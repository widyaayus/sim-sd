 <?php
include "config/koneksi.php";
$a=mysql_fetch_array(mysql_query("SELECT * FROM pemakai WHERE kode_ptgs='$_SESSION[namauser]'"));
echo "<img class='img-left framed' width=50 src='foto_user/$a[foto]' border=0 class>"; 
?>
