<?
include "config/koneksi.php";
$a=mysql_fetch_array(mysql_query("SELECT * FROM dis_identitas WHERE id_identitas = 1"));
$idnama   = $a[nama_rs];
$idalamat = $a[alamat];
$idkota = $a[kota];
$idtelpon = $a[no_telp];
$idemail = $a[email];
$idweb = $a[url];
$idlogo = $a[logo]; 

// Logo : left,top,persen gambar
$this->Image('../../logo/'.$idlogo,30,20,60);

// Huruf dan Ukuran : Arial bold 14
$this->SetFont('Arial','B',14);

// Margin kiri untuk tulisan
$this->Cell(65);

// Header / Kop
$this->Cell(30,0,$idnama,0,0,'L') ;
$this->Ln();

// Alamat : Arial 10
$this->SetFont('Arial','',10);
$this->Cell(0,30,'                       '.$idalamat,0,0,'L') ;
$this->Ln(15);
$this->Cell(0,30,'                       '.'Telpon '.$idtelpon.' '.$idkota,0,0,'L') ;

// Line break
$this->Ln(40);
?>
