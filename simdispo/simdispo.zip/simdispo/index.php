<html>
<head> 
<title>.:: DISPOSISI Online ~ Aplikasi Manajemen Disposisi Surat Masuk dan Keluar...</title>
<link rel="shortcut icon" href="favicon.png" />

<script language="javascript">
function validasi(form){
  if (form.username.value == ""){
    alert("Anda belum mengisikan Username.");
    form.username.focus();
    return (false);
  }
     
  if (form.password.value == ""){
    alert("Anda belum mengisikan Password.");
    form.password.focus();
    return (false);
  }
  
  return (true);
}
</script>
<link href="css/biru/login.css" rel="stylesheet" type="text/css" />
<script src="js/libs/modernizr-2.0.6.min.js"></script> 
<body OnLoad="document.login.username.focus();">
<div id="login">
  <center><img src="logo/logo.png">
  <h6>Sistem Informasi Manajemen Disposisi</h6></center>
		<div class="fieldContainer">
			<form name="login" action="cek_login.php" method="POST" onSubmit="return validasi(this)">
        <div class="formRow">
            <div class="field">
                <input type="text" name="username" placeholder=" username...">
            </div>
        </div>
        <div class="formRow">     
            <div class="field">
                <input type="password" name="password" placeholder=" password...">
            </div>
        </div>
		
	<div class="signupButton">
        <input type="submit" name="submit" id="submit" value="Login" />
    </div>
			</form>
			
</div>

<script type="text/javascript" src="ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="script.js"></script>
<div><footer>
<center>Didesain dan dikembangkan oleh www.isakomputer.com <br />
Hak Cipta dilindungi Undang Undang.<br />
Copyright&copy;2016</center>
</footer></div>
</body>
</html>
