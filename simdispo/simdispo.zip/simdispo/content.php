   
   <?php
   include "config/koneksi.php";
   include "config/library.php";
   include "config/fungsi_indotgl.php";
   include "config/fungsi_combobox.php";
   include "config/class_paging.php";
   include "config/fungsi_rupiah.php";

   // Bagian Home
   if ($_GET['module']=='home'){
	   //--------------------------------------- Modul ADMIN --------------
      if ($_SESSION['leveluser']=='admin'){
         echo "<div id='main-content'>
         <div class='container_12'>
         <div class='grid_12'>
                             
         <p>Hai <b>$_SESSION[namalengkap]</b>, selamat menggunakan aplikasi <b>DISPOSISI Online</b> ~ Aplikasi Manajemen Disposisi Surat Masuk dan Keluar. </p>
		               
         <div class='block-border'>
         <div class='block-header'>
         <h1>ADMINISTRATOR APLIKASI</h1>
         <span></span> 
         </div>
         <div class='block-content'>";

   echo "<ul class='shortcut-list'><center>
         <li><a href=media.php?module=identitas><img src='img/identitas.jpg'/>Identitas</a></li>
         <li><a href=media.php?module=gugustugas><img src='img/departemen.png'/>Unit Pengolah</a></li>
         <li><a href=media.php?module=user><img src='img/user.png'/>Manajemen User</a></li>
         <li><a href=media.php?module=jadwalretensi><img src='img/jra.png'/>Jadwal Retensi</a></li>
         <li><a href=media.php?module=lokasiarsip><img src='img/rakarsip.png'/>Lokasi Arsip</a></li>
         <li><a href=media.php?module=kategorialamat><img src='img/kategori2.png'/>Kategori Alamat</a></li>
         <li><a href=media.php?module=kategorisurat><img src='img/kategori1.png'/>Kategori Surat</a></li>
         <li><a href=media.php?module=jenissurat><img src='img/jenis.png'/>Jenis Surat</a></li>
         <li><a href=media.php?module=sifatsurat><img src='img/katlokasi.png'/>Sifat Surat</a></li>
         <li><a href=media.php?module=nasibakhir><img src='img/nasibakhir.png'/>Nasib Akhir Arsip</a></li>
         <li><a href=media.php?module=tempat><img src='img/venue.png'/>Tempat Kegiatan</a></li>
         <li><a href=media.php?module=pesanintranet><img src='img/kontak.png'/>Pesan Intranet</a></li>
         <center></ul>

         <p align=right>Login : $hari_ini, ";
         echo tgl_indo(date("Y m d")); 
         echo " | "; 
         echo date("H:i:s");
         echo " WIB</p>";
      
      } 
	  
	  //--------------------------------------- Modul DIREKSI --------------
	  elseif ($_SESSION['leveluser']=='direksi'){
         echo "<div id='main-content'>
         <div class='container_12'>
         <div class='grid_12'>
                             
         <p>Hai <b>$_SESSION[namalengkap]</b>, selamat menggunakan aplikasi <b>DISPOSISI Online</b> ~ Aplikasi Manajemen Disposisi Surat Masuk dan Keluar. </p>
         
         <div class='grid_12'>
         <div class='block-border'>
         <div class='block-header'>
         <h1>MODUL UNTUK DIREKSI</h1>
         <span></span> 
         </div>
         <div class='block-content'>
         <ul class='shortcut-list'>
         <li><a href=media.php?module=disposisi><img src='img/dispo.png'/>Disposisi</a></li>
         <li><a href=media.php?module=notadinas><img src='img/notadinas.png'/>Nota Dinas</a></li>
         <li><a href=media.php?module=jadwalkegiatan><img src='img/agenda.png'/>Agenda Kegiatan</a></li>
         <li><a href=media.php?module=pesanintranet><img src='img/kontak.png'/>Pesan Intranet</a></li>
         <li><a href=media.php?module=user><img src='img/user.png'/>Edit Profil</a></li>
         <li><a href=media.php?module=ubahsandi><img src='img/ubahsandi.png'/>Ubah Katasandi</a></li>
         </ul>

         <p align=right>Login : $hari_ini, ";
         echo tgl_indo(date("Y m d")); 
         echo " | "; 
         echo date("H:i:s");
         echo " WIB</p>";
      } 
	  
    elseif ($_SESSION['leveluser']=='pejabat'){
      if ($_SESSION['arsiparis']==1){
         echo "<div id='main-content'>
         <div class='container_12'>
         <div class='grid_12'>
                             
         <p>Hai <b>$_SESSION[namalengkap]</b>, selamat menggunakan aplikasi <b>DISPOSISI Online</b> ~ Aplikasi Manajemen Disposisi Surat Masuk dan Keluar. </p>
		      

         <div class='grid_12'>
         <div class='block-border'>
         <div class='block-header'>
         <h1>MODUL UNTUK PEJABAT KEARSIPAN</h1>
         <span></span> 
         </div>
         <div class='block-content'>
         <ul class='shortcut-list'>
         <li><a href=media.php?module=suratkeluar><img src='img/skel.png'/>Surat Keluar</a></li>
         <li><a href=media.php?module=keputusan><img src='img/sk.png'/>Surat Keputusan</a></li>
         <li><a href=media.php?module=perjanjian><img src='img/pks.png'/>Perjanjian</a></li>
         <li><a href=media.php?module=agendaarsip><img src='img/arsip.png'/>Proses Surat Masuk</a></li>
         <li><a href=media.php?module=terimaarsip><img src='img/masuk.png'/>Perimaan Surat Masuk</a></li>
         <li><a href=media.php?module=disposisi><img src='img/dispo.png'/>Disposisi</a></li>
         <li><a href=media.php?module=notadinas><img src='img/notadinas.png'/>Nota Dinas</a></li>
         <li><a href=media.php?module=jadwalretensi><img src='img/jra.png'/>Jadwal Retensi</a></li>
         <li><a href=media.php?module=gugustugas><img src='img/departemen.png'/>Unit Pengolah</a></li>
         <li><a href=media.php?module=lokasiarsip><img src='img/rakarsip.png'/>Lokasi Arsip</a></li>
         <li><a href=media.php?module=alamatsurat><img src='img/labelsurat.png'/>Alamat Surat</a></li>
         <li><a href=media.php?module=jadwalkegiatan><img src='img/agenda.png'/>Agenda Kegiatan</a></li>
         <li><a href=media.php?module=pesanintranet><img src='img/kontak.png'/>Pesan Intranet</a></li>
         <li><a href=media.php?module=user><img src='img/user.png'/>Edit Profil</a></li>
         <li><a href=media.php?module=ubahsandi><img src='img/ubahsandi.png'/>Ubah Katasandi</a></li>
         </ul>

         <p align=right>Login : $hari_ini, ";
         echo tgl_indo(date("Y m d")); 
         echo " | "; 
         echo date("H:i:s");
         echo " WIB</p>";
         }
     else{
         echo "<div id='main-content'>
         <div class='container_12'>
         <div class='grid_12'>
                             
         <p>Hai <b>$_SESSION[namalengkap]</b>, selamat menggunakan aplikasi <b>DISPOSISI Online</b> ~ Aplikasi Manajemen Disposisi Surat Masuk dan Keluar. </p>
		      

         <div class='grid_12'>
         <div class='block-border'>
         <div class='block-header'>
         <h1>MODUL UNTUK PEJABAT</h1>
         <span></span> 
         </div>
         <div class='block-content'>
         <ul class='shortcut-list'>
         <li><a href=media.php?module=disposisi><img src='img/dispo.png'/>Disposisi</a></li>
         <li><a href=media.php?module=notadinas><img src='img/notadinas.png'/>Nota Dinas</a></li>
         <li><a href=media.php?module=jadwalkegiatan><img src='img/agenda.png'/>Agenda Kegiatan</a></li>
		     <li><a href=media.php?module=pesanintranet><img src='img/kontak.png'/>Pesan Intranet</a></li>
		     <li><a href=media.php?module=user><img src='img/user.png'/>Edit Profil</a></li>
         <li><a href=media.php?module=ubahsandi><img src='img/ubahsandi.png'/>Ubah Katasandi</a></li>
         </ul>

         <p align=right>Login : $hari_ini, ";
         echo tgl_indo(date("Y m d")); 
         echo " | "; 
         echo date("H:i:s");
         echo " WIB</p>";
      } 
    }
	  //--------------------------------------- Modul ARSIPARIS --------------
	  elseif ($_SESSION['leveluser']=='arsiparis'){
         echo "<div id='main-content'>
         <div class='container_12'>
         <div class='grid_12'>
                             
         <p>Hai <b>$_SESSION[namalengkap]</b>, selamat menggunakan aplikasi <b>DISPOSISI Online</b> ~ Aplikasi Manajemen Disposisi Surat Masuk dan Keluar. </p>
		      
         <div class='grid_12'>
         <div class='block-border'>
         <div class='block-header'>
         <h1>MODUL UNTUK ARSIPARIS</h1>
         <span></span> 
         </div>
         <div class='block-content'>
         <ul class='shortcut-list'>
         <li><a href=media.php?module=suratkeluar><img src='img/skel.png'/>Surat Keluar</a></li>
         <li><a href=media.php?module=keputusan><img src='img/sk.png'/>Surat Keputusan</a></li>
         <li><a href=media.php?module=perjanjian><img src='img/pks.png'/>Perjanjian</a></li>
         <li><a href=media.php?module=agendaarsip><img src='img/arsip.png'/>Proses Surat Masuk</a></li>
         <li><a href=media.php?module=terimaarsip><img src='img/masuk.png'/>Perimaan Surat Masuk</a></li>
         <li><a href=media.php?module=jadwalretensi><img src='img/jra.png'/>Jadwal Retensi</a></li>
         <li><a href=media.php?module=gugustugas><img src='img/departemen.png'/>Unit Pengolah</a></li>
         <li><a href=media.php?module=alamatsurat><img src='img/labelsurat.png'/>Alamat Surat</a></li>
         <li><a href=media.php?module=jadwalkegiatan><img src='img/agenda.png'/>Agenda Kegiatan</a></li>
         <li><a href=media.php?module=pesanintranet><img src='img/kontak.png'/>Pesan Intranet</a></li>
         <li><a href=media.php?module=user><img src='img/user.png'/>Edit Profil</a></li>
         <li><a href=media.php?module=ubahsandi><img src='img/ubahsandi.png'/>Ubah Katasandi</a></li>
         </ul>

         <p align=right>Login : $hari_ini, ";
         echo tgl_indo(date("Y m d")); 
         echo " | "; 
         echo date("H:i:s");
         echo " WIB</p>";
      } 
	  
	  //--------------------------------------- Modul ARSIPARIS --------------
	  elseif ($_SESSION['leveluser']=='resepsionis'){
         echo "<div id='main-content'>
         <div class='container_12'>
         <div class='grid_12'>
                             
         <p>Hai <b>$_SESSION[namalengkap]</b>, selamat menggunakan aplikasi <b>DISPOSISI Online</b> ~ Aplikasi Manajemen Disposisi Surat Masuk dan Keluar. </p>
		      
         <div class='grid_12'>
         <div class='block-border'>
         <div class='block-header'>
         <h1>MODUL UNTUK PENERIMA SURAT</h1>
         <span></span> 
         </div>
         <div class='block-content'>
         <ul class='shortcut-list'>
         <li><a href=media.php?module=terimaarsip><img src='img/masuk.png'/>Perimaan Surat Masuk</a></li>
         <li><a href=media.php?module=alamatsurat><img src='img/labelsurat.png'/>Alamat Surat</a></li>
         <li><a href=media.php?module=jadwalkegiatan><img src='img/agenda.png'/>Agenda Kegiatan</a></li>
		     <li><a href=media.php?module=pesanintranet><img src='img/kontak.png'/>Pesan Intranet</a></li>
         <li><a href=media.php?module=user><img src='img/user.png'/>Edit Profil</a></li>
         <li><a href=media.php?module=ubahsandi><img src='img/ubahsandi.png'/>Ubah Katasandi</a></li>
         </ul>

         <p align=right>Login : $hari_ini, ";
         echo tgl_indo(date("Y m d")); 
         echo " | "; 
         echo date("H:i:s");
         echo " WIB</p>";
      } 
      
	  //--------------------------------------- Modul PEGAWAI --------------
	  else{
         echo "<div id='main-content'>
         <div class='container_12'>
         <div class='grid_12'>
                             
         <p>Hai <b>$_SESSION[namalengkap]</b>, selamat menggunakan aplikasi <b>DISPOSISI Online</b> ~ Aplikasi Manajemen Disposisi Surat Masuk dan Keluar. </p>
		      
         <div class='grid_12'>
         <div class='block-border'>
         <div class='block-header'>
         <h1>MODUL UNTUK PEGAWAI</h1>
         <span></span> 
         </div>
         <div class='block-content'>
         <ul class='shortcut-list'>
         <li><a href=media.php?module=terimaarsip><img src='img/masuk.png'/>Surat Masuk</a></li>
         <li><a href=media.php?module=pesaninternal><img src='img/kontak.png'/>Pesan Intranet</a></li>
         <li><a href=media.php?module=user><img src='img/user.png'/>Edit Profil</a></li>
         <li><a href=media.php?module=ubahsandi><img src='img/ubahsandi.png'/>Ubah Katasandi</a></li>
         </ul>

         <p align=right>Login : $hari_ini, ";
         echo tgl_indo(date("Y m d")); 
         echo " | "; 
         echo date("H:i:s");
         echo " WIB</p>";
      }
}

// Bagian Data Surat Keluar -- by Tejos
elseif ($_GET['module']=='suratkeluar'){
   if ($_SESSION['leveluser']=='admin' 
     OR $_SESSION['leveluser']=='pejabat' 
      OR $_SESSION['leveluser']=='arsiparis'){
    include "modul/mod_suratkeluar/suratkeluar.php";
  }
}

// Bagian Surat Keputusan -- by Tejos
elseif ($_GET['module']=='keputusan'){
   if ($_SESSION['leveluser']=='admin' 
     OR $_SESSION['leveluser']=='pejabat' 
      OR $_SESSION['leveluser']=='arsiparis'){
    include "modul/mod_suratkeputusan/suratkeputusan.php";
  }
}

// Bagian Surat Perjanjian -- by Tejos
elseif ($_GET['module']=='perjanjian'){
   if ($_SESSION['leveluser']=='admin' 
      OR $_SESSION['leveluser']=='pejabat' 
      OR $_SESSION['leveluser']=='arsiparis'){
    include "modul/mod_suratperjanjian/suratperjanjian.php";
  }
}

// Bagian Penerimaan Surat Masuk -- by Tejos
elseif ($_GET['module']=='terimaarsip'){
   if ($_SESSION['leveluser']=='arsiparis'
      OR $_SESSION['leveluser']=='pejabat' 
      OR $_SESSION['leveluser']=='resepsionis'){
    include "modul/mod_arsipmasuk/arsipmasuk.php";
  }
}

// Bagian Proses Surat Masuk -- by Tejos
elseif ($_GET['module']=='agendaarsip'){
   if ($_SESSION['leveluser']=='pejabat'
       OR $_SESSION['leveluser']=='arsiparis'){
    include "modul/mod_arsipproses/arsipproses.php";
  }
}

// Bagian Pemindahan Surat Keluar -- by Tejos
elseif ($_GET['module']=='pindahsurat'){
   if ($_SESSION['leveluser']=='admin' 
     OR $_SESSION['leveluser']=='pejabat' 
      OR $_SESSION['leveluser']=='arsiparis'){
    include "modul/mod_suratpindah/suratpindah.php";
  }
}

// Bagian Penyusutan Surat Keluar -- by Tejos
elseif ($_GET['module']=='susutsurat'){
   if ($_SESSION['leveluser']=='admin' 
     OR $_SESSION['leveluser']=='pejabat' 
      OR $_SESSION['leveluser']=='arsiparis'){
    include "modul/mod_suratsusut/suratsusut.php";
  }
}

// Bagian Disposisi -- by Tejos
elseif ($_GET['module']=='disposisi'){
   if ($_SESSION['leveluser']=='admin'  
    OR $_SESSION['leveluser']=='direksi' 
    OR $_SESSION['leveluser']=='pejabat'
	  OR $_SESSION['leveluser']=='arsiparis'){
    include "modul/mod_arsipdisposisi/arsipdisposisi.php";
  }
}

// Bagian Nota Dinas -- by Tejos
elseif ($_GET['module']=='notadinas'){
   if ($_SESSION['leveluser']=='admin'  
    OR $_SESSION['leveluser']=='direksi' 
    OR $_SESSION['leveluser']=='pejabat'
	  OR $_SESSION['leveluser']=='arsiparis'){
    include "modul/mod_notadinas/notadinas.php";
  }
}

// Bagian Jadwal Retensi Arsip -- by Tejos
elseif ($_GET['module']=='jadwalretensi'){
   if ($_SESSION['leveluser']=='admin'  
    OR $_SESSION['leveluser']=='direksi' 
    OR $_SESSION['leveluser']=='pejabat'
	  OR $_SESSION['leveluser']=='arsiparis'
    OR $_SESSION['leveluser']=='user'){
    include "modul/mod_jra/jra.php";
  }
}

// Bagian Lokasi Arsip -- by Tejos
elseif ($_GET['module']=='lokasiarsip'){
   if ($_SESSION['leveluser']=='admin'
     OR $_SESSION['leveluser']=='pejabat' 
     OR $_SESSION['leveluser']=='arsiparis'){
    include "modul/mod_lokasi/lokasi.php";
  }
}

// Bagian Unit/Gugus Tugas -- by Tejos
elseif ($_GET['module']=='gugustugas'){
   if ($_SESSION['leveluser']=='admin'
     OR $_SESSION['leveluser']=='pejabat' 
     OR $_SESSION['leveluser']=='arsiparis'){
    include "modul/mod_gugustugas/gugustugas.php";
  }
}

// Bagian Kategori Perusahaan -- by Tejos
elseif ($_GET['module']=='kategorialamat'){
   if ($_SESSION['leveluser']=='admin'){
    include "modul/mod_peruskat/peruskat.php";
  }
}

// Bagian Perusahaan -- by Tejos
elseif ($_GET['module']=='alamatsurat'){
   if ($_SESSION['leveluser']=='pejabat'
	   OR $_SESSION['leveluser']=='arsiparis'
	   OR $_SESSION['leveluser']=='resepsionis'){
    include "modul/mod_perus/perus.php";
  }
}

// Bagian Kategori Surat -- by Tejos
elseif ($_GET['module']=='kategorisurat'){
   if ($_SESSION['leveluser']=='admin'){
    include "modul/mod_suratkat/suratkat.php";
  }
}

// Bagian Jenis Surat -- by Tejos
elseif ($_GET['module']=='jenissurat'){
   if ($_SESSION['leveluser']=='admin'){
    include "modul/mod_suratjenis/suratjenis.php";
  }
}

// Bagian Sifat Surat-- by Tejos
elseif ($_GET['module']=='sifatsurat'){
   if ($_SESSION['leveluser']=='admin'){
    include "modul/mod_suratsifat/suratsifat.php";
  }
}

// Bagian Nasib Akhir Arsip -- by Tejos
elseif ($_GET['module']=='nasibakhir'){
   if ($_SESSION['leveluser']=='admin'){
    include "modul/mod_jranasibakhir/jranasibakhir.php";
  }
}

// Bagian Tempat Kegiatan -- by Tejos
elseif ($_GET['module']=='tempat'){
   if ($_SESSION['leveluser']=='admin' 
     OR $_SESSION['leveluser']=='arsiparis'){
    include "modul/mod_utiagendatempat/utiagendatempat.php";
  }
}

// Bagian UBAH SANDI -- by Tejos
elseif ($_GET['module']=='ubahsandi'){
   if ($_SESSION['leveluser']=='admin'  
     OR $_SESSION['leveluser']=='direksi' 
     OR $_SESSION['leveluser']=='pejabat'
	   OR $_SESSION['leveluser']=='arsiparis'
	   OR $_SESSION['leveluser']=='resepsionis'
     OR $_SESSION['leveluser']=='user'){
    include "modul/mod_ubahsandi/ubahsandi.php";
  }
}

// Bagian JADWAL KEGIATAN -- by Tejos
elseif ($_GET['module']=='jadwalkegiatan'){
   if ($_SESSION['leveluser']=='direksi' 
     OR $_SESSION['leveluser']=='pejabat'
	   OR $_SESSION['leveluser']=='arsiparis'
     OR $_SESSION['leveluser']=='resepsionis'
     OR $_SESSION['leveluser']=='user'){
    include "modul/mod_utiagenda/utiagenda.php";
  }
}

// Bagian SMS GATEWAY -- by Tejos
elseif ($_GET['module']=='smsgateway'){
   if ($_SESSION['leveluser']=='direksi' 
     OR $_SESSION['leveluser']=='pejabat'
	   OR $_SESSION['leveluser']=='arsiparis'
     OR $_SESSION['leveluser']=='user'){
    include "modul/mod_sms/sms.php";
  }
}

// Bagian Pesan INTRANET -- by Tejos
elseif ($_GET['module']=='pesanintranet'){
   if ($_SESSION['leveluser']=='admin'  
     OR $_SESSION['leveluser']=='direksi' 
     OR $_SESSION['leveluser']=='pejabat'
	   OR $_SESSION['leveluser']=='arsiparis'
	   OR $_SESSION['leveluser']=='resepsionis'
     OR $_SESSION['leveluser']=='user'){
    include "modul/mod_utiemail/utiemail.php";
  }
}

// Bagian Identitas -- by Tejos
elseif ($_GET['module']=='identitas'){
  if ($_SESSION['leveluser']=='admin'){
    include "modul/mod_identitas/identitas.php";
  }
}

// Bagian User -- by Tejos
elseif ($_GET['module']=='user'){
  if ($_SESSION['leveluser']=='admin'  
     OR $_SESSION['leveluser']=='direksi' 
     OR $_SESSION['leveluser']=='pejabat'
	   OR $_SESSION['leveluser']=='arsiparis'
	   OR $_SESSION['leveluser']=='resepsionis'
     OR $_SESSION['leveluser']=='user'){
    include "modul/mod_utiusers/utiusers.php";
  }
}

// Apabila modul tidak ditemukan
else{
  echo "<p><b>MAAF MODUL BELUM ADA ATAU BELUM LENGKAP</b></p>";
}


?>
