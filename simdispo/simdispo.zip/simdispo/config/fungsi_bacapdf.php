<?php
<embed src="../contoh.pdf"
   quality="high"
   name="fb"
   allowScriptAccess="always"
   allowFullScreen="true"
   pluginspage="http://www.adobe.com/go/getreader"
   type="application/pdf"
   width="612"
   height="792">
</embed>
?>
