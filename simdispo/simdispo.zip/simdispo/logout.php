<?php
  session_start();
  session_destroy();
  echo "<script>alert('Terima kasih Anda telah menggunakan Aplikasi SimDISPO ini.'); window.location = 'index.php'</script>";
?>
