<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];
  
// Hapus Tempat
if ($module=='tempat' AND $act=='hapus'){
    mysql_query("DELETE FROM dis_myevents1_tempat WHERE id_tempat='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input Kategori Surat
 elseif ($module=='tempat' AND $act=='input'){
     
     mysql_query("INSERT INTO dis_myevents1_tempat (kode_tempat,
                                   nama_tempat,
                                   kapasitas,
                                   fasilitas) 
	                       VALUES('$_POST[kode_tempat]',
                                '$_POST[nama_tempat]',
                                '$_POST[kapasitas]',
                                '$_POST[fasilitas]')");
 
  header('location:../../media.php?module='.$module);
  }

// Update Tempat
elseif ($module=='tempat' AND $act=='update') {
	   mysql_query("UPDATE dis_myevents1_tempat SET 
		                     kode_tempat   = '$_POST[kode_tempat]',
		                     nama_tempat   = '$_POST[nama_tempat]',
								         kapasitas  = '$_POST[kapasitas]',
								         fasilitas  = '$_POST[fasilitas]'
                  WHERE  id_tempat     = '$_POST[id]'");
 
 header('location:../../media.php?module='.$module);
	}
   
}

?>
