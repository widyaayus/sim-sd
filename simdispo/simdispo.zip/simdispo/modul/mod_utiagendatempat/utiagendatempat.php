<script>

function confirmdelete(delUrl) {

   if (confirm("Apakah Anda Yakin Ingin Menghapus Data Tempat Kegiatan Ini?")) {

      document.location = delUrl;

   }

}

</script>

<script>

function validasi(form){

		  if (form.kode_tempat.value == ""){

			alert("Anda belum mengisi Kode Tempat.");

			form.kode_tempat.focus();

			return (false);

		  }

		  if (form.nama_tempat.value == ""){

			alert("Anda belum mengisi Nama Tempat.");

			form.nama_tempat.focus();

			return (false);

		  }

		  

		  return (true);

}

</script>



<?php    

session_start();

//Deteksi hanya bisa diinclude, tidak bisa langsung dibuka (direct open)

if(count(get_included_files())==1)

{

	echo "<meta http-equiv='refresh' content='0; url=http://$_SERVER[HTTP_HOST]'>";

	exit("Direct access not permitted.");

}

 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='style.css' rel='stylesheet' type='text/css'>

 <center>Untuk mengakses modul, Anda harus login <br>";

  echo "<a href=../../index.php><b>LOGIN</b></a></center>";

}

else{



//cek hak akses user

$cek=user_akses($_GET[module],$_SESSION[sessid]);

if($cek==1 

   OR $_SESSION['leveluser']=='admin'){

	   

   $aksi="modul/mod_utiagendatempat/aksi_utiagendatempat.php";

   switch($_GET[act]){

   

   // Tampil Tempat Kegiatan

   default:

   echo "";

   

   if (empty($_GET['kata'])){

      echo "
      <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DAFTAR TEMPAT KEGIATAN</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=tempat&act=tambah' class='button'>
        <span>Tambahkan Tempat Kegiatan</span></a>
        </div>
	      <table id='table-example' class='table'>
       <thead><tr>

      <th>No.</th> 

      <th>Kode</th>

	    <th>Nama</th> 

	    <th>Kapasitas</th> 

	    <th>Aksi</th>

      </tr> 

      </thead>

      <tbody>";



      $p      = new Paging;

      $batas  = 15;

      $posisi = $p->cariPosisi($batas);

      

      $tampil = mysql_query("SELECT * FROM dis_myevents1_tempat ORDER BY id_tempat DESC");

      

      $no = $posisi+1;

      while($r=mysql_fetch_array($tampil)){

      $lebar=strlen($no);

      switch($lebar){

      

      case 1:

      {

        $g="0".$no;

        break;     

      }

      case 2:

      {

        $g=$no;

        break;     

      }      

    } 

	  

	  echo "<tr class=gradeX> 

   

    <td width=50><center>$g</center></td>

    <td>$r[kode_tempat]</td>

	  <td>$r[nama_tempat]</td>

	  <td>$r[kapasitas]</td>

	  <td valign=middle width=80>

	  <a href=?module=tempat&act=edit&id=$r[id_tempat] rel=tooltip-top title='Edit' class='with-tip'>

    <center><img src='img/edit.png'></a> 

	<a href=javascript:confirmdelete('$aksi?module=tempat&act=hapus&id=$r[id_tempat]') title='Hapus' class='with-tip'>

       <img src='img/hapus.png'></center></a>

   

    </td> </tr> ";

  

    $no++; }

	

   echo "</tbody></table> ";



   break;  

   

  }



   //--INPUT TEMPAT KEGIATAN -------------  

   case "tambah":

   echo "

   <div id='main-content'>

   <div class='container_12'>



   <div class='grid_12'>

   <div class='block-border'>

   <div class='block-header'>

   

   <h1>TAMBAH TEMPAT KEGIATAN</h1>

   </div>

   <div class='block-content'>

   

   <form onSubmit='return validasi(this)' id='formtempat' 

   method=POST action='$aksi?module=tempat&act=input' enctype='multipart/form-data'>

	 

   <p class=inline-small-label> 

   <label for=field4>Kode</label>

   <input type=text name='kode_tempat'>

   </p> 

	 	  

   <p class=inline-small-label> 

   <label for=field4>Nama</label>

   <input type=text name='nama_tempat'>

   </p> 

   

   <p class=inline-small-label> 

   <label for=field4>Kapasitas</label>

   <input style='width:60%' type=text name='kapasitas'> orang

   </p> 

   

   <p class=inline-small-label> 

   <label for=field4>Fasilitas</label>

   <textarea name='fasilitas' style='height: 50px;'></textarea>

   </p>";



   echo "<br/><br/><div class=block-actions> 

    <ul class=actions-right> 

    <li>

    <a class='button red' id=reset-validate-form href='?module=tempat'>Batal</a>

    </li> </ul>

    <ul class=actions-left> 

    <li>

   <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>

   </form>"; 

	 

   break;

   

   //--EDIT TEMPAT KEGIATAN -------------

   case "edit":

   $edit=mysql_query("SELECT * FROM dis_myevents1_tempat WHERE id_tempat='$_GET[id]'");

   $r=mysql_fetch_array($edit);



   echo "

   <div id='main-content'>

   <div class='container_12'>



   <div class='grid_12'>

   <div class='block-border'>

   <div class='block-header'>

   

   <h1>EDIT TEMPAT KEGIATAN</h1>

   </div>

   <div class='block-content'>

     

   <form onSubmit='return validasi(this)' id='formkategori' 

   method=POST action='$aksi?module=tempat&act=update' enctype='multipart/form-data'>

   <input type=hidden name=id value=$r[id_tempat]>

	 

   <p class=inline-small-label> 

   <label for=field4>Kode</label>

   <input type=text name='kode_tempat' value='$r[kode_tempat]'>

   </p> 

   

   <p class=inline-small-label> 

   <label for=field4>Nama</label>

   <input type=text name='nama_tempat' value='$r[nama_tempat]'>

   </p> 

   

   <p class=inline-small-label> 

   <label for=field4>Kapasitas</label>

   <input style='width:60%' type=text name='kapasitas' value='$r[kapasitas]'> orang

   </p>

   

   <p class=inline-small-label> 

   <label for=field4>Fasilitas</label>

   <textarea name='fasilitas' style='height: 100px;' >$r[fasilitas]</textarea>

   </p><br/>";

	  echo "<br/><div class=block-actions> 

    <ul class=actions-right> 

    <li>

    <a class='button red' id=reset-validate-form href='?module=tempat'>Batal</a>

    </li> </ul>

    <ul class=actions-left> 

    <li>

    <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>

	</form>";

    

    break;  

   }

   //kurawal akhir hak akses module

   } else {

	echo akses_salah();

   }



   }

   ?>





   </div> 

   </div>

   </div>

   <div class='clear height-fix'></div> 

   </div></div>

