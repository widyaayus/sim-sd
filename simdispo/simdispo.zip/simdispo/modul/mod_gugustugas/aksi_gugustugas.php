<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus Gugus Tugas
if ($module=='gugustugas' AND $act=='hapus'){
    mysql_query("DELETE FROM dis_unit WHERE id_unit='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input Gugus Tugas
 elseif ($module=='gugustugas' AND $act=='input'){
     mysql_query("INSERT INTO dis_unit(id_unit,
                                 nm_jbtan,
                                 nm_pjabat) 
	                       VALUES('$_POST[id_unit]',
                                '$_POST[nm_jbtan]',
								'$_POST[nm_pjabat]')");
 
  header('location:../../media.php?module='.$module);
  }

// Update Gugus Tugas
elseif ($module=='gugustugas' AND $act=='update') {
	if($_SESSION[leveluser]=='admin'){
	    mysql_query("UPDATE dis_unit SET 
		                           id_unit   = '$_POST[id_unit]',
				                   nm_jbtan  = '$_POST[nm_jbtan]',
								   nm_pjabat = '$_POST[nm_pjabat]'  
                            WHERE  id_unit = '$_POST[id]'");
	}else{
		mysql_query("UPDATE dis_unit SET 
		                           nm_jbtan  = '$_POST[nm_jbtan]',
								   nm_pjabat = '$_POST[nm_pjabat]'  
                            WHERE  id_unit = '$_POST[id]'");
	}
   header('location:../../media.php?module='.$module);
}
}
?>
