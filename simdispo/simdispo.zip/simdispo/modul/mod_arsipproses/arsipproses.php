<script>
function confirmdelete(delUrl) {
   if (confirm("Apakah Anda Yakin Ingin Menghapus Data Arsip Ini?")) {
      document.location = delUrl;
   }
}

</script>
<script>
function validasi(form){
		  
		  if (form.sifat.value == 0){
			alert("Anda belum mengisi Bagian Sifat.");
			form.sifat.focus();
			return (false);
		  }
		  if (form.klas.value == 0){
			alert("Anda belum mengisi Bagian Klasifikasi.");
			form.klas.focus();
			return (false);
		  }
		  if (form.lokasi.value == 0){
			alert("Anda belum mengisi Bagian Lokasi.");
			form.lokasi.focus();
			return (false);
		  }
		  if (form.utk_dispo.value == 0){
			alert("Anda belum mengisi Bagian Disposisi.");
			form.utk_dispo.focus();
			return (false);
		  }
		  return (true);
}
</script>


<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
 
  echo "
  <link href='../../css/biru/zalstyle.css' rel='stylesheet' type='text/css'>";

  echo "
  </head>
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  
  <img src='img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul ini, Anda harus login dahulu!</p></span><br/>
  
  </section>
  
  <section id='error-text'>
  <p><a class='button' href='index.php'>&nbsp;&nbsp; <b>ULANGI LAGI</b> &nbsp;&nbsp;</a></p>
  </section>
  </div>";
  
  }
  else{

//cek hak akses user dan pastikan semua user boleh mengakses  modul ini
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 
  OR $_SESSION['leveluser']=='pejabat'
  OR $_SESSION['leveluser']=='arsiparis'){

$aksi="modul/mod_arsipproses/aksi_arsipproses.php";
switch($_GET[act]){

  // Tampil Data Surat Masuk Sekretariat
  default:
  echo "";
  
  //----------Jika kata KOSONG ------------------
 if (empty($_GET['kata'])){
    
		echo "
        <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DAFTAR ARSIP SURAT MASUK</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=agendaarsip&act=suratterima' class='button'><span>Tambah Data</span></a>
        <a href='modul/mod_laporan/cetakdaftarsuratmasukpdf.php' target = _blank class='button'><span>Cetak Daftar Arsip</span></a>
        </div>
	      <table id='table-example' class='table'>
        <thead><tr>  
        <th>No</th>
        <th>No.Agenda</th>
		    <th>Tgl.Terima</th>
        <th>Pengirim</th>
        <th>Perihal</th>
        <th>No.Surat</th>
        <th>Kode File</th>";
        if ($_SESSION['leveluser']=='pejabat'){
        echo"<th>#</th>";
        }
        echo"<th>Aksi</th>
        </thead>
        <tbody>";
   
        $p      = new Paging;
        $batas  = 40;
        $posisi = $p->cariPosisi($batas);
        $tampil = mysql_query("SELECT a.*,b.nama,b.alamat,b.kota 
                  FROM dis_masuk a
							  inner join dis_perus as b on a.nomor = b.nomor
							  WHERE year(tg_terima) = year(now())
							  ORDER BY tg_terima DESC,no_masuk DESC");
	    $no = $posisi+1;
    
        while($r=mysql_fetch_array($tampil)){
        $tgl_posting=tgl_indo($r[tanggal]);
        $lebar=strlen($no);
        switch($lebar){
        case 1:
        {
        $g="0000".$no;
        break;     
         }
		 case 2:
        {
        $g="000".$no;
        break;     
         }
		 case 3:
        {
        $g="00".$no;
        break;     
         }
	    case 4:
         {
        $g="0".$no;
        break;     
        }
        case 5:
        {
        $g=$no;
        break;     
       }      
       } 
	  
	  //----------Jika hak akses PEJABAT ------------------
	  if ($_SESSION['leveluser']=='pejabat'){
         echo "<tr class=gradeX> 
         <td><center>$g</center></td>
         <td>$r[no_masuk]</td>
         <td>$r[tg_terima]</td>
	     <td>$r[nama]</td>
	     <td>$r[perihal]</td>
	     <td>$r[no_surat]</td>
	     <td>$r[kodefile]</td>
	     <td>
       <a href=?module=agendaarsip&act=lihatdispo&id=$r[no_masuk] title='Lihat Disposisi' class='with-tip'>DISPO</a>
       </td>
       <td width=70>
         <a href=?module=agendaarsip&act=lihatfile&id=$r[idmasuk] title='Lihat Surat' class='with-tip'>&nbsp;&nbsp;<img src='img/pdf.gif'></center></a>   
         <a href=?module=agendaarsip&act=edit&id=$r[idmasuk] title='Edit' class='with-tip'>&nbsp;&nbsp;<img src='img/edit.png'></a>
         </td></tr>";
	     }
		 
		 else{
	    echo "<tr class=gradeX> 
       <td><center>$g</center></td>
       <td>$r[no_masuk]</td>
       <td width=30>$r[tg_terima]</td>
	   <td>$r[nama]</td>
	   <td>$r[perihal]</td>
	     <td>$r[no_surat]</td>
	     <td>$r[kodefile]</td>
	    <td width=80>
       <a href=?module=agendaarsip&act=lihatfile&id=$r[idmasuk] title='Lihat Surat' class='with-tip'>&nbsp;&nbsp;<img src='img/pdf.gif'></center></a>   
       <a href=?module=agendaarsip&act=edit&id=$r[idmasuk] title='Edit' class='with-tip'>&nbsp;<img src='img/edit.png'></center></a>   
       </td></tr>";
		}
		
	   $no++;
       }
   
       echo "</table>";
       $jmldata = mysql_num_rows(mysql_query("SELECT * FROM dis_masuk"));  
       $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
       $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);
       break; 
}
  
  case "suratterima":
  //----------Jika kata KOSONG ------------------
 if (empty($_GET['kata'])){
	 //----------Jika Level User Arsiparis ------------------
	 echo "<div id='main-content'>
        <div class='container_12'>
        <div class=grid_12> 
        </div>

        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DAFTAR SURAT MASUK BARU</h1>
        <div id='form-close'>
        <p><a class='button red' href='?module=agendaarsip'>X</a> </p>
        </div> 
        </div>
        <div class='block-content'>
	      <table id='table-example' class='table'>
        <thead><tr>  
        <th>No</th>
        <th>No.Agenda</th>
        <th>Asal Surat</th>
		    <th>Aksi</th>
        </thead>
        <tbody>";
   
        $p      = new Paging;
        $batas  = 10;
        $posisi = $p->cariPosisi($batas);
        $tampil = mysql_query("SELECT a.*,b.nama,b.alamat,b.kota 
							  FROM dis_masuk_agd a
							  inner join dis_perus as b on a.noperus = b.nomor
							  where year(tgmasuk) = year(now())
							  AND kunci=0 AND diproses=1
							  ORDER BY nomasuk");
	    $no = $posisi+1;
    
        while($r=mysql_fetch_array($tampil)){
        $tgl_posting=tgl_indo($r[tanggal]);
        $lebar=strlen($no);
        switch($lebar){
        case 1:
        {
        $g="00".$no;
        break;     
         }
	    case 2:
         {
        $g="0".$no;
        break;     
        }
        case 3:
        {
        $g=$no;
        break;     
       }      
       } 
	   
	   //--Jika belum diproses warna -- merah
	   //--Jika belum dikunci warna -- kuning
	   //--Jika sudah semua warna sesuai background
	   
	   if($r[diproses]==0){
	   $warna  = 'background:#F33; color:#fff';  //--merah-putih
	   }
	   elseif($r[kunci]==0){
	   $warna  = 'background:#FF9; color:#000'; //--kuning-hitam
	   }
	   else{
	   $warna  = '';
	   }
	
	   $kirim = $r[nama].', '.$r[alamat].' '.$r[kota].' '.$r[kodepos];
       
	  echo "<tr class=gradeX> 
       <td style='$warna;'><center>$g</center></td>
       <td width=70 style='$warna;'>$r[nomasuk]</td>
	   <td style='$warna;'>$kirim</td>
       <td width=40 style='$warna;'>
       <a href=?module=agendaarsip&act=tambaharsip&id=$r[nomasuk] title='Tambah Data Arsip' class='with-tip'>
       <center><b>PILIH</b></center></a>   
       </td></tr>";
	   
	   $no++;
       }
   
       echo "</table>";
       $jmldata = mysql_num_rows(mysql_query("SELECT * FROM dis_masuk_agd 
                                              WHERE year(tgmasuk) = year(now()) 
                                              AND kunci=0 AND diproses=1"));  
       $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
       $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);
       
       break;    
  }
  
  case "tambaharsip":
  $tambah = mysql_query("SELECT a.*,b.nama,b.alamat,b.kota 
							  FROM dis_masuk_agd a
							  inner join dis_perus as b on a.noperus = b.nomor
							  WHERE nomasuk='$_GET[id]'");
  $r    = mysql_fetch_array($tambah);
  $kirim = $r[nama].', '.$r[alamat].' '.$r[kota].' '.$r[kodepos];
  
  echo "
  <div id='main-content'>
  <div class='container_12'>

  <div class='grid_12'>
  <div class='block-border'>
  <div class='block-header'>
   
  <h1>MENAMBAHKAN DATA ARSIP BARU</h1>
  </div>
  <div class='block-content'>

  <form onSubmit='return validasi(this)' id='formagendaarsip' 
  method=POST action='$aksi?module=agendaarsip&act=input' enctype='multipart/form-data'>
  
   <p class=inline-small-label> 
   <label for=field4>No. Terima</label>
   <input type=text name='no_agenda' value='$r[nomasuk]' readonly>
   </p> 
   <p class=inline-small-label> 
   <label for=field4>Pengirim</label>
   <input type=text name='nomor' value='$r[noperus]' readonly>
   </p> 	
   <p class=inline-small-label> 
   <label for=field4> </label>
   <textarea name='nama' style='height: 50px;' readonly>$kirim</textarea>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Tanggal Surat</label>";           
   combotgl(1,31,'tgl_surat',$tgl_skrg);
   combonamabln(1,12,'bln_surat',$bln_sekarang);
   combothn($thn_sekarang-1,$thn_sekarang,'thn_surat',$thn_sekarang);

   echo "</p>
   <p class=inline-small-label> 
   <label for=field4>No.Surat</label>
   <input style = 'width:30%' type=text name='no_surat' value='$r[nosurat]'> Lampiran 
   <input style = 'width:20%' type=text name='lampiran' value='$r[lamp]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Perihal</label>
   <input type=text name='perihal' value='$r[perihal]'>
   </p>
    
   <p class=inline-small-label> 
   <label for=field4>Sifat Surat</label>
   <select name='sifat'>
   <option value='' selected>- Pilih Sifat Surat-</option>";
   $tampil=mysql_query("SELECT * FROM dis_surat_sifat ORDER BY id_sifat");  
   while($w=mysql_fetch_array($tampil)){
   echo "<option value=$w[kode_sifat]>$w[kode_sifat]</option> </p> ";}
   echo "</select>";
   
   echo "	
   Klasifikasi
   <select name='klas'>
   <option value=0 selected>- Pilih Klasifikasi -</option>";   
   $tampil1=mysql_query("SELECT * FROM dis_jra ORDER BY jra_kode");
   while($x=mysql_fetch_array($tampil1)){
   echo "<option value=$x[jra_kode]>$x[jra_kode] - $x[jra_msl]</option> ";}
   echo "</select>";

   echo "
   <p class=inline-small-label> 
   <label for=field4>Lokasi Arsip</label>
   <select name='lokasi'>
   <option value=0 selected>- Pilih Lokasi Arsip -</option>";    
   $tampil1=mysql_query("SELECT * FROM dis_lokasi ORDER BY kode_lokasi");
   while($x=mysql_fetch_array($tampil1)){
   echo "<option value=$x[kode_lokasi]>$x[kode_lokasi] - $x[nama_lokasi]</option> ";}
   echo "</select>";

   echo "Disposisi untuk
   <select name='utk_dispo'>
   <option value=0 selected>- Pilih Tujuan Disposisi -</option>";   
   $tampil1=mysql_query("SELECT * FROM dis_unit ORDER BY nm_jbtan");
   while($x=mysql_fetch_array($tampil1)){
   echo "<option value=$x[id_unit]>$x[nm_jbtan] - [$x[id_unit]]</option> </p> ";}
   echo "</select>";

   echo "
   <p class=inline-small-label> 
   <label for=field4>Upload File</label>
   <input type=file name='fupload'><br />
   <small><b>Perhatian</b> : File yang diupload harus berekstensi PDF</small>
   </p>
   
   <br /> 
   <div class=block-actions> 
   <ul class=actions-right> 
   <li>
   <a class='button red' id=reset-validate-form href='?module=agendaarsip&act=suratterima'>Batal</a>
   </li> </ul>
   <ul class=actions-left> 
   <li>
      <input type='submit' name='fupload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	  </li> </ul>
	  </form>";
   break;
   
  case "edit":
  $edit = mysql_query("SELECT a.*,b.nama,b.alamat,b.kota,b.kodepos 
							  FROM dis_masuk a
          inner join dis_perus as b on a.nomor = b.nomor
          WHERE idmasuk='$_GET[id]'");
  $r    = mysql_fetch_array($edit);
  $kirim = $r[nama].', '.$r[alamat].' '.$r[kota].' '.$r[kodepos];

   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>EDIT DATA ARSIP SURAT MASUK</h1>
   </div>
   <div class='block-content'>

   <form onSubmit='return validasi(this)' id='formagendaarsip' 
   method=POST enctype='multipart/form-data' action=$aksi?module=agendaarsip&act=update>
   <input type=hidden name=id value=$r[idmasuk]>
   
   <p class=inline-small-label> 
   <label for=field4>Tanggal Masuk</label>";   
          $get_tgl2=substr("$r[tg_terima]",8,2);
          combotgl(1,31,'tgl_terima',$get_tgl2);
          $get_bln2=substr("$r[tg_terima]",5,2);
          combonamabln(1,12,'bln_terima',$get_bln2);
          $get_thn2=substr("$r[tg_terima]",0,4);
          combothn($thn_sekarang-10,$thn_sekarang,'thn_terima',$get_thn2);

    echo "</p>
   <p class=inline-small-label> 
   <label for=field4>Nomor Agenda</label>
   <input type=text name='no_masuk' value='$r[no_masuk]' readonly>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4> Pengirim</label>
   <input style = 'width:10%' type=text name='no_agenda' value='$r[no_agenda]' readonly>
   <input style = 'width:10%' type=text name='nomor' value='$r[nomor]' readonly>
   <textarea name='pengirim' style='height: 30px;' readonly>$kirim</textarea>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Tanggal Surat</label>";   
          $get_tgl2=substr("$r[tg_surat]",8,2);
          combotgl(1,31,'tgl_surat',$get_tgl2);
          $get_bln2=substr("$r[tg_surat]",5,2);
          combonamabln(1,12,'bln_surat',$get_bln2);
          $get_thn2=substr("$r[tg_surat]",0,4);
          combothn($thn_sekarang-10,$thn_sekarang,'thn_surat',$get_thn2);

    echo "</p>
    <p class=inline-small-label> 
   <label for=field4>Nomor Surat</label>
   <input style = 'width:30%' type=text name='no_surat' value='$r[no_surat]'> Lampiran 
   <input style = 'width:20%' type=text name='lampiran' value='$r[lamp]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4> Perihal</label>
   <input type=text name='perihal' value='$r[perihal]'>
   </p>
   
   <p class=inline-small-label> 
   <label for=field4>Sifat Surat</label>
   <select name='sifat'>";
   $tampil=mysql_query("SELECT * FROM dis_surat_sifat ORDER BY id_sifat");
   if ($r[sifat]==0){
   echo "<option value=0 selected>- Pilih Sifat Surat-</option>"; }   
   while($w=mysql_fetch_array($tampil)){
   if ($r[sifat]==$w[kode_sifat]){
   echo "<option value=$w[kode_sifat] selected>$w[kode_sifat]</option>";}
   else{
   echo "<option value=$w[kode_sifat]>$w[kode_sifat]</option> ";}}
   echo "</select>";
   
   echo " Klasifikasi    
   <select name='klas'>";
   $tampil1=mysql_query("SELECT * FROM dis_jra ORDER BY jra_msl");
   if ($r[kodejra]==0){
   echo "<option value=0 selected>- Pilih Klasifikasi -</option>"; }   

   while($x=mysql_fetch_array($tampil1)){
   if ($r[kodejra]==$x[jra_kode]){
   echo "<option value=$x[jra_kode] selected>$x[jra_msl] - $x[jra_kode]</option>";}
   else{
   echo "<option value=$x[jra_kode]>$x[jra_msl] - $x[jra_kode]</option> </p> ";}}
   echo "</select>";

   echo "
   <p class=inline-small-label> 
   <label for=field4>Lokasi Arsip</label>
   <select name='lokasi'>";
   $tampil1=mysql_query("SELECT * FROM dis_lokasi ORDER BY nama_lokasi");
   if ($r[kodelok]==0){
   echo "<option value=0 selected>- Pilih Lokasi Arsip -</option>"; }   

   while($x=mysql_fetch_array($tampil1)){
   if ($r[kodelok]==$x[kode_lokasi]){
   echo "<option value=$x[kode_lokasi] selected>$x[nama_lokasi] - $x[kode_lokasi]</option>";}
   else{
   echo "<option value=$x[kode_lokasi]>$x[nama_lokasi] - $x[kode_lokasi]</option> ";}}
   echo "</select>";

   echo "
   Kode Arsip
   <input style = 'width:20%' type=text name='kodefile' value='$r[kodefile]' readonly> 
   </p>
   
   
   <p class=inline-small-label> 
   <label for=field4>Disposisi Untuk</label>
   <select name='utk_dispo'>";
   $tampil1=mysql_query("SELECT * FROM dis_unit ORDER BY id_unit");
   if ($r[utk_dispo]==0){
   echo "<option value=0 selected>- Pilih Unit -</option>"; }   

   while($x=mysql_fetch_array($tampil1)){
   if ($r[utk_dispo]==$x[id_unit]){
   echo "<option value=$x[id_unit] selected>$x[nm_jbtan] - [$x[id_unit]]</option>";}
   else{
   echo "<option value=$x[id_unit]>$x[nm_jbtan] - [$x[id_unit]]</option> ";}}
   echo "</select>";

   echo "
   No. Disposisi
   <input style = 'width:20%' type=text name='no_dispo' value='$r[no_dispo]' readonly>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Nama File</label>
   <input type=text name='gambar' value='$r[gambar]' disabled>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Ganti File</label>
   <input type=file name='fupload'><br />
   <small><b>Perhatian</b> : File yang diupload harus berekstensi PDF</small>
   </p>";
   
   if ($r[status1]=='DISIMPAN'){
      echo "
      <p class=inline-small-label> 
      <label for=field4>Status Akhir</label>
      <input type=radio name='status1' value='DISIMPAN' checked> Disimpan   
      <input type=radio name='status1' value='DIPROSES'> Diproses</p>";}
    else{
      echo "
      <p class=inline-small-label> 
      <label for=field4>Status Akhir</label>
      <input type=radio name='status1' value='DISIMPAN'> Disimpan  
      <input type=radio name='status1' value='DIPROSES' checked> Diproses</p>";}
        
	echo "<br/>
   <div class=block-actions> 
   <ul class=actions-right> 
   <li>
   <a class='button red' id=reset-validate-form href='?module=agendaarsip'>Batal</a>
   </li> </ul>
   <ul class=actions-left> 
   <li>
      <input type='submit' name='fupload' class='button' value=' &nbsp;&nbsp;Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
   </form>";
   
    break; 
    
    
  case "lihatdispo": 
  $edit = mysql_query("SELECT a.*,b.nama,b.alamat,b.kota,b.kodepos 
							  FROM dis_masuk a
          inner join dis_perus as b on a.nomor = b.nomor
          WHERE no_masuk='$_GET[id]'");
  $r    = mysql_fetch_array($edit);
  $file = $r[gambar];
  $kirim = $r[nama].', '.$r[alamat].' '.$r[kota].' '.$r[kodepos];
  
  echo "<div id='main-content'>
   <div class='container_12'>
   <div class='grid_12'></div>

        <div class='grid_12'>
  <div class='block-border'>
   <div class='block-header'>
        <h1>View Surat Masuk</h1>
        <span></span>
   </div>
   
   <div class='block-content'>
   <center><embed src='fileupload/masuk/$file#toolbar=0&navpanes=0&scrollbar=0' 
          quality='high'
          name='suratmasuk'
          AllowScriptAccess='always'
          AllowFullScreen='true'
          type='application/pdf' 
          width='100%' 
          height='550'/>
   </embed></center>
   </div>
   </div>
   <div class='block-header'>
        <h1>DISPOSISI SURAT MASUK</h1>
        <div id='form-close'>
            <p><a class='button red' href='?module=agendaarsip'>X</a> </p>
        </div>
   </div>
   
   <div class='block-content'>
   <form method=POST enctype='multipart/form-data' action='modul/mod_laporan/cetakdisposisipdf.php' target = _blank >
   <input type=hidden name=no_masuk value=$r[no_masuk]>
   
   <p class=inline-small-label> 
   <label for=field4>Nomor Agenda</label>
   <input type=text name='no_masuk' value='$r[no_masuk]'  readonly>
   </p>	
   
   <p class=inline-small-label> 
   <label for=field4> Pengirim</label>
   <textarea name='pengirim' style='height: 30px;'  disabled>$kirim</textarea>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Perihal</label>
   <textarea name='perihal' style='height: 30px;'  disabled>$r[perihal]</textarea>
   </p>
   <p class=inline-small-label> 
   <label for=field4>No. Disposisi</label>
   <input type=text name='no_dispo' value='$r[no_dispo]' disabled>
   </p>
   
   <div class='block-content'>
   <div id='form-close'>
        <input type='submit' name='fupload' class='button' value='  Cetak Dispo  '>
   </div>
   <h4>DETAIL DISPOSISI:</h4>
    
   <table id='table-example' class='table'>
   <thead><tr>
      <th>No</th>
      <th>Tanggal</th>
      <th>Dari</th>
      <th>Untuk</th>
      <th>Disposisi</th>
   </thead>
   <tbody>";
	
   $p      = new Paging;
   $batas  = 15;
   $posisi = $p->cariPosisi($batas);
   
   $tampil=mysql_query("SELECT a.*,b.nm_jbtan as dispodari,c.nm_jbtan as dispountuk
                        FROM dis_dispo_dt a
                        inner join dis_unit as b on a.dari_dispo=b.id_unit
                        inner join dis_unit as c on a.untuk=c.id_unit
                        WHERE nomasuk='$_GET[id]'
                        ORDER BY iddispo ASC");
      
   $no = $posisi+1;
   while($r=mysql_fetch_array($tampil)){
   $lebar=strlen($no);
   switch($lebar){
   case 1:
      {
        $g="0".$no;
        break;     
      }
      case 2:
      {
        $g=$no;
        break;     
      }      
      } 

   $warna  = 'color:#F33';
	  if($r[baca]=='0'){
   echo "<tr class=gradeX> 
   <td width=50 style='$warna;'><center>$g</center></td>
   <td width=100 style='$warna;'>$r[tgdispo]</td>
   <td style='$warna;'>$r[dispodari]</td>
   <td style='$warna;'>$r[dispountuk]</td>
   <td style='$warna;'>$r[isidispo]</td>
   </td></tr>";
   }
   else{
   echo "<tr class=gradeX> 
   <td width=50><center>$g</center></td>
   <td width=100'>$r[tgdispo]</td>
   <td >$r[dispodari]</td>
   <td >$r[dispountuk]</td>
   <td >$r[isidispo]</td>
   </td></tr>";
   }
   $no++;
       }
   
       echo "</table></div>
   </div></div>
   </div>
   </div>";
   
    break;

case "cetakdaftar": 
  echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>CETAK DAFTAR ARSIP SURAT MASUK</h1>
   </div>
   <div class='block-content'>
   
   <form method=POST enctype='multipart/form-data' href='modul/mod_laporan/cetakdaftarsuratmasukpdf.php' target = _blank>
    
   <p class=inline-small-label> 
   <label for=field4>Masukkan Tahun</label>";   
          $get_thn2=substr("$r[tg_terima]",0,4);
          combothn($thn_sekarang-10,$thn_sekarang,'tahunarsip',$get_thn2);

    echo "</p>
   <div class=block-actions>
   <ul class=actions-right> 
   <li>
   <a class='button red' id=reset-validate-form href='?module=agendaarsip'>Tutup</a>
   </li> </ul>
   <ul class=actions-left> 
   <li>
      <input type='submit' name='fupload' class='button' value=' &nbsp;&nbsp;Cetak &nbsp;&nbsp;&nbsp;&nbsp;'>
  </li> </ul>";
   
    break;


   case "lihatfile": 
  $gambar = mysql_query("SELECT no_masuk,gambar FROM dis_masuk WHERE idmasuk='$_GET[id]'");
  $r    = mysql_fetch_array($gambar);
  $file = $r[gambar];
  
  echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>VIEW SURAT NO.: $r[no_masuk]</h1>
   <div id='form-close'>
      <p><a class='button red' href='?module=agendaarsip'>X</a> </p>
   </div>
   </div>
   
   <div class='block-content'>
   
   <center>
   <embed src='fileupload/masuk/$file#toolbar=0&navpanes=0&scrollbar=0' 
          quality='high'
          name='suratmasuk'
          AllowScriptAccess='always'
          AllowFullScreen='true'
          type='application/pdf' 
          width='100%' 
          height='500'/>
   </embed>
   </center>";
   
    break;
	
}
    //kurawal akhir hak akses module
}else {
	echo akses_salah();
    }
    }
    ?>

   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>
