<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/biru/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../config/koneksi.php";
include "../../config/library.php";
include "../../config/fungsi_thumb.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus Data Arsip
if ($module=='agendaarsip' AND $act=='hapus'){
   $data = mysql_query("SELECT gambar FROM dis_masuk WHERE idmasuk='$_GET[id]'");
   $z    = mysql_fetch_array($data);
   
   if ($z[gambar] !=''){
	 mysql_query("DELETE FROM dis_masuk WHERE idmasuk='$_GET[id]'");
     @unlink('../../fileupload/masuk/'.$z['gambar']);   
   }
   else{
     mysql_query("DELETE FROM dis_masuk WHERE idmasuk='$_GET[id]'");
   }
  
  header('location:../../media.php?module='.$module);
}


// Input Data Arsip
elseif ($module=='agendaarsip' AND $act=='input'){
  $kode= $_POST[klas];
  $lok = $_POST[lokasi];
  $agenda = $_POST[no_agenda];
  $dispo  = $_POST[utk_dispo];
  $thn = date("y"); //tahun 2 digit
	$bln = date("m"); //bulan 2 digit
	$thn1= date("Y"); //tahun 4 digit
	$qr1	= mysql_query("SELECT MAX(CONCAT(LPAD((LEFT((no_masuk),6)+1),6,'0'))) FROM dis_masuk WHERE YEAR(tg_terima) = $thn1");
  $qr2  = mysql_query("SELECT MIN(CONCAT(LPAD((LEFT((no_masuk),6)),6,'0'))) FROM dis_masuk WHERE YEAR(tg_terima) = $thn1");
  $qr3	= mysql_query("SELECT MAX(CONCAT(LPAD((RIGHT((kodefile),4)+1),4,'0'))) FROM dis_masuk WHERE YEAR(tg_terima) = $thn1 AND kodelok = '$lok'");
  $qr4  = mysql_query("SELECT MIN(CONCAT(LPAD((RIGHT((kodefile),4)),4,'0'))) FROM dis_masuk WHERE YEAR(tg_terima) = $thn1 AND kodelok = '$lok'");
  $qr5	= mysql_query("SELECT MAX(CONCAT(LPAD((RIGHT((no_dispo),6)+1),6,'0'))) FROM dis_masuk WHERE YEAR(tg_terima) = $thn1");
  $qr6  = mysql_query("SELECT MIN(CONCAT(LPAD((RIGHT((no_dispo),6)),6,'0'))) FROM dis_masuk WHERE YEAR(tg_terima) = $thn1");
  $kde1= mysql_fetch_array($qr1);
  $kde2= mysql_fetch_array($qr2);
  $kde3= mysql_fetch_array($qr3);
  $kde4= mysql_fetch_array($qr4);
  $kde5= mysql_fetch_array($qr5);
  $kde6= mysql_fetch_array($qr6);
  
  if ($bln == '01'){
    $rbln = 'I';
  }
  elseif ($bln == '02'){
    $rbln = 'II';
  }
  elseif ($bln == '03'){
    $rbln = 'III';
  }
  elseif ($bln == '04'){
    $rbln = 'IV';
  }
  elseif ($bln == '05'){
    $rbln = 'V';
  }
  elseif ($bln == '06'){
    $rbln = 'VI';
  }
  elseif ($bln == '07'){
    $rbln = 'VII';
  }
  elseif ($bln == '08'){
    $rbln = 'VIII';
  }
  elseif ($bln == '09'){
    $rbln = 'IX';
  }
  elseif ($bln == '10'){
    $rbln = 'X';
  }
  elseif ($bln == '11'){
    $rbln = 'XI';
  }
  elseif ($bln == '12'){
    $rbln = 'XII';
  }
  
  if ($kde2[0] != '000001'){
       $nourut = '000001'.'/'.$kode.'/'.$rbln.'/'.$thn1;
    }
    else{
       $nourut = $kde1[0].'/'.$kode.'/'.$rbln.'/'.$thn1;
    }
  
  
  
 if ($kde4[0] != '0001'){
       $nofile = $lok.'.'.$thn.'0001';
    }
    else{
       $nofile = $lok.'.'.$thn.$kde3[0];
    }
    
 if ($kde6[0] != '000001'){
       $nodispo = 'DIS'.'.'.$thn.'.'.'000001';
    }
    else{
       $nodispo = 'DIS'.'.'.$thn.'.'.$kde5[0];
    }   
    
    $tsurat      = $_POST[thn_surat].'-'.$_POST[bln_surat].'-'.$_POST[tgl_surat];
  
  $allowed_ext = array('pdf','PDF');
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $file        = $_FILES['fupload']['name'];
  
  //cari extensi file dengan menggunakan fungsi explode
  $explode    = explode('.',$file);
  $file_ext   = $explode[count($explode)-1];
  
  $tipe_file   = $_FILES['fupload']['type'];
  $file_size   = $_FILES['fupload']['size'];
  
  $namafile    = $thn.'-'.$bln.'-'.$lok.'-'.$file;
  
  //tukuran maximum file yang dapat diupload
  $max_size   = 10000000; // 10MB
  $proses = 'DIPROSES';
  $cek = 1;
  
  // Apabila ada file yang diupload
  if (!empty($lokasi_file)){  
    if(in_array($file_ext, $allowed_ext) === true){
       UploadFileMasuk($namafile);
       // 1. INSERT Data Arsip Surat Masuk
       mysql_query("INSERT INTO dis_masuk(no_masuk,
                                    tg_terima,
                                    no_agenda,
                                    nomor,
                                    tg_surat, 
                                    no_surat,
                                    lamp, 
                                    perihal, 
                                    sifat, 
                                    kodejra, 
                                    kodelok,
                                    kodefile,
                                    no_dispo,
                                    utk_dispo, 
                                    dari_dispo,
                                    kodeunit,
                                    kd_ptgs,
                                    gambar) 
                             VALUES('$nourut', 
                                    '$tgl_sekarang', 
                                    '$_POST[no_agenda]',
                                    '$_POST[nomor]', 
                                    '$tsurat', 
                                    '$_POST[no_surat]', 
                                    '$_POST[lampiran]', 
                                    '$_POST[perihal]', 
                                    '$_POST[sifat]', 
                                    '$_POST[klas]', 
                                    '$_POST[lokasi]', 
                                    '$nofile', 
                                    '$nodispo', 
                                    '$_POST[utk_dispo]', 
                                    '$_SESSION[namauser]', 
                                    '$_SESSION[bagian]',  
                                    '$_SESSION[namauser]',
                                    '$namafile')");
 
 // 2. UDATE Data Penerimaan Surat Masuk
    mysql_query("UPDATE dis_masuk_agd SET nosurat   = '$_POST[no_surat]',
                                    lamp      = '$_POST[lampiran]', 
                                    perihal   = '$_POST[perihal]',
                                    status1   = 'DIPROSES',
                                    kunci     = '1'  
                              WHERE nomasuk   = '$agenda'");

 // 3. Jika tujuan disposisi tidak kosong, INSERT Detail Disposisi Surat Masuk
    if (!empty($dispo)){
    mysql_query("INSERT INTO dis_dispo_dt(tgdispo,
                                    nomasuk,
                                    noperus,
                                    no_dtdispo,
                                    isidispo,
                                    dari_dispo,
                                    untuk,
                                    kd_ptgs) 
                             VALUES('$tgl_jamsekarang',
                                    '$nourut',
                                    '$_POST[nomor]', 
                                    '$nodispo',
                                    '$_POST[perihal]',
                                    '$_SESSION[bagian]',
                                    '$_POST[utk_dispo]',  
                                    '$_SESSION[namauser]')");
    }
 }
    else{
		echo "<script>window.alert('Upload Gagal, Pastikan File yang di Upload bertipe *.PDF');
        window.location=('../../media.php?module=agendaarsip')</script>";
	}
  }
  else{
  // 1. INSERT Data Arsip Surat Masuk
  mysql_query("INSERT INTO dis_masuk(no_masuk,
                                    tg_terima,
                                    no_agenda,
                                    nomor,
                                    tg_surat, 
                                    no_surat,
                                    lamp, 
                                    perihal, 
                                    sifat, 
                                    kodejra, 
                                    kodelok,
                                    kodefile,
                                    no_dispo,
                                    utk_dispo, 
                                    dari_dispo,
                                    kodeunit,
                                    kd_ptgs) 
                             VALUES('$nourut', 
                                    '$tgl_sekarang', 
                                    '$_POST[no_agenda]',
                                    '$_POST[nomor]', 
                                    '$tsurat', 
                                    '$_POST[no_surat]', 
                                    '$_POST[lampiran]', 
                                    '$_POST[perihal]', 
                                    '$_POST[sifat]', 
                                    '$_POST[klas]', 
                                    '$_POST[lokasi]', 
                                    '$nofile', 
                                    '$nodispo', 
                                    '$_POST[utk_dispo]', 
                                    '$_SESSION[namauser]', 
                                    '$_SESSION[bagian]',  
                                    '$_SESSION[namauser]')");
  
  // 2. UDATE Data Penerimaan Surat Masuk
    mysql_query("UPDATE dis_masuk_agd SET nosurat   = '$_POST[no_surat]',
                                    lamp      = '$_POST[lampiran]', 
                                    perihal   = '$_POST[perihal]',
                                    status1   = 'DIPROSES',
                                    kunci     = '1'   
                              WHERE nomasuk   = '$agenda'");
  
  // 3. Jika tujuan disposisi tidak kosong, INSERT Detail Disposisi Surat Masuk
    if (!empty($dispo)){
    mysql_query("INSERT INTO dis_dispo_dt(tgdispo,
                                    nomasuk,
                                    noperus,
                                    no_dtdispo,
                                    isidispo,
                                    dari_dispo,
                                    untuk,
                                    kd_ptgs) 
                             VALUES('$tgl_jamsekarang',
                                    '$_POST[no_agenda]',
                                    '$_POST[nomor]', 
                                    '$nodispo',
                                    '$_POST[perihal]',
                                    '$_SESSION[bagian]',
                                    '$_POST[utk_dispo]',  
                                    '$_SESSION[namauser]')");
    }
  }
  header('location:../../media.php?module='.$module);
}

// Update Data Arsip
elseif ($module=='agendaarsip' AND $act=='update'){
  $kode   = $_POST[klas];
  $lok    = $_POST[lokasi];
  $agenda = $_POST[no_agenda];
  $dispo  = $_POST[no_dispo];
  $thn = date("y"); //tahun 2 digit
	$bln = date("m"); //bulan 2 digit
	$thn1= date("Y"); //tahun 4 digit
  $allowed_ext = array('pdf','PDF');
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $file        = $_FILES['fupload']['name'];
  
  //cari extensi file dengan menggunakan fungsi explode
  $explode    = explode('.',$file);
  $file_ext   = $explode[count($explode)-1];
  
  $tipe_file   = $_FILES['fupload']['type'];
  $file_size   = $_FILES['fupload']['size'];
  
  $namafile    = $thn.'-'.$bln.'-'.$lok.'-'.$file;
  
  //tukuran maximum file yang dapat diupload
  $max_size   = 10000000; // 10MB
  $proses = 'DIPROSES';
  $cek = 1;
    
  $tsurat      = $_POST[thn_surat].'-'.$_POST[bln_surat].'-'.$_POST[tgl_surat];
  
  ///////////////////////////////// Apabila file tidak diganti
  if (empty($lokasi_file)){
  // 1. UDATE Data Arsip Surat Masuk
  mysql_query("UPDATE dis_masuk SET tg_surat  = '$tsurat', 
                                    no_surat  = '$_POST[no_surat]',
                                    lamp      = '$_POST[lampiran]', 
                                    perihal   = '$_POST[perihal]', 
                                    sifat     = '$_POST[sifat]', 
                                    kodejra   = '$_POST[klas]', 
                                    kodelok   = '$_POST[lokasi]', 
                                    utk_dispo = '$_POST[utk_dispo]',
                                    kodefile  = '$_POST[kodefile]',
                                    status1   = '$_POST[status1]'
                              WHERE idmasuk   = '$_POST[id]'");
  
  // 2. UDATE Data Penerimaan Surat Masuk
    mysql_query("UPDATE dis_masuk_agd SET nosurat   = '$_POST[no_surat]',
                                    lamp      = '$_POST[lampiran]', 
                                    perihal   = '$_POST[perihal]',
                                    status1   = 'DIPROSES',
                                    kunci     = '1'   
                              WHERE nomasuk   = '$agenda'");
  
  // 3. Jika tujuan disposisi kosong, INSERT Detail Disposisi Surat Masuk
    if (empty($dispo)){
    mysql_query("INSERT INTO dis_dispo_dt(tgdispo,
                                    nomasuk,
                                    noperus,
                                    no_dtdispo,
                                    isidispo,
                                    dari_dispo,
                                    untuk,
                                    kd_ptgs) 
                             VALUES('$tgl_jamsekarang',
                                    '$_POST[no_masuk]',
                                    '$_POST[nomor]', 
                                    '$_POST[no_dispo]',
                                    '$_POST[perihal]',
                                    '$_SESSION[bagian]',
                                    '$_POST[utk_dispo]',  
                                    '$_SESSION[namauser]')");
    }  
    else{
       mysql_query("UPDATE dis_dispo_dt SET no_dtdispo = '$_POST[no_dispo]',
                                    nosurat   = '$_POST[no_surat]',
                                    isidispo  = '$_POST[perihal]'
                              WHERE nomasuk   = '$agenda'");
    }                              
  }
  else{
  //check apakah type file sudah sesuai
   if(in_array($file_ext, $allowed_ext) === true){
     $data_file = mysql_query("SELECT gambar FROM dis_masuk WHERE idmasuk='$_POST[id]'");
	   $z    	= mysql_fetch_array($data_file);
     @unlink('fileupload/masuk/'.$z['gambar']);
		
   	 UploadFileMasuk($namafile);
   	 // 1. UDATE Data Arsip Surat Masuk
     mysql_query("UPDATE dis_masuk SET tg_surat  = '$tsurat', 
                                    no_surat  = '$_POST[no_surat]',
                                    lamp      = '$_POST[lampiran]', 
                                    perihal   = '$_POST[perihal]', 
                                    sifat     = '$_POST[sifat]', 
                                    kodejra   = '$_POST[klas]', 
                                    kodelok   = '$_POST[lokasi]', 
                                    utk_dispo = '$_POST[utk_dispo]',
                                    kodefile  = '$_POST[kodefile]',
                                    gambar    = '$namafile', 
                                    status1   = '$_POST[status1]'
                              WHERE idmasuk   = '$_POST[id]'");
    
    // 2. UDATE Data Penerimaan Surat Masuk
    mysql_query("UPDATE dis_masuk_agd SET nosurat   = '$_POST[no_surat]',
                                    lamp      = '$_POST[lampiran]', 
                                    perihal   = '$_POST[perihal]',
                                    status1   = 'DIPROSES',
                                    kunci     = '1' 
                              WHERE nomasuk   = '$agenda'");
                              
  // 3. Jika tujuan disposisi kosong, INSERT Detail Disposisi Surat Masuk
    if (empty($dispo)){
    mysql_query("INSERT INTO dis_dispo_dt(tgdispo,
                                    nomasuk,
                                    noperus,
                                    no_dtdispo,
                                    isidispo,
                                    dari_dispo,
                                    untuk,
                                    kd_ptgs) 
                             VALUES('$tgl_jamsekarang',
                                    '$_POST[no_masuk]',
                                    '$_POST[nomor]', 
                                    '$_POST[no_dispo]',
                                    '$_POST[perihal]',
                                    '$_SESSION[bagian]',
                                    '$_POST[utk_dispo]',  
                                    '$_SESSION[namauser]')");
    }  
  }
    else{
		echo "<script>window.alert('Upload Gagal, Pastikan File yang di Upload bertipe *.PDF');
        window.location=('../../media.php?module=agendaarsip')</script>";
	}
  }
  header('location:../../media.php?module='.$module);
}
}

?>
