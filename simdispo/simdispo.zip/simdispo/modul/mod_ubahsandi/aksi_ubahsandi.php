<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../config/koneksi.php";
include "../../config/fungsi_thumb.php";

$module=$_GET[module];
$act=$_GET[act];

// Update Katasandi
if ($module=='ubahsandi' AND $act=='update'){
 
   $r=mysql_fetch_array(mysql_query("SELECT * FROM dis_pemakai WHERE kode_ptgs='$_SESSION[namauser]' "));

  $pass_lama=md5($_POST[password_lama]);
  $pass_baru=md5($_POST[password_baru]);

  
  // Apabila password lama cocok dengan password admin di database
  if ($pass_lama==$r[password]){
  // Pastikan bahwa password baru yang dimasukkan sebanyak dua kali sudah cocok
     if ($_POST[password_baru]==$_POST[password_ulangi]){
        mysql_query("UPDATE dis_pemakai SET password = '$pass_baru' WHERE kode_ptgs = '$_SESSION[namauser]' ");
       header('location:../../media.php?module=home');
      }
      else{
        echo "<p align=center>Password baru yang Anda masukkan sebanyak dua kali belum cocok.<br />"; 
        echo "<a href=javascript:history.go(-1)><b>Ulangi Lagi</b></a></p>";  
      }
  }
  else{
      echo "<p align=center>Anda salah memasukkan Password Lama Anda.<br />"; 
      echo "<a href=javascript:history.go(-1)><b>Ulangi Lagi</b></a></p>";
  }
 
}
}
?>
