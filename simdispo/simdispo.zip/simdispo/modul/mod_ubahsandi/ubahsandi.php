<script>
function validasi(form){
		  if (form.nama_ptgs.value == ""){
			alert("Anda belum mengisi Nama User.");
			form.nama_ptgs.focus();
			return (false);
		  }
		  if (form.password_lama.value == ""){
			alert("Anda belum mengisi Password Lama.");
			form.password_lama.focus();
			return (false);
		  }
		  
		  if (form.password_baru.value == ""){
			alert("Anda belum mengisi Password Baru.");
			form.password_baru.focus();
			return (false);
		  }
		  if (form.password_ulangi.value == ""){
			alert("Anda belum mengisi Ulangi Password.");
			form.password_ulangi.focus();
			return (false);
		  }
		  return (true);
}
</script>

  <?php
  $aksi="modul/mod_ubahsandi/aksi_ubahsandi.php";
  switch($_GET[act]){
  // Tampil ubah sandi
  default:
    $sql  = mysql_query("SELECT * FROM dis_pemakai WHERE kode_ptgs='$_SESSION[namauser]' LIMIT 1");
    $r    = mysql_fetch_array($sql);

  
   echo "
   <div id='main-content'>
   <div class='container_12'>
   <div class='grid_12'>
   </div>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   <h1>UBAH KATA SANDI</h1>
   <span></span> 
   </div>
   <div class='block-content'>
  
    <form onSubmit='return validasi(this)' id='formpassword' 
    method=POST enctype='multipart/form-data' action=$aksi?module=ubahsandi&act=update>
    <input type=hidden name=id value=$r[id_session]>
		  
    <p class=inline-small-label> 
    <label for=field4>ID User</label>
  	<input type=text name='kode_ptgs' value='$r[kode_ptgs]' disabled>
    </p> 
	
    <p class=inline-small-label> 
    <label for=field4>Nama User</label>
    <input type=text name='nama_ptgs' value='$r[nama_ptgs]' resquired setfocus>
    </p> 
     
    <p class=inline-small-label> 
    <label for=field4>Password Lama</label>
	  <input type=password name='password_lama' resquired>
    </p> 
	  
	  <p class=inline-small-label> 
    <label for=field4>Password Baru</label>
	  <input type=password name='password_baru' resquired>
    </p> 
    
    <p class=inline-small-label> 
    <label for=field4>Ulangi Password</label>
	  <input type=password name='password_ulangi' resquired>
    </p><br> 
    
    <div class=block-actions> 
      <ul class=actions-right> 
      <li>
      <a class='button red' id=reset-validate-form href='?module=home'>Batal</a>
      </li> </ul>
      <ul class=actions-left> 
      <li>
      <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	  </form>";
	
    break;  

  }
  ?>


   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>
