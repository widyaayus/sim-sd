<script>
function confirmdelete(delUrl) {
   if (confirm("Apakah Anda Yakin Ingin Menghapus Data User Ini?")) {
      document.location = delUrl;
   }
}
</script>

<script>
function validasi(form){
		  if (form.kode_ptgs.value == ""){
			alert("Anda belum mengisi Bagian ID User.");
			form.kode_ptgs.focus();
			return (false);
		  }
		  if (form.nama_ptgs.value == ""){
			alert("Anda belum mengisi Bagian Nama User.");
			form.nama_ptgs.focus();
			return (false);
		  }
		  if (form.gustu.value == 0){
			alert("Anda belum mengisi Bagian Unit.");
			form.gustu.focus();
			return (false);
		  }
		  if (form.hakakses.value == 0){
			alert("Anda belum mengisi Bagian Hak Akses.");
			form.hakakses.focus();
			return (false);
		  }
		  
		  return (true);
}
</script>

<?php    
session_start();
//Deteksi hanya bisa diinclude, tidak bisa langsung dibuka (direct open)
if(count(get_included_files())==1)
{
	echo "<meta http-equiv='refresh' content='0; url=http://$_SERVER[HTTP_HOST]'>";
	exit("Direct access not permitted.");
}
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

//cek hak akses user
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 
    OR $_SESSION['leveluser']=='admin'  
    OR $_SESSION['leveluser']=='direksi' 
    OR $_SESSION['leveluser']=='pejabat'
	  OR $_SESSION['leveluser']=='arsiparis'
	  OR $_SESSION['leveluser']=='resepsionis'
    OR $_SESSION[leveluser]=='user'){
	   
   $aksi="modul/mod_utiusers/aksi_utiusers.php";
   switch($_GET[act]){
   
   // Tampil User
   default:
   echo "";

   if (empty($_GET['kata'])){
      if ($_SESSION['leveluser']=='admin'){
	    echo "
	    <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>MANAJEMEN USER DAN HAK AKSES</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=user&act=tambahuser' class='button'>
        <span>Tambahkan User</span></a>
        </div>
	      <table id='table-example' class='table'>
      <thead><tr>
  
      <th>No.</th> 
      <th>ID User</th>
      <th>Nama Lengkap</th> 
	    <th>ID Unit</th> 
      <th>Hak Akses</th>
      <th>Foto</th>
      <th>Blokir</th> 
      <th>Aksi</th>
      </tr> 
      </thead>
      <tbody>";

      $p      = new Paging;
      $batas  = 15;
      $posisi = $p->cariPosisi($batas);
      
      $tampil = mysql_query("SELECT * FROM dis_pemakai ORDER BY id_session DESC");
      
	  $no = $posisi+1;
      while($r=mysql_fetch_array($tampil)){
      $lebar=strlen($no);
      switch($lebar){
      case 1:
      {
        $g="00".$no;
        break;     
      }
      case 2:
      {
        $g="0".$no;
        break;     
      }
      case 3:
      {
        $g=$no;
        break;     
      }      
    } 
	
    echo "<tr class=gradeX> 
   
    <td width=50><center>$g</center></td>
    <td>$r[kode_ptgs]</td>
    <td>$r[nama_ptgs]</td>
    <td>$r[kode_unit]</td>
	  <td>$r[level]</td>
    <td width=80><center><img src='foto_user/small_$r[foto]' width=30></center></td>
    <td align=center width=40><center>$r[blokir]</center></td>
	<td valign=middle width=50>
	<a href=?module=user&act=edituser&id=$r[id_session] rel=tooltip-top title='Edit' class='with-tip'>
    <img src='img/edit.png'></a> 
    <a href=javascript:confirmdelete('$aksi?module=user&act=hapus&id=$r[id_session]')
   title='Hapus' class='with-tip'>&nbsp;<img src='img/hapus.png'></center></a> 
    </td> </tr> ";
  
    $no++; }
	
   echo "</tbody></table> ";

   break;  
  
  }
  
  else{
   echo "
      <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>MANAJEMEN USER DAN HAK AKSES</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        </div>
	      <table id='table-example' class='table'>
        <thead><tr>
  
      <th>No.</th> 
      <th>Nama Lengkap</th> 
	    <th>Foto</th>
      <th>Aksi</th>
      </tr> 
      </thead>
      <tbody>";

      $p      = new Paging;
      $batas  = 15;
      $posisi = $p->cariPosisi($batas);
      
      $tampil=mysql_query("SELECT * FROM dis_pemakai WHERE kode_ptgs='$_SESSION[namauser]'");
      
      $no = $posisi+1;
      while($r=mysql_fetch_array($tampil)){
      $lebar=strlen($no);
      switch($lebar){
      case 1:
      {
        $g="00".$no;
        break;     
      }
      case 2:
      {
        $g="0".$no;
        break;     
      }
      case 3:
      {
        $g=$no;
        break;     
      }      
    } 
	
    echo "<tr class=gradeX> 
    <td width=50><center>$g</center></td>
    <td>$r[nama_ptgs]</td>
    <td width=40><center><img src='foto_user/small_$r[foto]' width=50></center></td>
    <td valign=middle width=50>
	<a href=?module=user&act=edituser&id=$r[id_session] rel=tooltip-top title='Edit' class='with-tip'>
    <img src='img/edit.png'></a>   
    </td> </tr> ";
  
    $no++; }
	
   echo "</tbody></table> ";

   break;  }
   }
  

   //--INPUT USER -------------  
   case "tambahuser":
   
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>TAMBAH PROFIL USER</h1>
   </div>
   <div class='block-content'>
   
   <form onSubmit='return validasi(this)' id='formutiuser' 
   method=POST action='$aksi?module=user&act=input' enctype='multipart/form-data'>
	  
   <p class=inline-small-label> 
   <label for=field4>ID User</label>
   <input type=text name='kode_ptgs'>
   </p> 
	 	  
   <p class=inline-small-label> 
   <label for=field4>Kata Sandi</label>
   <input type=password name='password'>
   </p> 

   <p class=inline-small-label> 
   <label for=field4>Nama User</label>
   <input type=text name='nama_ptgs'>
   </p> 
	 	  
   <p class=inline-small-label> 
   <label for=field4>E-mail</label>
   <input type=text name='email'>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>No.Telp/HP</label>
   <input type=text name='phone'>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Unit</label>
   <select name='gustu'>
   <option value=0 selected>Pilih Unit</option>";
   $tampil=mysql_query("SELECT * FROM dis_unit ORDER BY id_unit");
   while($r=mysql_fetch_array($tampil)){
   echo "<option value=$r[id_unit]>$r[nm_jbtan] - [$r[id_unit]]</option></p>"; }
   
   echo "</select>";
   
   echo " 
   <p class=inline-small-label> 
   <label for=field4>Hak Akses</label>
   <select name='hakakses'>
   <option value=0 selected>Pilih Hak Akses</option>";
   $tampil=mysql_query("SELECT * FROM dis_pemakai_level ORDER BY id_level");
   while($r=mysql_fetch_array($tampil)){
   echo "<option value=$r[kode_level]>$r[nama_level]</option></p>"; }
   
   echo "</select>";
   
   echo "
   <p class=inline-small-label> 
   <span class=label>Upload Foto</span>
   <input type='file' name='fupload' /><br/>
   </p><br/>";
	  

   echo "<br/><br/><div class=block-actions> 
    <ul class=actions-right> 
    <li>
    <a class='button red' id=reset-validate-form href='?module=user'>Batal</a>
    </li> </ul>
    <ul class=actions-left> 
    <li>
   <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
   </form>";
	 
   break;
   
   //--EDIT USER -------------
   case "edituser":
   $edit=mysql_query("SELECT * FROM dis_pemakai WHERE id_session='$_GET[id]'");
   $r=mysql_fetch_array($edit);

   //----- AWAL leveluser admin----------
   if($_SESSION['leveluser']=='admin'){	  
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>EDIT PROFIL USER</h1>
   </div>
   <div class='block-content'>
     
   <form onSubmit='return validasi(this)' id='formutiuser' 
   method=POST action='$aksi?module=user&act=update' enctype='multipart/form-data'>
   <input type=hidden name=id value=$r[id_session]>
   <input type=hidden name=blokir value='$r[blokir]'>
	  
   <p class=inline-small-label> 
   <label for=field4>ID User</label>
   <input type=text name='kode_ptgs' value='$r[kode_ptgs]' disabled>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Kata Sandi</label>
   <input type=password name='password'>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Nama User</label>
   <input type=text name='nama_ptgs' value='$r[nama_ptgs]'>
   </p> 
	 
   <p class=inline-small-label> 
   <label for=field4>E-mail</label>
   <input type=text name='email' value='$r[email]'>
   </p> 
	 
   <p class=inline-small-label> 
   <label for=field4>No.Telp/HP</label>
   <input type=text name='phone' value='$r[phone]'>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Unit</label>
   <select name='gustu'>";
   $tampil1=mysql_query("SELECT * FROM dis_unit ORDER BY id_unit");
   if ($r[id_unit]==0){
   echo "<option value=0 selected>- Pilih Unit -</option>"; }   

   while($x=mysql_fetch_array($tampil1)){
   if ($r[kode_unit]==$x[id_unit]){
   echo "<option value=$x[id_unit] selected>$x[nm_jbtan] - [$x[id_unit]]</option>";}
   else{
   echo "<option value=$x[id_unit]>$x[nm_jbtan] - [$x[id_unit]]</option> </p> ";}}
   echo "</select>";

   echo "
   <p class=inline-small-label> 
   <label for=field4>Hak Akses</label>
   <select name='hakakses'>";
   $tampil3=mysql_query("SELECT * FROM dis_pemakai_level ORDER BY id_level");
   if ($r[level]==0){
   echo "<option value='user' selected>- Pilih Hak Akses -</option>"; }   

   while($z=mysql_fetch_array($tampil3)){
   if ($r[level]==$z[kode_level]){
   echo "<option value=$z[kode_level] selected>$z[nama_level]</option>";}
   else{
   echo "<option value=$z[kode_level]>$z[nama_level]</option> </p> ";}}
   echo "</select><br />";
   
   if ($r[cekarsiparis]==0){
      echo "
      <p class=inline-small-label> 
      <label for=field4>Arsiparis</label>
      <input type=radio name='cekarsiparis' value= 1 > Ya   
      <input type=radio name='cekarsiparis' value= 0 checked> Tidak </p>";
    }
    else{
      echo "
      <p class=inline-small-label> 
      <label for=field4>Arsiparis</label>
      <input type=radio name='cekarsiparis' value= 1 checked> Ya  
      <input type=radio name='cekarsiparis' value= 0 > Tidak</p>";
  }
   
   if ($r[cekfrontline]==0){
      echo "
      <p class=inline-small-label> 
      <label for=field4>Resepsionis</label>
      <input type=radio name='cekfrontline' value= 1 > Ya   
      <input type=radio name='cekfrontline' value= 0 checked> Tidak </p>";
    }
    else{
      echo "
      <p class=inline-small-label> 
      <label for=field4>Resepsionis</label>
      <input type=radio name='cekfrontline' value= 1 checked> Ya  
      <input type=radio name='cekfrontline' value= 0 > Tidak</p>";
    }
      
   echo "
   <p class=inline-small-label> 
   <label for=field4>Foto</label>
   <img src='foto_user/small_$r[foto]' width=100>
   </p>   
    
   <p class=inline-small-label> 
   <span class=label>Ganti Foto</span>
   <input type='file' name='fupload' />
   </p>";
	
	if ($r[blokir]=='N'){
      echo "
      <p class=inline-small-label> 
      <label for=field4>Blokir</label>
      <input type=radio name='blokir' value='Y'> Ya   
      <input type=radio name='blokir' value='N' checked> Tidak </p>";}
    else{
      echo "
      <p class=inline-small-label> 
      <label for=field4>Blokir</label>
      <input type=radio name='blokir' value='Y' checked> Ya  
      <input type=radio name='blokir' value='N'> Tidak </p><br />";
    }
	
	echo "";
	echo "<br/><br/><div class=block-actions> 
    <ul class=actions-right> 
    <li>
    <a class='button red' id=reset-validate-form href='?module=user'>Batal</a>
    </li> </ul>
    <ul class=actions-left> 
    <li>
    <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	</form>";
    }
	
   else {
	   
   //----- Hak Akses bukan Admin ----------
  		  
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>EDIT DATA PROFIL USER</h1>
   </div>
   <div class='block-content'>
     
   <form onSubmit='return validasi(this)' id='formutiuser' method=POST action='$aksi?module=user&act=update' enctype='multipart/form-data'>
   <input type=hidden name=id value=$r[id_session]>
   <input type=hidden name=blokir value='$r[blokir]'>
	  
   <p class=inline-small-label> 
   <label for=field4>ID User</label>
   <input type=text name='kode_ptgs' value='$r[kode_ptgs]' disabled>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Nama User</label>
   <input type=text name='nama_ptgs' value='$r[nama_ptgs]'>
   </p> 
	 
   <p class=inline-small-label> 
   <label for=field4>E-mail</label>
   <input type=text name='email' value='$r[email]'>
   </p> 
	 
   <p class=inline-small-label> 
   <label for=field4>No.Telp/HP</label>
   <input type=text name='phone' value='$r[phone]'>
   </p> 
   <p class=inline-small-label> 
   <label for=field4>Foto</label>
   <img src='foto_user/small_$r[foto]' width=100>
   </p>   
    
   <p class=inline-small-label> 
   <span class=label>Ganti Foto</span>
   <input type='file' name='fupload' /><br/>
   </p><br/>";
   
    echo "<br/><br/><div class=block-actions> 
    <ul class=actions-right> 
    <li>
    <a class='button red' id=reset-validate-form href='?module=user'>Batal</a>
    </li> </ul>
    <ul class=actions-left> 
    <li>
   <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	</form>";}     
	
    break;  
   }
   //kurawal akhir hak akses module
   } else {
	echo akses_salah();
   }

   }
   ?>


   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>
