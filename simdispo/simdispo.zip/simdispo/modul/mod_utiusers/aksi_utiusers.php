<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../config/koneksi.php";
include "../../config/fungsi_thumb.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus User
  if ($module=='user' AND $act=='hapus'){
   mysql_query("DELETE FROM dis_pemakai WHERE id_session='$_GET[id]'");
  
  header('location:../../media.php?module='.$module);
  }
// Penutup Hapus
  
// Input user  
  if ($module=='user' AND $act=='input'){
  //Jika Hak Akses 'admin'
  
  if ($_SESSION['leveluser']=='admin'){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 
  
  $pass=md5($_POST[password]);
  $unik=md5($_POST[kode_ptgs]);
  
  // Apabila ada foto yang diupload
  if (!empty($lokasi_file)){
  UploadUser($nama_file_unik);
  mysql_query("INSERT INTO dis_pemakai(kode_ptgs,
                           password,
                           nama_ptgs,
                           email, 
                           phone,
                           kode_unit,
                           level,
				                   foto,
                           id_session) 
	                  VALUES('$_POST[kode_ptgs]',
                           '$pass',
                           '$_POST[nama_ptgs]',
                           '$_POST[email]',
                           '$_POST[phone]',
                           '$_POST[gustu]',
				                   '$_POST[hakakses]',
                           '$nama_file_unik',
                           '$unik')");
 
  header('location:../../media.php?module='.$module);
  }
  else{
  mysql_query("INSERT INTO dis_pemakai(kode_ptgs,
                           password,
                           nama_ptgs,
                           email, 
                           phone,
                           kode_unit,
                           level,
                           id_session) 
	                  VALUES('$_POST[kode_ptgs]',
                           '$pass',
                           '$_POST[nama_ptgs]',
                           '$_POST[email]',
                           '$_POST[phone]',
                           '$_POST[gustu]',
                           '$_POST[hakakses]',
                           '$unik')");
  
  header('location:../../media.php?module='.$module);
}
} // Penutup Admin
} //Penutup dari Input

// Update user
if ($module=='user' AND $act=='update') {
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 
  
  if (empty($lokasi_file)){ 
             if ($_SESSION['leveluser']=='admin'){
                 mysql_query("UPDATE dis_pemakai SET   
						                nama_ptgs   = '$_POST[nama_ptgs]',
                            email       = '$_POST[email]',
                            phone       = '$_POST[phone]',
                            kode_unit   = '$_POST[gustu]',
                            level       = '$_POST[hakakses]',
                            cekarsiparis= '$_POST[cekarsiparis]',
                            cekfrontline= '$_POST[cekfrontline]',
                            blokir      = '$_POST[blokir]'
                   WHERE  id_session  = '$_POST[id]'");
            }
            else{
                 mysql_query("UPDATE dis_pemakai SET   
						                nama_ptgs   = '$_POST[nama_ptgs]',
                            email       = '$_POST[email]',
                            phone       = '$_POST[phone]'
                   WHERE  id_session  = '$_POST[id]'");
            }
        } //Penutup Foto Tidak diubah
        
  else{
         //B2. ---------jika password tidak diubah tetapi foto diubah
	        $data_foto = mysql_query("SELECT foto FROM dis_pemakai WHERE id_session='$_POST[id]'");
	        $r    	= mysql_fetch_array($data_foto);
	        @unlink('../../foto_user/'.$r['foto']);
	        @unlink('../../foto_user/'.'small_'.$r['foto']);
          UploadUser($nama_file_unik);
          
          if ($_SESSION['leveluser']=='admin'){
              mysql_query("UPDATE dis_pemakai SET 
					                nama_ptgs   = '$_POST[nama_ptgs]',
                          email       = '$_POST[email]',
                          phone       = '$_POST[phone]',
                          kode_unit   = '$_POST[gustu]',
                          level       = '$_POST[hakakses]',
                          cekarsiparis= '$_POST[cekarsiparis]',
                          cekfrontline= '$_POST[cekfrontline]',
                          foto        = '$nama_file_unik',
                          blokir      = '$_POST[blokir]'
                  WHERE id_session  = '$_POST[id]'");
          }
          else{
          mysql_query("UPDATE dis_pemakai SET 
					                nama_ptgs   = '$_POST[nama_ptgs]',
                          email       = '$_POST[email]',
                          phone       = '$_POST[phone]',
                          foto        = '$nama_file_unik'
                  WHERE id_session  = '$_POST[id]'");
          }
       }  //Penutup Jika Foto diubah
       
  header('location:../../media.php?module='.$module);

}  //penutup Edit
} //penutup If awal (1)
?>
