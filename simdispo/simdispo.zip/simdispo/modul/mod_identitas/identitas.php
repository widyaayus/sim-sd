  <?php
  $aksi="modul/mod_identitas/aksi_identitas.php";
  switch($_GET[act]){
  // Tampil identitas
  default:
    $sql  = mysql_query("SELECT * FROM dis_identitas LIMIT 1");
    $r    = mysql_fetch_array($sql);

  
   echo "
   <div id='main-content'>
   <div class='container_12'>
   <div class='grid_12'>
   </div>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   <h1>IDENTITAS PERUSAHAAN</h1>
   <span></span> 
   </div>
   <div class='block-content'>
  
    <form method=POST enctype='multipart/form-data' action=$aksi?module=identitas&act=update>
    <input type=hidden name=id value=$r[id_identitas]>
		  
    <p class=inline-small-label> 
    <label for=field4>Kode</label>
	<input type=text name='kode_rs' value='$r[kode_rs]'>
    </p> 
	
	<p class=inline-small-label> 
    <label for=field4>Nama </label>
	<input type=text name='nama_rs' value='$r[nama_rs]'>
    </p> 
	
    <p class=inline-small-label> 
    <label for=field4>Alamat</label>
    <input type=text name='alamat' value='$r[alamat]'>
    </p> 
        
    <p class=inline-small-label> 
    <label for=field4>Kota/Kabupaten</label>
	<input type=text name='kota' value='$r[kota]'>
    </p> 
    
	  <p class=inline-small-label> 
    <label for=field4>Kode Pos</label>
	  <input type=text name='kodepos' value='$r[kodepos]'>
    </p>
   	<p class=inline-small-label> 
    <label for=field4>No. Telp/HP</label>
	<input type=text name='no_telp' value='$r[no_telp]'>
    </p>
	
	<p class=inline-small-label> 
    <label for=field4>Email</label>
	<input type=text name='email' value='$r[email]'>
    </p>
 	
	<p class=inline-small-label> 
    <label for=field4>Website</label>
	<input type=text name='url' value='$r[url]'>
    </p>	  
	
    <p class=inline-small-label> 
    <label for=field4>Pimpinan</label>
	<input type=text name='namadir' value='$r[namadir]'>
    </p>
	
	<p class=inline-small-label> 
    <label for=field4>Jabatan</label>
	<input type=text name='jabatan' value='$r[jabatan]'>
    </p>
	
	<p class=inline-small-label> 
	<span class=label>Gambar Logo</span>";
    if ($r[logo]!=''){
    echo "&nbsp;&nbsp;&nbsp;&nbsp;<img src=logo/$r[logo] width=100><br/><br/>"; 
		
	echo "</p>
      <p class=inline-small-label> 
	  <span class=label>Ganti Logo</span>
	  <input type='file' name='fupload' /><br/>
	  <span class style=\"font-size:11px;color:#666;\">&nbsp;&nbsp;&nbsp;&nbsp;
	  (Ekstensi file gambar harus <b>PNG, JPG)</b></span></p><br/>";

    echo "<div class=block-actions> 
      <ul class=actions-right> 
      <li>
      <a class='button red' id=reset-validate-form href='?module=home'>Batal</a>
      </li> </ul>
      <ul class=actions-left> 
      <li>
      <input type='submit' name='fupload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	  </form>";
	
    break;  
   }

  }
  ?>


   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>
