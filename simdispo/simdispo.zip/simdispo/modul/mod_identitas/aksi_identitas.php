<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../config/koneksi.php";
include "../../config/fungsi_thumb.php";

$module=$_GET[module];
$act=$_GET[act];

// Update identitas
if ($module=='identitas' AND $act=='update'){
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $nama_file   = $_FILES['fupload']['name'];

  // Apabila ada gambar yang diupload
  if (!empty($lokasi_file)){
    UploadLogo($nama_file);
    mysql_query("UPDATE dis_identitas SET kode_rs   = '$_POST[kode_rs]',
	                                  nama_rs   = '$_POST[nama_rs]',
									  alamat    = '$_POST[alamat]',
	                                  kota      = '$_POST[kota]',
	                                  kodepos   = '$_POST[kodepos]',
									  no_telp   = '$_POST[no_telp]',
									  email     = '$_POST[email]',
	                                  url       = '$_POST[url]',
								      namadir   = '$_POST[namadir]',
                                      jabatan   = '$_POST[jabatan]',
                                      logo      = '$nama_file'    
                                WHERE id_identitas   = '$_POST[id]'");
  }
  else{
    mysql_query("UPDATE dis_identitas SET kode_rs   = '$_POST[kode_rs]',
	                                  nama_rs   = '$_POST[nama_rs]',
									  alamat    = '$_POST[alamat]',
	                                  kota      = '$_POST[kota]',
	                                  kodepos   = '$_POST[kodepos]',
									  no_telp   = '$_POST[no_telp]',
									  email     = '$_POST[email]',
	                                  url       = '$_POST[url]',
								      namadir   = '$_POST[namadir]',
                                      jabatan   = '$_POST[jabatan]'
                                WHERE id_identitas   = '$_POST[id]'");
  }
  header('location:../../media.php?module='.$module);
}
}
?>
