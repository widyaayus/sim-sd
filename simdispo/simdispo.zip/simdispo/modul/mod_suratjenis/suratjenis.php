<script>
function confirmdelete(delUrl) {
   if (confirm("Apakah Anda Yakin Ingin Menghapus Data Jenis Surat Ini?")) {
      document.location = delUrl;
   }
}
</script>
<script>
function validasi(form){
		  if (form.kode_jns.value == ""){
			alert("Anda belum mengisi Kode.");
			form.kode_jns.focus();
			return (false);
		  }
		  if (form.ket_jns.value == ""){
			alert("Anda belum mengisi Keterangan.");
			form.ket_jns.focus();
			return (false);
		  }
		  
		  return (true);
}
</script>

<?php    
session_start();
//Deteksi hanya bisa diinclude, tidak bisa langsung dibuka (direct open)
if(count(get_included_files())==1)
{
	echo "<meta http-equiv='refresh' content='0; url=http://$_SERVER[HTTP_HOST]'>";
	exit("Direct access not permitted.");
}
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

//cek hak akses user
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 
   OR $_SESSION['leveluser']=='admin'){
	   
   $aksi="modul/mod_suratjenis/aksi_suratjenis.php";
   switch($_GET[act]){
   
   // Tampil Kategori Surat
   default:
   echo "";
   
   if (empty($_GET['kata'])){
      echo "
      <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DAFTAR JENIS SURAT</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=jenissurat&act=tambah' class='button'>
        <span>Tambahkan Jenis Surat</span></a>
        </div>
	      <table id='table-example' class='table'>
       <thead><tr>
      <th>No.</th> 
      <th>Kode</th>
	    <th>Keterangan</th> 
	    <th>Aksi</th>
      </tr> 
      </thead>
      <tbody>";

      $p      = new Paging;
      $batas  = 15;
      $posisi = $p->cariPosisi($batas);
      
      $tampil = mysql_query("SELECT * FROM dis_surat_jenis ORDER BY id_jns");
      
      $no = $posisi+1;
      while($r=mysql_fetch_array($tampil)){
      $lebar=strlen($no);
      switch($lebar){
      
      case 1:
      {
        $g="0".$no;
        break;     
      }
      case 2:
      {
        $g=$no;
        break;     
      }      
    } 
	  
	  echo "<tr class=gradeX> 
   
    <td width=50><center>$g</center></td>
    <td>$r[kode_jns]</td>
	  <td>$r[ket_jns]</td>
	  <td valign=middle width=80>
	  <a href=?module=jenissurat&act=edit&id=$r[id_jns] rel=tooltip-top title='Edit' class='with-tip'>
    <center><img src='img/edit.png'></a> 
	<a href=javascript:confirmdelete('$aksi?module=jenissurat&act=hapus&id=$r[id_jns]') title='Hapus' class='with-tip'>
       &nbsp;&nbsp;<img src='img/hapus.png'></center></a>
   
    </td> </tr> ";
  
    $no++; }
	
   echo "</tbody></table> ";

   break; 
  }

   //--INPUT Jenis Surat -------------  
   case "tambah":
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>TAMBAH JENIS SURAT</h1>
   </div>
   <div class='block-content'>
   
   <form onSubmit='return validasi(this)' id='formjenis' 
   method=POST action='$aksi?module=jenissurat&act=input' enctype='multipart/form-data'>
	 
   <p class=inline-small-label> 
   <label for=field4>Kode</label>
   <input style='width:10%' type=text name='kode_jns'>
   </p> 
	 	  
   <p class=inline-small-label> 
   <label for=field4>Keterangan</label>
   <input type=text name='ket_jns'>
   </p>";

   echo "<br/><br/><div class=block-actions> 
    <ul class=actions-right> 
    <li>
    <a class='button red' id=reset-validate-form href='?module=jenissurat'>Batal</a>
    </li> </ul>
    <ul class=actions-left> 
    <li>
   <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
   </form>";
	 
   break;
   
   //--EDIT Jenis Surat -------------
   case "edit":
   $edit=mysql_query("SELECT * FROM dis_surat_jenis WHERE id_jns='$_GET[id]'");
   $r=mysql_fetch_array($edit);

   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>EDIT JENIS SURAT</h1>
   </div>
   <div class='block-content'>
     
   <form onSubmit='return validasi(this)' id='formjenis' 
   method=POST action='$aksi?module=jenissurat&act=update' enctype='multipart/form-data'>
   <input type=hidden name=id value=$r[id_jns]>
	 
   <p class=inline-small-label> 
   <label for=field4>Kode</label>
   <input style='width:10%' type=text name='kode_jns' value='$r[kode_jns]' disabled>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Keterangan</label>
   <input type=text name='ket_jns' value='$r[ket_jns]'>
   </p><br/>";
	  echo "<br/><div class=block-actions> 
    <ul class=actions-right> 
    <li>
    <a class='button red' id=reset-validate-form href='?module=jenissurat'>Batal</a>
    </li> </ul>
    <ul class=actions-left> 
    <li>
    <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	</form>";
    
    break;  
   }
   //kurawal akhir hak akses module
   } else {
	echo akses_salah();
   }

   }
   ?>


   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>
