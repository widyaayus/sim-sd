<script>
function confirmdelete(delUrl) {
   if (confirm("Apakah Anda Yakin Ingin Menghapus Data Penerimaan Surat Masuk Ini?")) {
      document.location = delUrl;
   }
}
</script>
<script>
function validasi(form){
		  if (form.noperus.value == 0){
			alert("Anda belum mengisi Bagian Pengirim.");
			form.noperus.focus();
			return (false);
		  }
		  if (form.jnsmasuk.value == 0){
			alert("Anda belum mengisi Bagian Kategori Surat.");
			form.jnsmasuk.focus();
			return (false);
		  }
		  if (form.kepada.value == 0){
			alert("Anda belum mengisi Bagian Kepada.");
			form.kepada.focus();
			return (false);
		  }
		  if (form.perihal.value == 0){
			alert("Anda belum mengisi Bagian isi Ringkas.");
			form.perihal.focus();
			return (false);
		  }
		  return (true);
}
</script>

<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
 
  echo "
  <link href='../../css/biru/zalstyle.css' rel='stylesheet' type='text/css'>";

  echo "
  </head>
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  
  <img src='img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul ini, Anda harus login dahulu!</p></span><br/>
  
  </section>
  
  <section id='error-text'>
  <p><a class='button' href='index.php'>&nbsp;&nbsp; <b>ULANGI LAGI</b> &nbsp;&nbsp;</a></p>
  </section>
  </div>";
  
  }
  else{

//cek hak akses user dan pastikan semua user boleh mengakses  modul ini
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 
  OR $_SESSION['leveluser']=='arsiparis'
  OR $_SESSION['leveluser']=='pejabat' 
  OR $_SESSION['leveluser']=='resepsionis'){

$aksi="modul/mod_arsipmasuk/aksi_arsipmasuk.php";
switch($_GET[act]){

  // Tampil Data Penerimaan Surat Masuk
  default:
  echo "";
  
  //----------Jika kata KOSONG ------------------
 if (empty($_GET['kata'])){
	 //----------Jika Level User Arsiparis ------------------
	 if ($_SESSION['leveluser']=='pejabat' 
       OR $_SESSION['leveluser']=='arsiparis'){
        
        echo "
	      <div id='main-content'>
        <div class='container_12'>
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DATA SURAT MASUK</h1>
        <div id='form-close'>
        <p><a class='button red' href='?module=home'>X</a> </p>
        </div> 
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=terimaarsip&act=tambah' class='button'>
        <span>Tambahkan Data</span>
        </a>
		    <a href='modul/mod_laporan/cetaklembarekspidisi.php' target = _blank class='button'>
        <span>Cetak Pengantar</span>
        </a>
        <a href='modul/mod_laporan/cetakterimaarsippdf.php' target = _blank class='button'>
        <span>Cetak Data</span>
        </a>
        </div>

	      <table id='table-example' class='table'>
        <thead><tr>  
        <th>No</th>
        <th>No.Agenda</th>
        <th>Asal Surat</th>
		    <th>Aksi</th>
        </thead>
        <tbody>";
   
        $p      = new Paging;
        $batas  = 10;
        $posisi = $p->cariPosisi($batas);
        $tampil = mysql_query("SELECT a.*,b.nama,b.alamat,b.kota 
							  FROM dis_masuk_agd a
							  inner join dis_perus as b on a.noperus = b.nomor
							  where year(tgmasuk) = year(now())
							  ORDER BY nomasuk DESC");
	    $no = $posisi+1;
    
        while($r=mysql_fetch_array($tampil)){
        $tgl_posting=tgl_indo($r[tanggal]);
        $lebar=strlen($no);
        switch($lebar){
        case 1:
        {
        $g="00".$no;
        break;     
         }
	    case 2:
         {
        $g="0".$no;
        break;     
        }
        case 3:
        {
        $g=$no;
        break;     
       }      
       } 
	   
	   //--Jika belum diproses warna -- merah
	   //--Jika belum dikunci warna -- kuning
	   //--Jika sudah semua warna sesuai background
	   
	   if($r[diproses]==0){
	   $warna  = 'background:#F33; color:#fff';  //--merah-putih
	   }
	   elseif($r[kunci]==0){
	   $warna  = 'background:#FF9; color:#000'; //--kuning-hitam
	   }
	   else{
	   $warna  = '';
	   }
	
	   $kirim = $r[nama].', '.$r[alamat].' '.$r[kota].' '.$r[kodepos];
       
	  echo "<tr class=gradeX> 
       <td style='$warna;'><center>$g</center></td>
       <td width=70 style='$warna;'>$r[nomasuk]</td>
	   <td style='$warna;'>$kirim</td>
       <td width=80 style='$warna;'>
       <a href=?module=terimaarsip&act=cetakekspidisi&id=$r[nomasuk] title='Cetak Lembar Pengantar Surat' class='with-tip'><img src='img/cetak.bmp'></a>
       <a href=?module=terimaarsip&act=edit&id=$r[nomasuk] title='Edit Data' class='with-tip'>&nbsp;&nbsp;<img src='img/edit.png'></a>
       </center>  
       </td></tr>";
	   
	   $no++;
       }
   
       echo "</table>";
       $jmldata = mysql_num_rows(mysql_query("SELECT * FROM dis_masuk_agd where year(tgmasuk) = year(now())"));  
       $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
       $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);
       break;    
      }
  
	else{
	 echo "<div id='main-content'>
        <div class='container_12'>
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DATA SURAT MASUK</h1>
        <div id='form-close'>
        <p><a class='button red' href='?module=home'>X</a> </p>
        </div> 
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=terimaarsip&act=tambah' class='button'>
        <span>Tambahkan Data</span>
        </a>
		    <a href='modul/mod_laporan/cetaklembarekspidisi.php' target = _blank class='button'>
        <span>Cetak Pengantar</span>
        </a>
        <a href='modul/mod_laporan/cetakterimaarsippdf.php' target = _blank class='button'>
        <span>Cetak Data</span>
        </a>
        </div>

	      <table id='table-example' class='table'>
	      <thead><tr>  
        <th>No</th>
        <th>Tanggal</th>
        <th>Asal Surat</th>
		    <th>Aksi</th>
        </thead>
        <tbody>";
	  
        $p      = new Paging;
        $batas  = 10;
        $posisi = $p->cariPosisi($batas);
        $tampil = mysql_query("SELECT a.*,b.nama,b.alamat,b.kota 
							  FROM dis_masuk_agd a
							  inner join dis_perus as b on a.noperus = b.nomor
							  where year(tgmasuk) = year(now())
							  ORDER BY nomasuk DESC");
	      $no = $posisi+1;
    
        while($r=mysql_fetch_array($tampil)){
        $tgl_posting=tgl_indo($r[tanggal]);
        $lebar=strlen($no);
        switch($lebar){
        case 1:
        {
        $g="00".$no;
        break;     
         }
	    case 2:
         {
        $g="0".$no;
        break;     
        }
        case 3:
        {
        $g=$no;
        break;     
       }      
       } 
	   
	   //--Jika belum diproses warna -- merah
	   //--Jika belum dikunci warna -- kuning
	   //--Jika sudah semua warna sesuai background
	   
	   if($r[diproses]==0){
	   $warna  = 'background:#F33; color:#fff';  //--merah-putih
	   }
	   elseif($r[kunci]==0){
	   $warna  = 'background:#FF9; color:#000'; //--kuning-hitam
	   }
	   else{
	   $warna  = '';
	   }
	   $kirim = $r[nama].', '.$r[alamat].' '.$r[kota].' '.$r[kodepos];
       echo "<tr class=gradeX> 
       <td style='$warna;'><center>$g</center></td>
       <td width=70 style='$warna;'>$r[tgmasuk]</td>
       <td style='$warna;'>$kirim</td>
       <td width=60 style='$warna;'>
       <a href=?module=terimaarsip&act=cetakekspidisi&id=$r[nomasuk] title='Cetak Lembar Pengantar Surat' class='with-tip'><center><img src='img/cetak.bmp'></a>
       <a href=?module=terimaarsip&act=edit&id=$r[nomasuk] title='Edit Data' class='with-tip'>&nbsp;&nbsp;<img src='img/edit.png'></center></a>
       </td></tr>";
	   
	   $no++;
       }
   
       echo "</table>";
       $jmldata = mysql_num_rows(mysql_query("SELECT * FROM dis_masuk_agd where year(tgmasuk) = year(now())"));  
       $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
       $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);
       break;    
      }
 }
  
  case "tambah":
  echo "
  <div id='main-content'>
  <div class='container_12'>

  <div class='grid_12'>
  <div class='block-border'>
  <div class='block-header'>                    
  <h1>INPUT PENERIMAAN SURAT MASUK</h1>
  </div>
  <div class='block-content'>

   <form onSubmit='return validasi(this)' id='formterimaarsip' 
   method=POST action='$aksi?module=terimaarsip&act=input' enctype='multipart/form-data'>
   
   <p class=inline-small-label> 
   <label for=field4>Kategori Surat</label>
   <select name='jnsmasuk'>
   <option value='D' selected>Pilih Kategori</option>";
   $tampil=mysql_query("SELECT * FROM dis_groupsurat ORDER BY id_group");
   while($r=mysql_fetch_array($tampil)){
   echo "<option value=$r[id_group]>$r[nm_group]</option></p>"; }
   echo "</select>";
 			 
   echo " 
   <p class=inline-small-label> 
   <label for=field4>Asal Surat</label>
   <select name='noperus'>
   <option value=0 selected>Pilih Alamat Surat</option>";
   $tampil1=mysql_query("SELECT * FROM dis_perus ORDER BY nama");
   while($d=mysql_fetch_array($tampil1)){
   echo "<option value=$d[nomor]>$d[nama]</option>"; }
   echo "</select>";
   
   echo"
   <p class=inline-small-label> 
   <label for=field4>Kepada</label>
   <input type=text name='kepada'>
   </p> 	  
   
   <p class=inline-small-label> 
   <label for=field4>No.Surat</label>
   <input type=text name='nosurat'> 
   </p>
   <p class=inline-small-label> 
   <label for=field4>Lampiran</label>
   <input type=text name='lamp'>  
   </p>
   <p class=inline-small-label> 
   <label for=field4>Isi Ringkas</label>
   <textarea name='perihal' style='height: 100px;'></textarea>
   </p>	
   <p class=inline-small-label> 
   <label for=field4>Diteruskan?</label>
   <input type=radio name='diproses' value=1> Sudah   
   <input type=radio name='diproses' value=0 checked> Belum
   </p><br />";

   echo " 
   <div class=block-actions> 
   <ul class=actions-right> 
   <li>
   <a class='button red' id=reset-validate-form href='?module=terimaarsip'>Batal</a>
   </li> </ul>
   <ul class=actions-left> 
   <li>
      <input type='submit' name='fupload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	  </li> </ul>
	  </form>";
   
   
   break;
    
    
   //-----------------------------EDIT DATA ---------------------------------
  case "edit":
  if ($_SESSION['leveluser']=='arsiparis'){ 
  $edit = mysql_query("SELECT a.*,b.nama,b.alamat,b.kota 
							  FROM dis_masuk_agd a
							  inner join dis_perus as b on a.noperus = b.nomor
							  WHERE nomasuk='$_GET[id]'");
  $r    = mysql_fetch_array($edit);
  $kirim = $r[nama].', '.$r[alamat].' '.$r[kota].' '.$r[kodepos];
  
   echo "
   <div id='main-content'>
   <div class='container_12'>
   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   <h1>EDIT PENERIMAAN SURAT MASUK</h1>
   </div>
   <div class='block-content'>
   <form onSubmit='return validasi(this)' id='formterimaarsip' 
   method=POST enctype='multipart/form-data' action=$aksi?module=terimaarsip&act=update>
   <input type=hidden name=id value=$r[nomasuk]>
   
   <p class=inline-small-label> 
   <label for=field4>No.Agenda</label>
   <input style='width:35%' type=text name='nomasuk1' value='$r[nomasuk]' disabled> 
</p>

<p class=inline-small-label>
   <label for=field4>Kategori Surat</label>
   <select name='jnsmasuk'>";
   $tampilx=mysql_query("SELECT * FROM dis_groupsurat ORDER BY id_group");
   if ($r[jnsmasuk]==0){
   echo "<option value=0 selected>- Pilih Kategori -</option>"; }   
   while($w=mysql_fetch_array($tampilx)){
   if ($r[jnsmasuk]==$w[id_group]){
   echo "<option value=$w[id_group] selected>$w[nm_group]</option>";}
   else{
   echo "<option value=$w[id_group]>$w[nm_group]</option> </p> ";}}
   echo "</select>";
   
   echo "
   <p class=inline-small-label> 
   <label for=field4>Asal Surat</label>
   <input type=text name='noperus' size=60 value='$r[noperus]'>
   </p> 	
   <p class=inline-small-label> 
   <label for=field4> </label>
   <textarea name='nama' style='height: 30px;' disabled>$kirim</textarea>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Ditujukan Kpd</label>
   <input type=text name='kepada' size=60 value='$r[kepada]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>No.Surat</label>
   <input style = 'width:30%' type=text name='nosurat' size=60 value='$r[nosurat]'> Lampiran 
   <input style = 'width:20%' type=text name='lamp' size=60 value='$r[lamp]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Tgl.diteruskan</label>
   <input style = 'width:15%' type=text name='tgterus' size=60 value='$r[tgterus]'>  Oleh  
   <input style = 'width:20%' type=text name='ptgterus' size=60 value='$r[ptgterus]' disabled>  Kepada   
   <input style = 'width:20%' type=text name='untuk' size=60 value='$r[untuk]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Diterima oleh</label>
   <input style = 'width:20%' type=text name='terima' size=60 value='$r[terima]'> Tanggal 
   <input style = 'width:15%' type=text name='tgditerima' size=60 value='$r[tgditerima]' disabled> No.tanda Terima 
   <input style = 'width:10%' type=text name='noterima' size=60 value='$r[noterima]' disabled>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Status</label>
   <input style = 'width:20%' type=text name='status1' size=60 value='$r[status1]'> Posisi Fisik Surat saat ini 
   <input style = 'width:20%' type=text name='posisi' size=60 value='$r[posisi]' disabled>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Isi Ringkas</label>
   <textarea name='perihal' style='height: 50px;'>$r[perihal]</textarea>
   </p>";
   if ($r[kunci]==0){
      echo "
      <p class=inline-small-label> 
      <label for=field4>Siap Dikirim</label>
      <input type=radio name='kunci' value=1> Ya   
      <input type=radio name='kunci' value=0 checked> Tidak</p>";}
    else{
      echo "
      <p class=inline-small-label> 
      <label for=field4>Siap Dikirim</label>
      <input type=radio name='kunci' value=1 checked > Ya  
      <input type=radio name='kunci' value=0 > Tidak </p>";}
	
  
       if ($r[diproses]==0){
          echo "
          <p class=inline-small-label> 
          <label for=field4>Tindak Lanjut</label>
          <input type=radio name='diproses' value=1> Telah Diproses   
          <input type=radio name='diproses' value=0 checked> Belum Diproses</p>";}
       else{
          echo "
          <p class=inline-small-label> 
          <label for=field4>Tindak Lanjut</label>
          <input type=radio name='diproses' value=1 checked > Telah Diproses  
          <input type=radio name='diproses' value=0 > Belum Diproses</p>";}
        
	echo "<br/>
    <div class=block-actions> 
   <ul class=actions-right> 
   <li>
   <a class='button red' id=reset-validate-form href='?module=terimaarsip'>Batal</a>
   </li> </ul>
   <ul class=actions-left> 
   <li>
      <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
   </form>";
}   
else{
$edit = mysql_query("SELECT a.*,b.nama,b.alamat,b.kota,b.kodepos 
							  FROM dis_masuk_agd a
							  inner join dis_perus as b on a.noperus = b.nomor
							  WHERE nomasuk='$_GET[id]'");
  $r    = mysql_fetch_array($edit);
  $kirim = $r[nama].', '.$r[alamat].' '.$r[kota].' '.$r[kodepos];
  
   echo "
   <div id='main-content'>
   <div class='container_12'>
   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   <h1>EDIT PENERIMAAN SURAT MASUK</h1>
   </div>
   <div class='block-content'>
   <form onSubmit='return validasi(this)' id='formterimaarsip' 
   method=POST enctype='multipart/form-data' action=$aksi?module=terimaarsip&act=update>
   <input type=hidden name=id value=$r[nomasuk]>
   
   <p class=inline-small-label> 
   <label for=field4>No.Agenda</label>
   <input type=text name='nomasuk1' value='$r[nomasuk]' disabled> 
   </p>
   <p class=inline-small-label> 
          <label for=field4>Tgl.Masuk</label>";   
          $get_tgl2=substr("$r[tgmasuk]",8,2);
          combotgl(1,31,'tgl_masuk',$get_tgl2);
          $get_bln2=substr("$r[tgmasuk]",5,2);
          combonamabln(1,12,'bln_masuk',$get_bln2);
          $get_thn2=substr("$r[tgmasuk]",0,4);
          combothn($thn_sekarang,$thn_sekarang,'thn_masuk',$get_thn2);

    echo "</p>
   
   <p class=inline-small-label> 
   <label for=field4>Diterima oleh</label>
   <input type=text name='kd_ptgs' value='$r[kd_ptgs]' disabled>
   </p>   
   <p class=inline-small-label>
   <label for=field4>Kategori Surat</label>
   <select name='jnsmasuk'>";
   $tampilx=mysql_query("SELECT * FROM dis_groupsurat ORDER BY id_group");
   if ($r[jnsmasuk]==0){
   echo "<option value=0 selected>- Pilih Kategori -</option>"; }   
   while($w=mysql_fetch_array($tampilx)){
   if ($r[jnsmasuk]==$w[id_group]){
   echo "<option value=$w[id_group] selected>$w[nm_group]</option>";}
   else{
   echo "<option value=$w[id_group]>$w[nm_group]</option> </p> ";}}
   echo "</select>";
   
   echo "
   <p class=inline-small-label>
   <label for=field4>Asal Surat</label>
   <select name='noperus'>";
   $tampilx=mysql_query("SELECT * FROM dis_perus ORDER BY nomor");
   if ($r[noperus]==0){
   echo "<option value=0 selected>- Pilih Alamat Surat -</option>"; }   
   while($w=mysql_fetch_array($tampilx)){
   if ($r[noperus]==$w[nomor]){
   echo "<option value=$w[nomor] selected>$w[nama]</option>";}
   else{
   echo "<option value=$w[nomor]>$w[nama]</option> </p> ";}}
   echo "</select>";
   
   echo "
   <p class=inline-small-label> 
   <label for=field4>Kepada</label>
   <input type=text name='kepada' value='$r[kepada]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>No.Surat</label>
   <input type=text name='nosurat' value='$r[nosurat]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Lampiran</label>
   <input type=text name='lamp' value='$r[lamp]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Isi Ringkas</label>
   <textarea name='perihal' style='height: 75px;'>$r[perihal]</textarea>
   </p>
   
   <p class=inline-small-label> 
   <label for=field4>Lokasi Fisik</label>
   <input type=text name='posisi' value='$r[posisi]' disabled>
   </p>";
   if ($r[diproses]==0){
      echo "
      <p class=inline-small-label> 
      <label for=field4>Diteruskan?</label>
      <input type=radio name='diproses' value=1> Sudah   
      <input type=radio name='diproses' value=0 checked> Belum</p>";}
    else{
      echo "
      <p class=inline-small-label> 
      <label for=field4>Diteruskan?</label>
      <input type=radio name='diproses' value=1 checked > Sudah  
      <input type=radio name='diproses' value=0 > Belum </p>";}
        
	echo "<br/>
    <div class=block-actions> 
   <ul class=actions-right> 
   <li>
   <a class='button red' id=reset-validate-form href='?module=terimaarsip'>Batal</a>
   </li> </ul>
   <ul class=actions-left> 
   <li>
      <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
   </form>";
   }
    break; 
    
//-----CETAK LEMBAR EKSPIDISI ---------------------- 
  case "cetakekspidisi":
  $cetak = mysql_query("SELECT a.*,b.nama,b.alamat,b.kota 
							  FROM dis_masuk_agd a
							  inner join dis_perus as b on a.noperus = b.nomor
							  WHERE nomasuk='$_GET[id]'");
  $r    = mysql_fetch_array($cetak);
  $kirim = $r[nama].', '.$r[alamat].' '.$r[kota].' '.$r[kodepos];
  
  echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>CETAK LEMBAR EKSPIDISI</h1>
   </div>
   <div class='block-content'>
   
   <form method=POST enctype='multipart/form-data' 
   action='modul/mod_laporan/cetaklembarekspidisi2.php' target = _blank >
   <input type=hidden name=id value=$r[nomasuk]>
 
   <p class=inline-small-label> 
   <label for=field4>No.Agenda</label>
   <input style ='width:30%' type=text name='nomasuk' value='$r[nomasuk]' disabled>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Dari</label>
   <textarea name='pengirim' style='height: 60px;' disabled>$kirim </textarea>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Untuk</label>
   <input type=text name='untuk'  value=''>
   </p>
   <p class=inline-small-label> 
   <label for=field4>No.Surat</label>
   <input type=text name='nosurat' value='$r[nosurat]' disabled>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Perihal</label>
   <textarea name='deskripsi' style='height: 60px;' disabled>$r[perihal] </textarea>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Petugas Ekpidisi</label>
   <input type=text name='ptgsbag'  value=''>
   </p>
   <br /><br />";

   echo  "<div class=block-actions> 
   <ul class=actions-right> 
   <li>
   <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp;Cetak &nbsp;&nbsp;&nbsp;&nbsp;'>
   </li>
   <li>
   <a class='button red' id=reset-validate-form href='?module=terimaarsip'>Batal</a>
   </li> </ul>
   </form>";
	 // }
    break; 
}

    //kurawal akhir hak akses module
}else {
	echo akses_salah();
    }
    }
    ?>

   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>

