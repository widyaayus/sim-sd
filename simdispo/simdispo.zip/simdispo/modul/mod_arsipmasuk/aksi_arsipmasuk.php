<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../config/koneksi.php";
include "../../config/library.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus Data Penerimaan Surat Masuk
if ($module=='terimaarsip' AND $act=='hapus'){
  mysql_query("DELETE FROM dis_masuk_agd WHERE nomasuk='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input Penerimaan Surat Masuk
// Nomor masuk = D.15.0001
//Nomor Kirim = K-15070001
/*,
                 */
elseif ($module=='terimaarsip' AND $act=='input'){
  $kode= $_POST[jnsmasuk];
  $thn = date("y"); //tahun 2 digit
	$bln = date("m"); //bulan 2 digit
	$thn1= date("Y"); //tahun 4 digit
	$qr1	= mysql_query("SELECT MAX(CONCAT(LPAD((SUBSTR((nomasuk),6,4)+1),4,'0'))) FROM dis_masuk_agd WHERE YEAR(tgmasuk) = $thn1");
  $qr2  = mysql_query("SELECT MIN(CONCAT(LPAD((SUBSTR((nomasuk),6,4)),4,'0'))) FROM dis_masuk_agd WHERE YEAR(tgmasuk) = $thn1");
  $qr3	= mysql_query("SELECT MAX(CONCAT(LPAD((SUBSTR((noterima),7,4)+1),4,'0'))) FROM dis_masuk_agd WHERE YEAR(tgmasuk) = $thn1 AND MONTH(tgmasuk) = $bln");
  $qr4  = mysql_query("SELECT MIN(CONCAT(LPAD((SUBSTR((noterima),7,4)),4,'0'))) FROM dis_masuk_agd WHERE YEAR(tgmasuk) = $thn1 AND MONTH(tgmasuk) = $bln");
  $kde1= mysql_fetch_array($qr1);
  $kde2= mysql_fetch_array($qr2);
  $kde3= mysql_fetch_array($qr3);
  $kde4= mysql_fetch_array($qr4); 	
	
  if ($kde2[0] != '0001'){
       $nourut = $kode.'.'.$thn.'.'.'0001';
    }
    else{
       $nourut = $kode.'.'.$thn.'.'.$kde1[0];
    }
  
  if ($kde4[0] != '0001'){
       $notrm = 'K-'.$thn.$bln.'0001';
    }
    else{
       $notrm = 'K-'.$thn.$bln.$kde3[0];
    }
    
  $tterus = $_POST[thn_terus].'-'.$_POST[bln_terus].'-'.$_POST[tgl_terus];
  $tterima = $_POST[thn_terima].'-'.$_POST[bln_terima].'-'.$_POST[tgl_terima];
  mysql_query("INSERT INTO dis_masuk_agd(tgmasuk,
                           nomasuk,
                           jnsmasuk,
                           noperus,
                           kepada,
                           nosurat,
                           lamp,
                           perihal,
                           kd_ptgs,
                           posisi,
                           diproses) 
                    VALUES('$tgl_sekarang',
                           '$nourut',
                           '$_POST[jnsmasuk]',
                           '$_POST[noperus]',
                           '$_POST[kepada]',
                           '$_POST[nosurat]',
                           '$_POST[lamp]',
                           '$_POST[perihal]',
                           '$_SESSION[namauser]',
                           '$_SESSION[bagian]',
                           '$_POST[diproses]')");
   
  header('location:../../media.php?module='.$module);
}

// Update Penerimaan Surat Masuk
elseif ($module=='terimaarsip' AND $act=='update'){
     mysql_query("UPDATE dis_masuk_agd SET 
			                jnsmasuk = '$_POST[jnsmasuk]',
			                noperus  = '$_POST[noperus]',
			                kepada   = '$_POST[kepada]',
			                nosurat  = '$_POST[nosurat]',
			                lamp     = '$_POST[lamp]',
			                perihal  = '$_POST[perihal]',
			                diproses = '$_POST[diproses]'
               WHERE nomasuk = '$_POST[id]'");
    }
  header('location:../../media.php?module='.$module);
}
?>
