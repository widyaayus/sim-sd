<script>
function confirmdelete(delUrl) {
   if (confirm("Apakah Anda Yakin Ingin Menghapus Data Disposisi Ini?")) {
      document.location = delUrl;
   }
}

</script>
<script>
function validasi(form){
		  
      if (form.utk_dispo.value == 0){
			alert("Anda belum mengisi Bagian Tujuan Disposisi.");
			form.utk_dispo.focus();
			return (false);
		  }
		  if (form.isi_dispo.value == ""){
			alert("Anda belum mengisi Bagian Isi Disposisi.");
			form.isi_dispo.focus();
			return (false);
		  }
		  
		  return (true);
}
</script>

<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "
  <link href='../../css/biru/zalstyle.css' rel='stylesheet' type='text/css'>";

  echo "
  </head>
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul ini, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='index.php'>&nbsp;&nbsp; <b>ULANGI LAGI</b> &nbsp;&nbsp;</a></p>
  </section>
  </div>";
 }
  else{
//cek hak akses user dan pastikan semua user boleh mengakses  modul ini
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 
  OR $_SESSION['leveluser']=='direksi'
  OR $_SESSION['leveluser']=='pejabat'){
  
$aksi="modul/mod_arsipdisposisi/aksi_arsipdisposisi.php";
switch($_GET[act]){

  // Tampil Data Disposisi
  default:
  echo "";
  //----------Jika kata KOSONG ------------------
 if (empty($_GET['kata'])){
    echo "
	      <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DATA DISPOSISI</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        
	      <table id='table-example' class='table'>
        <thead><tr>  
        <th>No</th>
        <th>Tanggal</th>
		    <th>Dari</th>
        <th>Disposisi</th>
        <th>Aksi</th>
        </thead>
        <tbody>";

        $p      = new Paging;
        $batas  = 15;
        $posisi = $p->cariPosisi($batas);
        
        $tampil = mysql_query("SELECT a.*,b.nm_jbtan 
                  FROM dis_dispo_dt a
							    inner join dis_unit as b on a.dari_dispo = b.id_unit
							    WHERE untuk like '%$_SESSION[bagian]%'
                  AND year(tgdispo) = year(now())
							    ORDER BY baca ASC,iddispo DESC");
	      
        $no = $posisi+1;
        while($r=mysql_fetch_array($tampil)){
        $tgl_posting=tgl_indo($r[tanggal]);
        $lebar=strlen($no);
        switch($lebar){
        case 1:
        {
        $g="0000".$no;
        break;     
         }

		 case 2:
        {
        $g="000".$no;
        break;     
         }

		 case 3:
        {
        $g="00".$no;
        break;     
         }

	    case 4:
         {
        $g="0".$no;
        break;     
        }

        case 5:
        {
        $g=$no;
        break;     
       }      
       } 

	  $warna  = 'color:#F33';
	  if($r[baca]=='0'){
	    echo "<tr class=gradeX> 
            <td width=50 style='$warna;'><center>$g</center></td>
            <td width=100 style='$warna;'>$r[tgdispo]</td>
            <td width=150 style='$warna;'><b><a href=?module=disposisi&act=lihatdispo&id=$r[nomasuk]>$r[nm_jbtan]</a></b></td>
            <td style='$warna;'>$r[isidispo]</td>
            <td width=50 >
            <a href=?module=disposisi&act=lihatdispo&id=$r[iddispo] title='Baca Disposisi' class='with-tip'>Baca</a>
            </td></tr>";
     }
     else{
     echo "<tr class=gradeX> 
            <td width=50><center>$g</center></td>
            <td width=100>$r[tgdispo]</td>
            <td width=150><b><a href=?module=disposisi&act=lihatdispo&id=$r[nomasuk]>$r[nm_jbtan]</a></b></td>
            <td>$r[isidispo]</td>
            <td width=50 >
            <a href=?module=disposisi&act=lihatdispo&id=$r[iddispo] title='Baca Disposisi' class='with-tip'>Baca</a>
            </td></tr>";
     }
	   $no++;

       }

       echo "</table>";
       $jmldata = mysql_num_rows(mysql_query("SELECT * FROM dis_dispo_dt 
                  WHERE untuk like '%$_SESSION[bagian]%'
                  AND year(tgdispo) = year(now())"));  
       $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
       $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);
       break; 
}   

  case "lihatdispo": 
  $edit = mysql_query("SELECT a.*,b.nama,b.alamat,b.kota,b.kodepos,c.perihal,c.gambar 
							  FROM dis_dispo_dt a
                inner join dis_perus as b on a.noperus = b.nomor
                inner join dis_masuk as c on a.nomasuk = c.no_masuk
                WHERE iddispo='$_GET[id]'");
  
  $r    = mysql_fetch_array($edit);
  $file = $r[gambar];
  $kirim = $r[nama].', '.$r[alamat].' '.$r[kota].' '.$r[kodepos];
  $dibaca = $r[baca];
  $nodispo = $r[no_dtdispo];
  
  if ($dibaca==0){
     mysql_query("UPDATE dis_dispo_dt SET baca='1', tgbaca='$tgl_jamsekarang' WHERE iddispo='$_GET[id]'");
  }
  
  echo "<div id='main-content'>
   <div class='container_12'>
   <div class='grid_12'></div>

        <div class='grid_12'>
  <div class='block-border'>
   <div class='block-header'>
        <h1>View Surat Masuk</h1>
        <span></span>
   </div>
   
   <div class='block-content'>
   <center><embed src='fileupload/masuk/$file#toolbar=0&navpanes=0&scrollbar=0' 
          quality='high'
          name='suratmasuk'
          AllowScriptAccess='always'
          AllowFullScreen='true'
          type='application/pdf' 
          width='100%' 
          height='550'/>
   </embed></center>
   </div>
   </div>
   <div class='block-header'>
        <h1>DISPOSISI SURAT MASUK</h1>
        <div id='form-close'>
            <p><a class='button red' href='?module=disposisi'>X</a> </p>
        </div>
   </div>
   
   <div class='block-content'>
   <form onSubmit='return validasi(this)' id='formdisposisi' 
   method=POST action='$aksi?module=disposisi&act=input' enctype='multipart/form-data'>
   <input type=hidden name=no_masuk value=$r[nomasuk]>
   
   <p class=inline-small-label> 
   <label for=field4>Nomor Agenda</label>
   <input type=text name='no_masuk' value='$r[nomasuk]'  readonly>
   </p>	
   
   <p class=inline-small-label> 
   <label for=field4> Pengirim</label>
   <input type=text name='noperus' value='$r[noperus]'  readonly>
   <textarea name='pengirim' style='height: 30px;'  readonly>$kirim</textarea>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Perihal</label>
   <textarea name='perihal' style='height: 30px;'  readonly>$r[perihal]</textarea>
   </p>
   <p class=inline-small-label> 
   <label for=field4>No. Disposisi</label>
   <input type=text name='no_dispo' value='$r[no_dtdispo]' readonly>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Dari</label>
   <input type=text name='dari_dispo' value = '$_SESSION[bagian]' readonly>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Untuk</label>
   <select name='utk_dispo'>
   <option value=0 selected>- Pilih Tujuan Disposisi -</option>";   
   $tampil1=mysql_query("SELECT * FROM dis_unit ORDER BY nm_jbtan");
   while($x=mysql_fetch_array($tampil1)){
   echo "<option value=$x[id_unit]>$x[nm_jbtan] - [$x[id_unit]]</option> </p> ";}
   echo "</select>";

   echo "<br /><p class=inline-small-label> 
   <label for=field4>Disposisi</label>
   <textarea name='isi_dispo' style='height: 100px;'></textarea>
   </p>
   <div class='block-content'>
   <div id='form-close'>
        <input type='submit' name='fupload' class='button' value='  Kirim  '>
   </div>
   <h4>DETAIL DISPOSISI:</h4>
    
   <table id='table-example' class='table'>
   <thead><tr>
      <th>No</th>
      <th>Tanggal</th>
      <th>Dari</th>
      <th>Untuk</th>
      <th>Disposisi</th>
   </thead>
   <tbody>";
	
   $p      = new Paging;
   $batas  = 15;
   $posisi = $p->cariPosisi($batas);
   
   $tampil=mysql_query("SELECT a.*,b.nm_jbtan as dispodari,c.nm_jbtan as dispountuk
                        FROM dis_dispo_dt a
                        inner join dis_unit as b on a.dari_dispo=b.id_unit
                        inner join dis_unit as c on a.untuk=c.id_unit
                        WHERE no_dtdispo='$nodispo'
                        ORDER BY iddispo ASC");
      
   $no = $posisi+1;
   while($r=mysql_fetch_array($tampil)){
   $lebar=strlen($no);
   switch($lebar){
   case 1:
      {
        $g="0".$no;
        break;     
      }
      case 2:
      {
        $g=$no;
        break;     
      }      
      } 

   $warna  = 'color:#F33';
	  if($r[baca]=='0'){
   echo "<tr class=gradeX> 
   <td width=50 style='$warna;'><center>$g</center></td>
   <td width=100 style='$warna;'>$r[tgdispo]</td>
   <td style='$warna;'>$r[dispodari]</td>
   <td style='$warna;'>$r[dispountuk]</td>
   <td style='$warna;'>$r[isidispo]</td>
   </td></tr>";
   }
   else{
   echo "<tr class=gradeX> 
   <td width=50><center>$g</center></td>
   <td width=100>$r[tgdispo]</td>
   <td >$r[dispodari]</td>
   <td >$r[dispountuk]</td>
   <td >$r[isidispo]</td>
   </td></tr>";
   }
   $no++;
       }
   
       echo "</table></div>
   </div></div>
   </div>
   </div>";
   
    break;

}
    //kurawal akhir hak akses module
}else {
	echo akses_salah();
    }
    }
    ?>

   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>

