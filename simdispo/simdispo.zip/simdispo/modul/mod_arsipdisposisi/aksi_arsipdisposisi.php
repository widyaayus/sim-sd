<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

 echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
 
else{
include "../../config/koneksi.php";
include "../../config/library.php";
include "../../config/fungsi_thumb.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus Data Disposisi
if ($module=='disposisi' AND $act=='hapus'){
     mysql_query("DELETE FROM dis_dispo_dt WHERE no_dtdispo='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input Data Disposisi
elseif ($module=='disposisi' AND $act=='input'){
  mysql_query("INSERT INTO dis_dispo_dt(tgdispo,
                                    nomasuk,
                                    noperus,
                                    no_dtdispo,
                                    isidispo,
                                    dari_dispo,
                                    untuk,
                                    kd_ptgs,
                                    balas,
                                    tglbalas) 
                             VALUES('$tgl_jamsekarang',
                                    '$_POST[no_masuk]', 
                                    '$_POST[noperus]',
                                    '$_POST[no_dispo]',
                                    '$_POST[isi_dispo]',
                                    '$_SESSION[bagian]',
                                    '$_POST[utk_dispo]',  
                                    '$_SESSION[namauser]',
                                    '1',
                                    '$tgl_jamsekarang')");

  header('location:../../media.php?module='.$module);
}
}

?>

