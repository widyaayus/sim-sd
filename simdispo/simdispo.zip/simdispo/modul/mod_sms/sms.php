<script>
function confirmdelete(delUrl) {
   if (confirm("Anda yakin ingin menghapus Pesan ini?")) {
      document.location = delUrl;
   }
}
</script>
<script>
function validasi(form){
		  if (form.notelpon.value == ""){
			alert("Anda belum mengisi Bagian No.Telpon.");
			form.notelpon.focus();
			return (false);
		  }
		  
		  if (form.pesan.value == ""){
			alert("Anda belum mengisi Bagian Pesan.");
			form.pesan.focus();
			return (false);
		  }
		  
		  return (true);
}
</script>

<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
    echo "
  <link href='css/zalstyle.css' rel='stylesheet' type='text/css'>";

  echo "
  </head>
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='index.php'>&nbsp;&nbsp; <b>ULANGI LAGI</b> &nbsp;&nbsp;</a></p>
  </section>
  </div>";
}
else{
//cek hak akses user
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1
   OR $_SESSION[menu84]=='11111'  
   OR $_SESSION[menu84]=='01111' 
   OR $_SESSION[menu84]=='00111'
   OR $_SESSION[menu84]=='00101'){

$base_url = $_SERVER['HTTP_HOST'];
  $iden=mysql_fetch_array(mysql_query("SELECT * FROM identitas"));

$aksi="modul/mod_sms/aksi_sms.php";
switch($_GET[act]){
  // Tampil Hubungi Kami
  default:
   
   echo "
   <div id='main-content'>
   <div class='container_12'>
   <div class='grid_12'>
   <a href='?module=smsgateway&act=tambah' class='button'>
   <span>Tulis SMS Baru</span>
   </a><a href='?module=smsgateway&act=terkirim' class='button'>
   <span>Lihat SMS Terkirim</span>
   </a><a href='?module=smsgateway&act=keluar' class='button'>
   <span>Lihat SMS Keluar</span>
   </a></div>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   <h1>PESAN SINGKAT (SMS) MASUK</h1>
   <span></span> 
   </div>
   <div class='block-content'>
		  
   <table id='table-example' class='table'>
		
   <thead><tr>	
		
  <th>No</th>
  <th>Tanggal</th>
  <th>No.Telpon</th>
  <th>Pesan</th>
  <th>Aksi</th>
   </thead>
   <tbody>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil=mysql_query("SELECT * FROM sms_inbox ORDER BY ID DESC");

    $no = $posisi+1;
    while ($r=mysql_fetch_array($tampil)){
      $tgl=tgl_indo($r[tanggal]);
    $lebar=strlen($no);
    switch($lebar){
      case 1:
      {
        $g="0".$no;
        break;     
      }
      case 2:
      {
        $g=$no;
        break;     
      }      
    } 

    $warna  = 'color:#F33';
	  if($r[ReadOK]==0){
    echo "<tr class=gradeX> 
    <td width=50 style='$warna;'><center><b>$g</b></center></td>
	  <td width=150 style='$warna;'><b>$r[ReceivingDateTime]</b></td>
	  <td width=100 style='$warna;'><b><a href=?module=smsgateway&act=balas&id=$r[ID]>$r[SenderNumber]</a></b></td>
	  <td style='$warna;'><b>$r[TextDecoded]</b></td>
	  <td width=80>
	  <a href=?module=smsgateway&act=balas&id=$r[ID] title='Balas SMS' class='with-tip'><center><img src='img/balas.png'></a>
	  <a href=javascript:confirmdelete('$aksi?module=smsgateway&act=hapus&id=$r[ID]') 
    title='Hapus' class='with-tip'><img src='img/hapus.png'></center></a> 
	 </td></tr>";
	 
	  } 
	  else {
echo "<tr class=gradeX> 
    <td width=50><center>$g</center></td>
	  <td width=150>$r[ReceivingDateTime]</td>
	  <td width=100><a href=?module=smsgateway&act=balas&id=$r[ID]>$r[SenderNumber]</a></td>
	  <td>$r[TextDecoded]</td>
	  <td width=80>
	  <a href=?module=smsgateway&act=balas&id=$r[ID] title='Balas SMS' class='with-tip'><center><img src='img/balas.png'></a>
	  <a href=javascript:confirmdelete('$aksi?module=smsgateway&act=hapus&id=$r[ID]') 
    title='Hapus' class='with-tip'><img src='img/hapus.png'></center></a> 
	 
	  </td></tr>";
	  }
    $no++;
    }
    echo "</table>";
    $jmldata=mysql_num_rows(mysql_query("SELECT * FROM sms_inbox"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

    break;

  case "balas":
    $tampil = mysql_query("SELECT * FROM sms_inbox WHERE ID='$_GET[id]'");
    $r      = mysql_fetch_array($tampil);
	  mysql_query("UPDATE sms_inbox SET ReadOK=1, ReadID='$_SESSION[namauser], ReadDateTime= now() WHERE ID='$_GET[id]'");

    echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>BALAS PESAN SINGKAT (SMS)</h1>
   </div>
   <div class='block-content'>
   <form onSubmit='return validasi(this)' id='formsms' 
   method=POST action='$aksi?module=smsgateway&act=input' enctype='multipart/form-data'>
   <p class=inline-small-label> 
   <label for=field4>No.Telpon</label>
  <input type=text name='notelpon' value='$r[SenderNumber]'><br />
   *) Gunakan tanda koma (,) untuk memisahkan nomor telpon 1 dengan yang lainnya
   </p> 
   		 
   <p class=inline-small-label> 
   <label for=field4>Pesan</label>
   <textarea name='pesan' style='height: 50px;'></textarea><br />
   *) Panjang pesan maksimal 160 character
   </p><br /> 
   <div class=block-actions> 
   <ul class=actions-right> 
   <li>
   <a class='button red' id=reset-validate-form href='?module=smsgateway'>Batal</a>
   </li> </ul>
   <ul class=actions-left> 
   <li>
   <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Kirim SMS  &nbsp;&nbsp;&nbsp;&nbsp;'>
	 </form>";
	  		  
   break;
	 
 //Kirim SMS Baru
  case "tambah":
  echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>BALAS PESAN SINGKAT (SMS)</h1>
   </div>
   <div class='block-content'>
   <form onSubmit='return validasi(this)' id='formsms' 
   method=POST action='$aksi?module=smsgateway&act=input' enctype='multipart/form-data'>
   <p class=inline-small-label> 
   <label for=field4>No.Telpon</label>
  <input type=text name='notelpon'><br />
   *) Gunakan tanda koma (,) untuk memisahkan nomor telpon 1 dengan yang lainnya
   </p> 
   		 
   <p class=inline-small-label> 
   <label for=field4>Pesan</label>
   <textarea name='pesan' style='height: 50px;'></textarea><br />
   *) Panjang pesan maksimal 160 character
   </p><br /> 
   <div class=block-actions> 
   <ul class=actions-right> 
   <li>
   <a class='button red' id=reset-validate-form href='?module=smsgateway'>Batal</a>
   </li> </ul>
   <ul class=actions-left> 
   <li>
   <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Kirim SMS  &nbsp;&nbsp;&nbsp;&nbsp;'>
	 </form>";
	  		  
   break; 
   /////////////////////////////////////////////////////////
   case "terkirim":
   echo "
   <div id='main-content'>
   <div class='container_12'>
   <div class='grid_12'>
   <a href='?module=smsgateway&act=tambah' class='button'>
   <span>Tulis SMS Baru</span>
   </a><a href='?module=smsgateway&act=terkirim' class='button'>
   <span>Lihat SMS Keluar</span>
   </a><a href='?module=smsgateway' class='button'>
   <span>Lihat SMS Masuk</span>
   </a></div>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   <h1>PESAN SINGKAT (SMS) TERKIRIM</h1>
   <span></span> 
   </div>
   <div class='block-content'>
		  
   <table id='table-example' class='table'>
		
   <thead><tr>	
		
  <th>No</th>
  <th>Tanggal</th>
  <th>No.Telpon</th>
  <th>Pesan</th>
  <th>Aksi</th>
   </thead>
   <tbody>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil=mysql_query("SELECT * FROM sms_sentitems 
                         WHERE SenderID = '$_SESSION[namauser]'
                         ORDER BY ID DESC");

    $no = $posisi+1;
    while ($r=mysql_fetch_array($tampil)){
      $tgl=tgl_indo($r[tanggal]);
    $lebar=strlen($no);
    switch($lebar){
      case 1:
      {
        $g="0".$no;
        break;     
      }
      case 2:
      {
        $g=$no;
        break;     
      }      
    } 

    echo "<tr class=gradeX> 
    <td width=50><center>$g</center></td>
	  <td width=150>$r[SendingDateTime]</td>
	  <td width=100>$r[DestinationNumber]</td>
	  <td>$r[TextDecoded]</td>
	  <td width=30>
	  <a href=javascript:confirmdelete('$aksi?module=smsgateway&act=hapus&id=$r[ID]') 
    title='Hapus' class='with-tip'><center><img src='img/hapus.png'></center></a> 
	  </td></tr>";
	 
    $no++;
    }
    echo "</table>";
    $jmldata=mysql_num_rows(mysql_query("SELECT * FROM sms_sentitems
                                         WHERE SenderID = '$_SESSION[namauser]'"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);
   break; 
   //////////////////////////////////////////////////////
   case "keluar":
   echo "
   <div id='main-content'>
   <div class='container_12'>
   <div class='grid_12'>
   <a href='?module=smsgateway&act=tambah' class='button'>
   <span>Tulis SMS Baru</span>
   </a><a href='?module=smsgateway&act=terkirim' class='button'>
   <span>Lihat SMS Terkirim</span>
   </a><a href='?module=smsgateway' class='button'>
   <span>Lihat SMS Masuk</span>
   </a></div>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   <h1>PESAN SINGKAT (SMS) KELUAR</h1>
   <span></span> 
   </div>
   <div class='block-content'>
		  
   <table id='table-example' class='table'>
		
   <thead><tr>	
		
  <th>No</th>
  <th>Tanggal</th>
  <th>No.Telpon</th>
  <th>Pesan</th>
  <th>Aksi</th>
   </thead>
   <tbody>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil=mysql_query("SELECT * FROM sms_outbox 
                         WHERE SenderID = '$_SESSION[namauser]'
                         ORDER BY ID DESC");

    $no = $posisi+1;
    while ($r=mysql_fetch_array($tampil)){
      $tgl=tgl_indo($r[tanggal]);
    $lebar=strlen($no);
    switch($lebar){
      case 1:
      {
        $g="0".$no;
        break;     
      }
      case 2:
      {
        $g=$no;
        break;     
      }      
    } 

    echo "<tr class=gradeX> 
    <td width=50><center>$g</center></td>
	  <td width=150>$r[SendingDateTime]</td>
	  <td width=100>$r[DestinationNumber]</td>
	  <td>$r[TextDecoded]</td>
	  <td width=30>
	  <a href=javascript:confirmdelete('$aksi?module=smsgateway&act=hapus&id=$r[ID]') 
    title='Hapus' class='with-tip'><center><img src='img/hapus.png'></center></a> 
	  </td></tr>";
	 
    $no++;
    }
    echo "</table>";
    $jmldata=mysql_num_rows(mysql_query("SELECT * FROM sms_outbox
                                         WHERE SenderID = '$_SESSION[namauser]'"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);
   break; 
   }
   }
   }
  ?>

   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>
