<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];
$namakomp = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$ipkomp = GetHostByName($REMOTE_ADDR);

// Hapus SMS
if ($module=='smsgateway' AND $act=='hapus'){
  mysql_query("DELETE FROM sms_inbox WHERE ID='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input SMS
 elseif ($module=='smsgateway' AND $act=='input'){
     
     mysql_query("INSERT INTO sms_outbox (DestinationNumber,
                                   TextDecoded,
                                   SenderID,
                                   idkomp) 
	                       VALUES('$_POST[notelpon]',
                                '$_POST[pesan]',
                                '$_SESSION[namauser]',
                                '$namakomp')");
 
  header('location:../../media.php?module='.$module);
  }
}
?>
