<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/biru/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../config/koneksi.php";
include "../../config/library.php";
include "../../config/fungsi_thumb.php";

$module=$_GET[module];
$act=$_GET[act];
$namakomp = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$ipkomp = GetHostByName($REMOTE_ADDR);

// Hapus ENota Dinas
if ($module=='notadinas' AND $act=='hapus'){
  $data=mysql_fetch_array(mysql_query("SELECT attachment FROM dis_notadinas WHERE id_nota='$_GET[id]'"));
  if ($data['attachment']!=''){
  mysql_query("DELETE FROM dis_notadinas WHERE id_nota='$_GET[id]'");
     unlink("../../fileupload/nota/$_GET[namafile]");   
  }
  else{
  mysql_query("DELETE FROM dis_notadinas WHERE id_nota='$_GET[id]'");
  }
  header('location:../../media.php?module='.$module);
}

// Input Nota Dinas
elseif ($module=='notadinas' AND $act=='input'){
  $thn = date("y"); //tahun 2 digit
	$bln = date("m"); //bulan 2 digit
	$thn1= date("Y"); //tahun 4 digit
	$qr1	= mysql_query("SELECT MAX(CONCAT(LPAD((LEFT((no_nota),4)+1),4,'0'))) FROM dis_notadinas WHERE YEAR(tglkirim) = $thn1");
  $qr2  = mysql_query("SELECT MIN(CONCAT(LPAD((LEFT((no_nota),4)),4,'0'))) FROM dis_notadinas WHERE YEAR(tglkirim) = $thn1");
  $kde1= mysql_fetch_array($qr1);
  $kde2= mysql_fetch_array($qr2);
  
  if ($bln == '01'){
    $rbln = 'I';
  }
  elseif ($bln == '02'){
    $rbln = 'II';
  }
  elseif ($bln == '03'){
    $rbln = 'III';
  }
  elseif ($bln == '04'){
    $rbln = 'IV';
  }
  elseif ($bln == '05'){
    $rbln = 'V';
  }
  elseif ($bln == '06'){
    $rbln = 'VI';
  }
  elseif ($bln == '07'){
    $rbln = 'VII';
  }
  elseif ($bln == '08'){
    $rbln = 'VIII';
  }
  elseif ($bln == '09'){
    $rbln = 'IX';
  }
  elseif ($bln == '10'){
    $rbln = 'X';
  }
  elseif ($bln == '11'){
    $rbln = 'XI';
  }
  elseif ($bln == '12'){
    $rbln = 'XII';
  }
  
  if ($kde2[0] != '0001'){
       $nourut = '0001'.'/DIR/'.$rbln.'/'.$thn1;
    }
    else{
       $nourut = $kde1[0].'/DIR/'.$rbln.'/'.$thn1;
    }
  
  mysql_query("INSERT INTO dis_notadinas(no_nota,
                                   kode_penerima,
                                   hal,
                                   berita,
                                   tglkirim,
                                   kode_pengirim,
                                   ipkomp) 
                            VALUE('$nourut',
                                  '$_POST[nama]',
                                  '$_POST[hal]',
                                  '$_POST[berita]',
                                  '$tgl_sekarang',
                                  '$_SESSION[namauser]',
                                  '$ipkomp')");

  header('location:../../media.php?module='.$module);
}

}
?>
