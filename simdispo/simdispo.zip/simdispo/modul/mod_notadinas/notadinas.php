<script>
function confirmdelete(delUrl) {
   if (confirm("Anda Yakin Ingin Menghapus Nota Dinas Ini?")) {
      document.location = delUrl;
   }
}
</script>
<script>
function validasi(form){
		  if (form.nama.value == 0){
			alert("Anda belum mengisi Bagian Kepada.");
			form.nama.focus();
			return (false);
		  }
		  if (form.subjek.value == 0){
			alert("Anda belum mengisi Bagian Subjek.");
			form.subjek.focus();
			return (false);
		  }
		  if (form.pesan.value == ""){
			alert("Anda belum mengisi Bagian Pesan.");
			form.pesan.focus();
			return (false);
		  }
		  
		  return (true);
}
</script>

<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
    echo "
  <link href='../../css/biru/zalstyle.css' rel='stylesheet' type='text/css'>";

  echo "
  </head>
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='index.php'>&nbsp;&nbsp; <b>ULANGI LAGI</b> &nbsp;&nbsp;</a></p>
  </section>
  </div>";
}
else{

//cek hak akses user
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 OR $_SESSION['leveluser']=='admin'  
     OR $_SESSION['leveluser']=='direksi' 
     OR $_SESSION['leveluser']=='pejabat'){

  $base_url = $_SERVER['HTTP_HOST'];
  $iden=mysql_fetch_array(mysql_query("SELECT * FROM dis_identitas"));

$aksi="modul/mod_notadinas/aksi_notadinas.php";
switch($_GET[act]){
  // Tampil Nota Dinas
  default:
   
   if($_SESSION['leveluser']=='direksi'){
   echo "
   <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DAFTAR NOTA DINAS MASUK</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=notadinas&act=notabaru' class='button'>
        <span>Tulis Nota Dinas Baru</span>
        </a>
        <a href='?module=notadinas&act=terkirim' class='button'>
        <span>Lihat Nota Dinas Terkirim</span>
        </a>
        </div>
	      <table id='table-example' class='table'>
       <thead><tr>	
		
  <th>No</th>
  <th>Nomor</th>
  <th>Tanggal</th>
  <th>Dari</th>
  <th>Hal</th>
  <th>Aksi</th>
  
   </thead>
   <tbody>";
}
else{
  echo "
   <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DAFTAR NOTA DINAS MASUK</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=notadinas&act=terkirim' class='button'>
        <span>Lihat Nota Dinas Terkirim</span>
        </a>
        </div>
	      <table id='table-example' class='table'>
       <thead><tr>	
		
  <th>No</th>
  <th>Nomor</th>
  <th>Tanggal</th>
  <th>Dari</th>
  <th>Hal</th>
  <th>Aksi</th>
  
   </thead>
   <tbody>";
}


    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil=mysql_query("SELECT a.*,b.nama_ptgs as pengirim
                         FROM dis_notadinas a
                         inner join dis_pemakai as b on a.kode_pengirim = b.kode_ptgs
                         WHERE kodenota = 'M' AND
                         kode_penerima = '$_SESSION[namauser]'
                         ORDER BY id_nota DESC");
                         

    $no = $posisi+1;
    while ($r=mysql_fetch_array($tampil)){
    $tgl=tgl_indo($r[tglkirim]);
    $lebar=strlen($no);
    switch($lebar){
      case 1:
      {
        $g="00".$no;
        break;
      }  
      case 2:
      {
        $g="0".$no;
        break;   
      }
      case 3:
      {
        $g=$no;
        break;     
      }      
    } 

    $warna  = 'color:#F33';
    if($_SESSION['leveluser']=='direksi'){
	  if($r[dibaca]=='N'){
    echo "<tr class=gradeX> 
    <td width=50 style='$warna;'><center><b>$g</b></center></td>
	  <td width=150 style='$warna;'><b>$r[no_nota]</a></b></td>
	  <td width=150 style='$warna;'><b>$tgl</a></b></td>
    <td width=150 style='$warna;'><b><a href=?module=notadinas&act=balas&id=$r[id_nota]>$r[pengirim]</a></b></td>
    <td style='$warna;'><b>$r[hal]</b></td>
    <td width=80>";
    
    if ($r[attachment]==''){
	     echo"
       <a href=?module=notadinas&act=balas&id=$r[id_nota] title='Balas Nota Dinas' class='with-tip'><center><img src='img/balas.png'></a>  
       <a href=javascript:confirmdelete('$aksi?module=notadinas&act=hapus&id=$r[id_nota]') 
       title='Hapus' class='with-tip'>&nbsp;<img src='img/hapus.png'></center></a></td></tr>";
    }
    else{
       echo"
       <a href=?module=notadinas&act=balas&id=$r[id_nota] title='Balas Nota Dinas' class='with-tip'><center><img src='img/attachment.png'></a>  
       <a href=javascript:confirmdelete('$aksi?module=notadinas&act=hapus&id=$r[id_nota]') 
       title='Hapus' class='with-tip'>&nbsp;<img src='img/hapus.png'></center></a></td></tr>";
    }  
	  } 
	  else {
    echo "<tr class=gradeX> 
    <td width=50><center>$g</center></td>
	  <td width=100>$tgl</a></td>
    <td width=200><a href=?module=notadinas&act=balas&id=$r[id_nota]>$r[pengirim]</a></td>
	  <td>$r[hal]</td>
	  <td width=80>";
	  if ($r[attachment]==''){
        echo"
        <a href=?module=notadinas&act=balas&id=$r[id_nota] title='Balas Nota Dinas' class='with-tip'>
        <center><img src='img/balas.png'></a>
        <a href=javascript:confirmdelete('$aksi?module=notadinas&act=hapus&id=$r[id_nota]') 
        title='Hapus' class='with-tip'>&nbsp;<img src='img/hapus.png'></center></a></td></tr>";
    }
    else{
        echo"
        <a href=?module=notadinas&act=balas&id=$r[id_nota] title='Balas Nota Dinas' class='with-tip'>
        <center><img src='img/battachment.png'></a>
        <a href=javascript:confirmdelete('$aksi?module=notadinas&act=hapus&id=$r[id_nota]') 
        title='Hapus' class='with-tip'>&nbsp;<img src='img/hapus.png'></center></a></td></tr>";
    }
	  }
	  }
	  else{
    ////////////////
    if($r[dibaca]=='N'){
    echo "<tr class=gradeX> 
    <td width=50 style='$warna;'><center><b>$g</b></center></td>
	  <td width=150 style='$warna;'><b>$r[no_nota]</a></b></td>
	  <td width=150 style='$warna;'><b>$tgl</a></b></td>
    <td width=150 style='$warna;'><b><a href=?module=notadinas&act=balas&id=$r[id_nota]>$r[pengirim]</a></b></td>
    <td style='$warna;'><b>$r[hal]</b></td>
    <td width=80>";
    
    if ($r[attachment]==''){
	     echo"
       <a href=?module=notadinas&act=balas&id=$r[id_nota] title='Balas Nota Dinas' class='with-tip'><center><img src='img/balas.png'></a>  
       </td></tr>";
    }
    else{
       echo"
       <a href=?module=notadinas&act=balas&id=$r[id_nota] title='Balas Nota Dinas' class='with-tip'><center><img src='img/attachment.png'></a>  
       </td></tr>";
    }  
	  } 
	  else {
    echo "<tr class=gradeX> 
    <td width=50><center>$g</center></td>
    <td width=100>$r[no_nota]</td>
	  <td width=100>$tgl</a></td>
    <td width=200><a href=?module=notadinas&act=balas&id=$r[id_nota]>$r[pengirim]</a></td>
	  <td>$r[hal]</td>
	  <td width=80>";
	  if ($r[attachment]==''){
        echo"
        <a href=?module=notadinas&act=balas&id=$r[id_nota] title='Balas Nota Dinas' class='with-tip'>
        <center><img src='img/balas.png'></a></td></tr>";
    }
    else{
        echo"
        <a href=?module=notadinas&act=balas&id=$r[id_nota] title='Balas Nota Dinas' class='with-tip'>
        <center><img src='img/battachment.png'></a></td></tr>";
    }
	  }
    }
    $no++;
    }
    echo "</table>";
    $jmldata=mysql_num_rows(mysql_query("SELECT * FROM dis_notadinas 
                         WHERE kodenota = 'M' AND
                         kode_penerima = '$_SESSION[namauser]'"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

    break;

  //---TULIS NOTA DINAS BARU -----------
   case "notabaru":
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>BUAT NOTA DINAS BARU</h1>
   </div>
   <div class='block-content'>
   
   <form onSubmit='return validasi(this)' id='formnotadinas'
   method=POST action='$aksi?module=notadinas&act=input' enctype='multipart/form-data'>
   
   <p class=inline-small-label> 
   <label for=field4>Untuk</label>
   <select name='nama'>
   <option value=0 selected>Pilih Tujuan</option>";
   $tampil=mysql_query("SELECT * FROM dis_pemakai WHERE level = 'pejabat' ORDER BY nama_ptgs");
   while($r=mysql_fetch_array($tampil)){
   echo "<option value=$r[kode_ptgs]>$r[nama_ptgs]</option></p>"; }
   echo "</select>";
   echo "
         
   <p class=inline-small-label> 
   <label for=field4>Hal</label>
   <input type=text name='hal'>
   </p> 
   <p class=inline-small-label> 
   <label for=field4>Attachment</label>
   <input type=file name='fupload'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Berita</label>
   <textarea name='berita' style='height: 150px;'></textarea>
   </p><br /><br />
   
	 <div class=block-actions> 
   <ul class=actions-right> 
   <li>
   <a class='button red' id=reset-validate-form href='?module=notadinas'>Batal</a>
   </li> </ul>
   <ul class=actions-left> 
   <li>
   <input type='submit' name='fupload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Kirim &nbsp;&nbsp;&nbsp;&nbsp;'>
	 </form>";
	  		  
   break;
	
	 //--BALAS NOTA DINAS --------------- 
	case "balas":
   $tampil = mysql_query("SELECT * FROM dis_notadinas WHERE id_nota='$_GET[id]'");
   $r      = mysql_fetch_array($tampil);
	 
   mysql_query("UPDATE dis_notadinas SET dibaca='Y' WHERE id_nota='$_GET[id]'");

   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>MEMBALAS NOTA DINAS</h1>
   </div>
   <div class='block-content'>
   
   <form onSubmit='return validasi(this)' id='fornotadinas'
   method=POST action='$aksi?module=notadinas&act=input' enctype='multipart/form-data'>
            
   <p class=inline-small-label> 
   <label for=field4>Kepada</label>
   <input type=text name='nama' value='$r[kode_pengirim]' readonly>
   </p> 
   		 
   <p class=inline-small-label> 
   <label for=field4>Hal</label>
  <input type=text name='hal' value='Re: $r[hal]' readonly>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Berita</label>
   <textarea name='berita' style='height: 350px;'>
   
   
   --------------------------------------------------------
   Dari : $r[kode_pengirim]
   $r[berita]</textarea>
   </p> 
   
	  
     <div class=block-actions> 
      <ul class=actions-right> 
      <li>
      <a class='button red' id=reset-validate-form href='?module=notadinas'>Batal</a>
      </li> </ul>
      <ul class=actions-left> 
      <li>
     <input type='submit' name='fupload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Kirim &nbsp;&nbsp;&nbsp;&nbsp;'>
	  </form>";
	  		  
     break;
     
     
	//---NOTA DINAS TERKIRIM -----------
   case "terkirim":
   if($_SESSION['leveluser']=='direksi'){
   echo "
   <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DATA NOTA DINAS TERKIRIM</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=notadinas&act=notabaru' class='button'>
        <span>Tulis Nota Dinas Baru</span>
        </a>
        <a href='?module=notadinas' class='button'>
        <span>Lihat Nota Dinas Masuk</span>
        </a>
        </div>
	      <table id='table-example' class='table'>
       <thead><tr>	
		
  <th>No</th>
  <th>Nomor</th>
  <th>Tanggal</th>
  <th>Kepada</th>
  <th>Hal</th>
  <th>Aksi</th>
  
   </thead>
   <tbody>";
}
else{
 echo "
   <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DATA NOTA DINAS TERKIRIM</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=notadinas' class='button'>
        <span>Lihat Nota Dinas Masuk</span>
        </a>
        </div>
	      <table id='table-example' class='table'>
       <thead><tr>	
		
  <th>No</th>
  <th>Nomor</th>
  <th>Tanggal</th>
  <th>Untuk</th>
  <th>Hal</th>
  <th>Aksi</th>
   </thead>
   <tbody>";
}

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil=mysql_query("SELECT a.*,b.nama_ptgs as penerima
                         FROM dis_notadinas a
                         inner join dis_pemakai as b on a.kode_penerima = b.kode_ptgs
                         WHERE kode_pengirim = '$_SESSION[namauser]'
                         ORDER BY id_nota DESC");

    $no = $posisi+1;
    while ($r=mysql_fetch_array($tampil)){
    $tgl=tgl_indo($r[tglkirim]);
    $lebar=strlen($no);
    switch($lebar){
      case 1:
      {
        $g="00".$no;
        break;
      }  
      case 2:
      {
        $g="0".$no;
        break;   
      }
      case 3:
      {
        $g=$no;
        break;     
      }      
    } 
    $warna  = 'color:#F33';
    if($_SESSION['leveluser']=='direksi'){
	  if($r[dibaca]=='N'){
    echo "<tr class=gradeX> 
    <td width=50 style='$warna;'><center><b>$g</b></center></td>
    <td width=100 style='$warna;'><b>$r[no_nota]</b></td>
	  <td width=100 style='$warna;'><b>$tgl</a></b></td>
    <td width=150 style='$warna;'><b>$r[penerima]</b></td>
    <td style='$warna;'><b>$r[hal]</b></td>
    <td width=30>
    <a href=javascript:confirmdelete('$aksi?module=notadinas&act=hapus&id=$r[id_nota]') 
    title='Hapus' class='with-tip'><center><img src='img/hapus.png'></center></a></td></tr>";
    } 
	  else {
    echo "<tr class=gradeX> 
    <td width=50><center>$g</center></td>
	  <td width=100 style='$warna;'><b>$r[no_nota]</b></td>
	  <td width=100>$tgl</a></td>
    <td width=200>$r[penerima]</td>
	  <td>$r[hal]</td>
	  <td width=30>
    <a href=javascript:confirmdelete('$aksi?module=notadinas&act=hapus&id=$r[id_nota]') 
    title='Hapus' class='with-tip'><center><img src='img/hapus.png'></center></a></td></tr>";
    }
    }
    else{
    if($r[dibaca]=='N'){
    echo "<tr class=gradeX> 
    <td width=50 style='$warna;'><center><b>$g</b></center></td>
	  <td width=100 style='$warna;'><b>$r[no_nota]</b></td>
	  <td width=100 style='$warna;'><b>$tgl</a></b></td>
    <td width=150 style='$warna;'><b>$r[penerima]</b></td>
    <td style='$warna;'><b>$r[hal]</b></td>
    <td width=30>
    <a href=javascript:confirmdelete('$aksi?module=notadinas&act=hapus&id=$r[id_nota]') 
    title='Hapus' class='with-tip'><center><img src='img/hapus.png'></center></a></td></tr>";
    } 
	  else {
    echo "<tr class=gradeX> 
    <td width=50><center>$g</center></td>
	  <td width=100 style='$warna;'><b>$r[no_nota]</b></td>
	  <td width=100>$tgl</a></td>
    <td width=200>$r[penerima]</td>
	  <td>$r[hal]</td>
	  <td width=30>
    <a href=javascript:confirmdelete('$aksi?module=notadinas&act=hapus&id=$r[id_nota]') 
    title='Hapus' class='with-tip'><center><img src='img/hapus.png'></center></a></td></tr>";
    }
    }
    
	  $no++;
    }
    echo "</table>";
    $jmldata=mysql_num_rows(mysql_query("SELECT * FROM dis_notadinas 
                         WHERE kode_pengirim = '$_SESSION[namauser]' "));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);
	  		  
   break;
    
   }
   }
   }
  ?>

   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>
