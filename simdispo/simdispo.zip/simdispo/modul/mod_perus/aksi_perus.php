<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../config/koneksi.php";

$module= $_GET[module];
$act   = $_GET[act];
$kode1 = $_POST['groups'];

// Hapus Alamat Pengirim/Penerima Surat
if ($module=='alamatsurat' AND $act=='hapus'){
    mysql_query("DELETE FROM dis_perus WHERE id_perus='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input Alamat Pengirim/Penerima Surat
 elseif ($module=='alamatsurat' AND $act=='input'){
    $thn  = date("y"); //tahun 2 digit
	  $bln  = date("m"); //bulan 2 digit
  	$thn1 = date("Y"); //tahun 4 digit
	  $qr	  = mysql_query("SELECT MAX(CONCAT(LPAD((RIGHT((nomor),6)+1),6,'0'))) FROM dis_perus WHERE groups = '$kode1'");
    $qr2  = mysql_query("SELECT MIN(CONCAT(LPAD((RIGHT((nomor),6)),6,'0'))) FROM dis_perus WHERE groups = '$kode1'");
    $kde  = mysql_fetch_array($qr);
    $kde2 = mysql_fetch_array($qr2);
   	
	if ($kde2[0] != '000001'){
       $nourut = $kode1.'-'.'000001';
    }
    else{
       $nourut = $kode1.'-'.$kde[0];
    }       
     mysql_query("INSERT INTO dis_perus (groups,
                                   nomor,
                                   nama,
                                   alamat,
                                   kota,
                                   kodepos,
                                   telp,
                                   fax,
                                   email,
                                   url,
                                   kontak,
                                   jabatan,
                                   alamat1,
                                   kota1,
                                   telp1,
                                   hp,
                                   email1) 
	                       VALUES('$_POST[groups]',
	                              '$nourut',
                                '$_POST[nama]',
                                '$_POST[alamat]',
                                '$_POST[kota]',
                                '$_POST[kodepos]',
                                '$_POST[telp]',
                                '$_POST[faks]',
                                '$_POST[email]',
                                '$_POST[web]',
                                '$_POST[kontak]',
                                '$_POST[jabatan]',
                                '$_POST[alamat1]',
                                '$_POST[kota1]',
                                '$_POST[telp1]',
                                '$_POST[hp]',
                                '$_POST[email1]')");
 
  header('location:../../media.php?module='.$module);
  }

// Update Alamat Pengirim/Penerima Surat
elseif ($module=='alamatsurat' AND $act=='update') {
	   mysql_query("UPDATE dis_perus SET 
		                     groups   = '$_POST[groups]',
                         nama     = '$_POST[nama]',
                         alamat   = '$_POST[alamat]',
                         kota     = '$_POST[kota]',
                         kodepos  = '$_POST[kodepos]',
                         telp     = '$_POST[telp]',
                         fax      = '$_POST[faks]',
                         email    = '$_POST[email]',
                         url      = '$_POST[url]',
                         kontak   = '$_POST[kontak]',
                         jabatan  = '$_POST[jabatan]',
                         alamat1  = '$_POST[alamat1]',
                         kota1    = '$_POST[kota1]',
                         telp1    = '$_POST[telp1]',
                         hp       = '$_POST[hp]',
                         email1   = '$_POST[email1]'
                  WHERE  id_perus  = '$_POST[id]'");
 
 header('location:../../media.php?module='.$module);
	}
   
}

?>
