<script>
function confirmdelete(delUrl) {
   if (confirm("Apakah Anda Yakin Ingin Menghapus Data Alamat Surat Ini?")) {
      document.location = delUrl;
   }
}
</script>
<script>
function validasi(form){
		  if (form.groups.value == 0){
			alert("Anda belum mengisi Kelompok Alamat Surat.");
			form.groups.focus();
			return (false);
		  }
		  if (form.nama.value == 0){
			alert("Anda belum mengisi Nama Alamat Surat.");
			form.nama.focus();
			return (false);
		  }
		  if (form.alamat.value == 0){
			alert("Anda belum mengisi Alamat Alamat Surat.");
			form.alamat.focus();
			return (false);
		  }
		  if (form.kota.value == ""){
			alert("Anda belum mengisi Kota.");
			form.kota.focus();
			return (false);
		  }
		  return (true);
}
</script>

<?php    
session_start();
//Deteksi hanya bisa diinclude, tidak bisa langsung dibuka (direct open)
if(count(get_included_files())==1)
{
	echo "<meta http-equiv='refresh' content='0; url=http://$_SERVER[HTTP_HOST]'>";
	exit("Direct access not permitted.");
}
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

//cek hak akses user
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 
   OR $_SESSION['leveluser']=='pejabat'
	   OR $_SESSION['leveluser']=='arsiparis'
	   OR $_SESSION['leveluser']=='resepsionis'){
	   
   $aksi="modul/mod_perus/aksi_perus.php";
   switch($_GET[act]){
   
   // Tampil JLokasi Arsip
   default:
   echo "";
   
   if (empty($_GET['kata'])){
      //-----------HAK AKES PEJABAT------------------
      echo "
      <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DAFTAR ALAMAT SURAT</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=alamatsurat&act=tambah' class='button'>
        <span>Tambahkan Alamat Surat</span>
        </a>
        </div>
	      <table id='table-example' class='table'>
	      <thead><tr>
      <th>No.</th> 
      <th>N a m a</th>
	    <th>Alamat</th> 
	    <th>Aksi</th>
      </tr> 
      </thead>
      <tbody>";

      $p      = new Paging;
      $batas  = 15;
      $posisi = $p->cariPosisi($batas);
      
      $tampil = mysql_query("SELECT * FROM dis_perus ORDER BY id_perus DESC");
      
      $no = $posisi+1;
      while($r=mysql_fetch_array($tampil)){
      $lebar=strlen($no);
      switch($lebar){
      case 1:
      {
        $g="000".$no;
        break;     
      }
      case 2:
      {
        $g="00".$no;
        break;     
      }
      case 3:
      {
        $g="0".$no;
        break;     
      }
      case 4:
      {
        $g=$no;
        break;     
      }      
    } 
	  
	  echo "<tr class=gradeX> 
   
    <td width=50><center>$g</center></td>
    <td>$r[nama]</td>
	  <td>$r[alamat] $r[kota]</td>";
	  if($_SESSION['leveruser'] =='pejabat'){
	  echo"<td valign=middle width=80>
	  <a href=?module=alamatsurat&act=edit&id=$r[id_perus] rel=tooltip-top title='Edit' class='with-tip'>
    <center><img src='img/edit.png'></a> 
	<a href=javascript:confirmdelete('$aksi?module=alamatsurat&act=hapus&id=$r[id_perus]') title='Hapus' class='with-tip'>
       &nbsp;&nbsp;<img src='img/hapus.png'></center></a>
    </td> </tr> ";
    }
    else{
    echo"<td valign=middle width=80>
	  <a href=?module=alamatsurat&act=edit&id=$r[id_perus] rel=tooltip-top title='Edit' class='with-tip'>
    <center><img src='img/edit.png'></a></center>
	  </td> </tr> ";
    }
  }
  
    $no++; 
	
   echo "</tbody></table> ";

   break; 

  }

   //--INPUT Alamat Pengirim/Penerima Surat-------------  
   case "tambah":
   if ($_SESSION['leveluser']=='pejabat'
	   OR $_SESSION['leveluser']=='arsiparis'
	   OR $_SESSION['leveluser']=='resepsionis'){
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>TAMBAH ALAMAT SURAT</h1>
   </div>
   <div class='block-content'>
   
   <form onSubmit='return validasi(this)' id='formperus' 
   method=POST action='$aksi?module=alamatsurat&act=input' enctype='multipart/form-data'>
	  
   <p class=inline-small-label>
	 <label for=field4>Kelompok</label>
   <select name='groups'>
   <option value=0 selected>Pilih Kelompok</option>";
   $tampil=mysql_query("SELECT * FROM dis_peruskat ORDER BY nm_jenispt");
   while($r=mysql_fetch_array($tampil)){
   echo "<option value=$r[kd_jenispt]>$r[kd_jenispt] - $r[nm_jenispt]</option></p>"; }
   echo "</select>";
   
   echo "
   <p class=inline-small-label> 
   <label for=field4>Nama</label>
   <input type=text name='nama' >
   </p>
   
   <p class=inline-small-label> 
   <label for=field4>Alamat</label>
   <input type=text name='alamat' >
   </p>
   <p class=inline-small-label> 
   <label for=field4>Kota/Kode Pos</label>
   <input style='width:45%' type=text name='kota' > / 
   <input style='width:24%' type=text name='kodepos' >
   </p>
   <p class=inline-small-label> 
   <label for=field4>Telpon/Faxc.</label>
   <input style='width:35%' type=text name='telp' > / 
   <input style='width:34%' type=text name='faks' >
   </p>
   <p class=inline-small-label> 
   <label for=field4>Email</label>
   <input type=text name='email'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Website</label>
   <input type=text name='web'>
   </p><br />
   <p class=inline-small-label> 
   <label for=field4>Kontak Person</label>
   <input type=text name='kontak'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Jabatan</label>
   <input type=text name='jabatan'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Kota</label>
   <input type=text name='kota1' >
   </p>
   <p class=inline-small-label> 
   <label for=field4>Telpon</label>
   <input type=text name='telp1'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Mobile (HP)</label>
   <input type=text name='hp' >
   </p>
   <p class=inline-small-label> 
   <label for=field4>Email</label>
   <input type=text name='email1' size=50>
   </p>";

   echo "<br/><br/><div class=block-actions> 
    <ul class=actions-right> 
    <li>
    <a class='button red' id=reset-validate-form href='?module=alamatsurat'>Batal</a>
    </li> </ul>
    <ul class=actions-left> 
    <li>
   <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
   </form>"; }
   
    else{
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>

   <div class='block-header'>
   <h1>Anda tidak berhak mengakses halaman ini !</h1>
   </div>";  }
	 
   break;
   
   //--EDIT Alamat Pengirim/Penerima Surat -------------
   case "edit":
   $edit=mysql_query("SELECT * FROM dis_perus WHERE id_perus='$_GET[id]'");
   $r=mysql_fetch_array($edit);

   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>EDIT ALAMAT SURAT</h1>
   </div>
   <div class='block-content'>
     
   <form onSubmit='return validasi(this)' id='formperus' 
   method=POST action='$aksi?module=alamatsurat&act=update' enctype='multipart/form-data'>
   <input type=hidden name=id value=$r[id_perus]>
	 
	 <p class=inline-small-label> 
   <label for=field4>Nomor</label>
   <input style='width:35%' type=text name='nomor' value='$r[nomor]' disabled>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Kelompok</label>
   <select name='groups'>";
   $tampil1=mysql_query("SELECT * FROM dis_peruskat ORDER BY nm_jenispt");
   if ($r[groups]==0){
   echo "<option value=0 selected>- Pilih Kelompok -</option>"; }   
   while($x=mysql_fetch_array($tampil1)){
   if ($r[groups]==$x[kd_jenispt]){
   echo "<option value=$x[kd_jenispt] selected>$x[kd_jenispt] - $x[nm_jenispt]</option>";}
   else{
   echo "<option value=$x[kd_jenispt]>$x[kd_jenispt] - $x[nm_jenispt]</option> </p> ";}}
   echo "</select>";
   
   echo "
   <p class=inline-small-label> 
   <label for=field4>Nama</label>
   <input type=text name='nama' value='$r[nama]'>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Alamat</label>
   <input type=text name='alamat' value='$r[alamat]'>
   </p> 
   <p class=inline-small-label> 
   <label for=field4>Kota / Kode Pos</label>
   <input style='width:45%' type=text name='kota' value='$r[kota]'> / 
   <input style='width:24%' type=text name='kodepos' value='$r[kodepos]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Telpon/Faxc.</label>
   <input style='width:35%' type=text name='telp' value='$r[telp]'> / 
   <input style='width:34%' type=text name='faks' value='$r[fax]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Email</label>
   <input type=text name='email' value='$r[email]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Website</label>
   <input type=text name='url' value='$r[url]'>
   </p><br />
   <p class=inline-small-label> 
   <label for=field4>Kontak Person</label>
   <input type=text name='kontak' value='$r[kontak]'>
   </p> 
   <p class=inline-small-label> 
   <label for=field4>Jabatan</label>
   <input type=text name='jabatan' value='$r[jabatan]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Alamat</label>
   <input type=text name='alamat1' value='$r[alamat1]'>
   </p> 
   <p class=inline-small-label> 
   <label for=field4>Kota</label>
   <input type=text name='kota1' value='$r[kota1]'> 
   </p>
   <p class=inline-small-label> 
   <label for=field4>Telpon</label>
   <input type=text name='telp1' value='$r[telp1]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Mobile / HP</label>
   <input type=text name='hp' value='$r[hp]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Email</label>
   <input type=text name='email1' value='$r[email1]'>
   </p><br/>";
	  echo "<br/><div class=block-actions> 
    <ul class=actions-right> 
    <li>
    <a class='button red' id=reset-validate-form href='?module=alamatsurat'>Batal</a>
    </li> </ul>
    <ul class=actions-left> 
    <li>
    <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	</form>";
    
    break;  
   }
   //kurawal akhir hak akses module
   } else {
	echo akses_salah();
   }

   }
   ?>


   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>
