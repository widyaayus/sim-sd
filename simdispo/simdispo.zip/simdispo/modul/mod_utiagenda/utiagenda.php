<script>
function confirmdelete(delUrl) {
   if (confirm("Anda Yakin Ingin Menghapus Data Ini?")) {
      document.location = delUrl;
   }
}
</script>

<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
    echo "
  <link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>";

  echo "
  </head>
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  
  <img src='img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  
  </section>
  
  <section id='error-text'>
  <p><a class='button' href='index.php'>&nbsp;&nbsp; <b>ULANGI LAGI</b> &nbsp;&nbsp;</a></p>
  </section>
  </div>";
}
else{

//cek hak Agenda Kegiatan
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 OR $_SESSION['leveluser']=='direksi' 
     OR $_SESSION['leveluser']=='pejabat'
	   OR $_SESSION['leveluser']=='arsiparis'
     OR $_SESSION['leveluser']=='resepsionis'
     OR $_SESSION['leveluser']=='user'){

$aksi="modul/mod_utiagenda/aksi_utiagenda.php";
switch($_GET[act]){
  // Tampil Jadwal Kegiatan
  default:
  
   echo "
   <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>AGENDA KEGIATAN</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=jadwalkegiatan&act=tambah' class='button'>
        <span>Tambah Agenda Kegiatan</span>
        </a></div>
	      <table id='table-example' class='table'>
	      <thead><tr>	  
		  
   <th>No</th>
   <th>Tanggal</th>
   <th>Kegiatan</th>
	 <th>Tempat</th>
	 <th>Aksi</th>
	 </thead>
   <tbody>";

    $p      = new Paging;
    $batas  = 15;
    $posisi = $p->cariPosisi($batas);

    if (cekrhs==0){
      $tampil=mysql_query("SELECT * FROM dis_myevents1 WHERE YEAR(EventDate) = YEAR(NOW()) ORDER BY EventDate DESC,EventTime ASC");
    }
    else{
      $tampil=mysql_query("SELECT * FROM dis_myevents1 
                           WHERE username='$_SESSION[namauser]'       
                           ORDER BY EventDate DESC,EventTime ASC LIMIT $posisi,$batas");
    }

    $no = $posisi+1;
    while ($r=mysql_fetch_array($tampil)){
      $tgl_mulai   = tgl_indo($r[EventDate]).' Pkl.'.$r[EventTime];
      $tgl_selesai = tgl_indo($r[EventDate2]).' Pkl.'.$r[EventTime2];

    $lebar=strlen($no);
    switch($lebar){
      case 1:
      {
        $g="0".$no;
        break;     
      }
      case 2:
      {
        $g=$no;
        break;     
      }      
    } 
    
   echo "<tr class=gradeX>
   <td width=50><center>$g</center></td>
    <td>$tgl_mulai</td>
    <td>$r[ShortDesc]</td>
    <td>$r[Venue]</td>";
    if($_SESSION['leveluser']=='pejabat'){
       if($_SESSION['arsiparis']=='1'){
          echo"<td width=80>
    <a href=?module=jadwalkegiatan&act=edit&id=$r[ID] title='Edit'  class='with-tip'><img src='img/edit.png'></a>
          <a href=javascript:confirmdelete('$aksi?module=jadwalkegiatan&act=hapus&id=$r[ID]') 
   title='Hapus' class='with-tip'><img src='img/hapus.png'></center></a> 
          </td></tr>";
        }else{
        echo"<td width=50>
        <a href=?module=jadwalkegiatan&act=edit&id=$r[ID] title='Edit' class='with-tip'><center><img src='img/edit.png'></center></a> 
   </td></tr>";
          }
   }else{
   echo"<td width=50>
   <a href=?module=jadwalkegiatan&act=edit&id=$r[ID] title='Edit' class='with-tip'><center><img src='img/edit.png'></center></a> 
   </td></tr>";
   }
   		
      $no++;
    }
    echo "</table>";

    if (cekrhs==0){
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM dis_myevents1"));
    }
    else{
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM dis_myevents1 WHERE username='$_SESSION[namauser]'"));
    }  
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);


    break;

  
  case "tambah":
  
   echo "
  <div id='main-content'>
  <div class='container_12'>

  <div class='grid_12'>
  <div class='block-border'>
  <div class='block-header'>
   
  <h1>TAMBAHKAN JADWAL KEGIATAN</h1>
  </div>
  <div class='block-content'>	
	
  <form method=POST action='$aksi?module=jadwalkegiatan&act=input' enctype='multipart/form-data'>
  <p class=inline-small-label> 
  <label for=field4>Tgl.Mulai</label>";        
  combotgl(1,31,'tgl_mulai',$tgl_skrg);
  combonamabln(1,12,'bln_mulai',$bln_sekarang);
  combothn($thn_sekarang,$thn_sekarang+5,'thn_mulai',$thn_sekarang);
  
  echo "</p> 
  <p class=inline-small-label> 
  <label for=field4>Jam Mulai</label>
  <input type=text name='EventTime'>
  </p>
  
  <p class=inline-small-label> 
  <label for=field4>Tgl.Selesai</label>";        
  combotgl(1,31,'tgl_selesai',$tgl_skrg);
  combonamabln(1,12,'bln_selesai',$bln_sekarang);
  combothn($thn_sekarang,$thn_sekarang+5,'thn_selesai',$thn_sekarang);

   echo "</p>
   <p class=inline-small-label> 
   <label for=field4>Jam Selesai</label>
   <input type=text name='EventTime2'>
   </p>   
   
   <p class=inline-small-label>
	 <label for=field4>Tempat</label>
   <select name='Venue'>
   <option value=0 selected>Pilih Tempat Kegiatan</option>";
   $tampil=mysql_query("SELECT * FROM dis_myevents1_tempat ORDER BY nama_tempat");
   while($r=mysql_fetch_array($tampil)){
   echo "<option value=$r[kode_tempat]>$r[nama_tempat]</option></p>"; }
   echo "</select>";
   
   echo "
   <p class=inline-small-label> 
   <label for=field4>Jumlah Peserta</label>
   <input style = 'width:60%' type=text name='jmlpeserta'> Orang
   </p>
   <p class=inline-small-label> 
   <label for=field4>Kegiatan</label>
  <input type=text name='ShortDesc'>
   </p> 		 
   
   <p class=inline-small-label> 
   <label for=field4>Detail Acara</label>
  <textarea name='LongDesc' style='height: 50px;'></textarea>
   </p> 		 
   <p class=inline-small-label> 
   <label for=field4>Peserta</label>
   <textarea name='LongDesc2' style='height: 50px;'></textarea>
   </p> 
   <p class=inline-small-label> 
   <label for=field4>Catatan</label>
   <textarea name='Notes' style='height: 50px;'></textarea>
   </p><br /> 
   
   <div class=block-actions> 
   <ul class=actions-right> 
   <li>
   <a class='button red' id=reset-validate-form href='?module=jadwalkegiatan'>Batal</a>
   </li> </ul>
   <ul class=actions-left> 
   <li>
   <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
   </li> </ul>
   </form>";
   
    break;
  

  case "edit":
    $edit = mysql_query("SELECT * FROM dis_myevents1 WHERE ID='$_GET[id]'");
    $r    = mysql_fetch_array($edit);

    echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>EDIT JADWAL KEGIATAN</h1>
   </div>
   <div class='block-content'>	
	
   <form method=POST action='$aksi?module=jadwalkegiatan&act=update' enctype='multipart/form-data'>
   <input type=hidden name=id value=$r[ID]>";
	 
	 if ($r[EventDate]=='0000-00-00'){
	  echo "
	  <p class=inline-small-label> 
    <label for=field4>Tgl. Mulai</label>";        
    combotgl(1,31,'tgl_mulai',$tgl_skrg);
    combonamabln(1,12,'bln_mulai',$bln_sekarang);
    combothn($thn_sekarang,$thn_sekarang,'thn_mulai',$thn_sekarang);
	 }
	 else{
	 echo "
   <p class=inline-small-label> 
   <label for=field4>Tgl. Mulai</label> ";  
          $get_tgl=substr("$r[EventDate]",8,2);
          combotgl(1,31,'tgl_mulai',$get_tgl);
          $get_bln=substr("$r[EventDate]",5,2);
          combonamabln(1,12,'bln_mulai',$get_bln);
          $get_thn=substr("$r[EventDate]",0,4);
          $thn_skrg=date("Y");
          combothn($thn_sekarang,$thn_sekarang+5,'thn_mulai',$get_thn);}
    
   echo "
    <p class=inline-small-label> 
    <label for=field4>Jam Mulai</label>
    <input type=text name='EventTime' value='$r[EventTime]'></p>";
     
    if ($r[EventDate2]=='0000-00-00'){
	  echo "
	  <p class=inline-small-label> 
    <label for=field4>Tgl.Selesai</label>";        
    $get_tgl2=substr("$r[EventDate2]",8,2);
          combotgl(1,31,'tgl_selesai',$get_tgl2);
          $get_bln2=substr("$r[EventDate2]",5,2);
          combonamabln(1,12,'bln_selesai',$get_bln2);
          $get_thn2=substr("$r[EventDate2]",0,4);
          $thn_skrg=date("Y");
          combothn($thn_sekarang,$thn_sekarang+5,'thn_selesai',$get_thn2);
	 }
	 else{
	  echo "
    </p> <p class=inline-small-label> 
          <label for=field4>Tgl.Selesai</label>";   
          $get_tgl2=substr("$r[EventDate2]",8,2);
          combotgl(1,31,'tgl_selesai',$get_tgl2);
          $get_bln2=substr("$r[EventDate2]",5,2);
          combonamabln(1,12,'bln_selesai',$get_bln2);
          $get_thn2=substr("$r[EventDate2]",0,4);
          combothn($thn_sekarang,$thn_sekarang+5,'thn_selesai',$get_thn2);}

    echo "</p>
    <p class=inline-small-label> 
    <label for=field4>Jam Selesai</label>
    <input type=text name='EventTime2' value='$r[EventTime2]'>
    </p> 
   <p class=inline-small-label> 
   <label for=field4>Tempat</label>
   <select name='Venue'>";
   $tampil1=mysql_query("SELECT * FROM dis_myevents1_tempat ORDER BY nama_tempat");
   if ($r[Venue]==0){
   echo "<option value=0 selected>- Pilih Tempat Kegiatan -</option>"; }   
   while($x=mysql_fetch_array($tampil1)){
   if ($r[Venue]==$x[kode_tempat]){
   echo "<option value=$x[kode_tempat] selected>$x[nama_tempat]</option>";}
   else{
   echo "<option value=$x[kode_tempat]>$x[nama_tempat]</option> </p> ";}}
   echo "</select>";
   
   echo "
   <p class=inline-small-label> 
   <label for=field4>Jumlah Peserta</label>
   <input style = 'width:60%' type=text name='jmlpeserta' value='$r[jmlpeserta]'> Orang
   </p>	  
   <p class=inline-small-label> 
   <label for=field4>Kegiatan</label>
   <input type=text name='ShortDesc' value='$r[ShortDesc]'>
   </p> 	
   	  
   <p class=inline-small-label> 
   <label for=field4>Detail Acara</label>
   <textarea name='LongDesc' style='height: 50px;'>$r[LongDesc]</textarea>
   </p> 	
  
   <p class=inline-small-label> 
   <label for=field4>Peserta</label>
   <textarea name='LongDesc2' style='height: 50px;'>$r[LongDesc2]</textarea>
   </p> 
   <p class=inline-small-label> 
   <label for=field4>Catatan</label>
   <textarea name='Notes' style='height: 50px;'>$r[Notes]</textarea>
   </p><br />   
      	
   <div class=block-actions> 
   <ul class=actions-right> 
   <li>
   <a class='button red' id=reset-validate-form href='?module=jadwalkegiatan'>Batal</a>
   </li> </ul>
   <ul class=actions-left> 
   <li>
   <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
   </li> </ul>
   </form>";
   
    break;
	
   }
    //kurawal akhir hak akses module
    } else {
	echo akses_salah();
    }
    }
    ?>

   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>
