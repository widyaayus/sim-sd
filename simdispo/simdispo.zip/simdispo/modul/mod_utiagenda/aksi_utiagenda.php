<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

include "../../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus Agenda Kegiatan
if ($module=='agenda' AND $act=='hapus'){
  mysql_query("DELETE FROM dis_myevents1 WHERE ID='$_GET[id]'");  
  header('location:../../media.php?module='.$module);
}

// Input Jadwal Kegiatan
elseif ($module=='jadwalkegiatan' AND $act=='input'){
  $mulai=$_POST[thn_mulai].'-'.$_POST[bln_mulai].'-'.$_POST[tgl_mulai];
  $selesai=$_POST[thn_selesai].'-'.$_POST[bln_selesai].'-'.$_POST[tgl_selesai];
  mysql_query("INSERT INTO dis_myevents1(EventDate,
                                    EventTime,
                                    EventDate2,
                                    EventTime2,
                                    ShortDesc,
                                    LongDesc,
                                    Venue,
                                    jmlpeserta,
                                    LongDesc2,
                                    Notes) 
					                  VALUES('$mulai',
					                         '$_POST[EventTime]',
                                   '$selesai',
                                   '$_POST[EventTime2]',
                                   '$_POST[ShortDesc]',
					                         '$_POST[LongDesc]',
                                   '$_POST[Venue]',
                                   '$_POST[jmlpeserta]',
                                   '$_POST[LongDesc2]',
                                   '$_POST[Notes]')");
  header('location:../../media.php?module='.$module);
}

// Update Jadwal Kegiatan
elseif ($module=='jadwalkegiatan' AND $act=='update'){
  $mulai=$_POST[thn_mulai].'-'.$_POST[bln_mulai].'-'.$_POST[tgl_mulai];
  $selesai=$_POST[thn_selesai].'-'.$_POST[bln_selesai].'-'.$_POST[tgl_selesai];

  mysql_query("UPDATE dis_myevents1 SET EventDate = '$mulai',
                                    EventTime = '$_POST[EventTime]',
                                    EventDate2= '$selesai',
                                    EventTime2= '$_POST[EventTime2]',
                                    ShortDesc = '$_POST[ShortDesc]',
                                    LongDesc  = '$_POST[LongDesc]',
                                    Venue     = '$_POST[Venue]',
                                    jmlpeserta= '$_POST[jmlpeserta]',
                                    LongDesc2 = '$_POST[LongDesc2]',
                                    Notes     = '$_POST[Notes]'        
                           WHERE ID  = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
  }
  
}
?>
