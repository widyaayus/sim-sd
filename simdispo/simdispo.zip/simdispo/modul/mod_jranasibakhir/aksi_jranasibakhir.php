<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];
  
// Hapus 
if ($module=='nasibakhir' AND $act=='hapus'){
    mysql_query("DELETE FROM dis_jra_nasib WHERE id_nasib='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input 
 elseif ($module=='nasibakhir' AND $act=='input'){
     
     mysql_query("INSERT INTO dis_jra_nasib (kode_nasib,
                                   ket_nasib) 
	                       VALUES('$_POST[kode_nasib]',
                                '$_POST[ket_nasib]')");
 
  header('location:../../media.php?module='.$module);
  }

// Update
elseif ($module=='nasibakhir' AND $act=='update') {
	   mysql_query("UPDATE dis_jra_nasib SET 
		                     kode_nasib = '$_POST[kode_nasib]',
		                     ket_nasib  = '$_POST[ket_nasib]'
                  WHERE  id_nasib   = '$_POST[id]'");
 
 header('location:../../media.php?module='.$module);
	}
   
}

?>
