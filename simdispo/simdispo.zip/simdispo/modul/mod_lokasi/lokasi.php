<script>
function confirmdelete(delUrl) {
   if (confirm("Apakah Anda Yakin Ingin Menghapus Data Lokasi Arsip Ini?")) {
      document.location = delUrl;
   }
}
</script>
<script>
function validasi(form){
		  if (form.gustu.value == 0){
			alert("Anda belum mengisi Bagian Unit.");
			form.gustu.focus();
			return (false);
		  }
		  if (form.jenis_lokasi.value == 0){
			alert("Anda belum mengisi Bagian Jenis Surat.");
			form.jenis_lokasi.focus();
			return (false);
		  }
		  
		  if (form.klas.value == 0){
			alert("Anda belum mengisi Bagian Klasifikasi.");
			form.klas.focus();
			return (false);
		  }
		  
		  if (form.nama_lokasi.value == ""){
			alert("Anda belum mengisi Bagian Nama Lokasi.");
			form.nama_lokasi.focus();
			return (false);
		  }
		  return (true);
}
</script>

<?php    
session_start();
//Deteksi hanya bisa diinclude, tidak bisa langsung dibuka (direct open)
if(count(get_included_files())==1)
{
	echo "<meta http-equiv='refresh' content='0; url=http://$_SERVER[HTTP_HOST]'>";
	exit("Direct access not permitted.");
}
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

//cek hak akses user
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 
   OR $_SESSION['leveluser']=='admin'
   OR $_SESSION['leveluser']=='pejabat'){
	   
   $aksi="modul/mod_lokasi/aksi_lokasi.php";
   switch($_GET[act]){
   
   // Tampil lokasi
   default:
   echo "";

   if (empty($_GET['kata'])){
      if ($_SESSION['leveluser']=='admin'){
	  echo "
	      <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DATA LOKASI PENYIMPANAN ARSIP</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=lokasiarsip&act=tambahlokasi' class='button'>
        <span>Tambahkan Lokasi</span></a>
        </div>
	      <table id='table-example' class='table'>
      <thead><tr>
      <th>No.</th> 
      <th>Kode</th>
	  <th>Lokasi</th> 
	  <th>Aksi</th>
      </tr> 
      </thead>
      <tbody>";

      $p      = new Paging;
      $batas  = 15;
      $posisi = $p->cariPosisi($batas);
      
      $tampil = mysql_query("SELECT * FROM dis_lokasi ORDER BY id_lokasi DESC");
      
      $no = $posisi+1;
      while($r=mysql_fetch_array($tampil)){
      $lebar=strlen($no);
      switch($lebar){
      case 1:
      {
        $g="00".$no;
        break;     
      }
      case 2:
      {
        $g="0".$no;
        break;     
      }
      case 3:
      {
        $g=$no;
        break;     
      }      
    } 
	
    echo "<tr class=gradeX> 
    <td width=50><center>$g</center></td>
    <td>$r[kode_lokasi]</td>
	<td>$r[nama_lokasi]</td>
	<td valign=middle width=80>
	<a href=?module=lokasiarsip&act=editlokasi&id=$r[id_lokasi] rel=tooltip-top title='Edit' class='with-tip'>
    <center><img src='img/edit.png'></a> 
	<a href=javascript:confirmdelete('$aksi?module=lokasiarsip&act=hapus&id=$r[id_lokasi]') title='Hapus' class='with-tip'>
       &nbsp;&nbsp;<img src='img/hapus.png'></center></a>
   
    </td> </tr> ";
  
    $no++; }
	
   echo "</tbody></table> ";

   break;  }
   
   //-----------BUKAN ADMIN------------------
   else{
   echo "
      <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DATA LOKASI PENYIMPANAN ARSIP</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=lokasiarsip&act=tambahlokasi' class='button'>
        <span>Tambahkan Lokasi</span></a>
        </div>
	      <table id='table-example' class='table'>
      <thead><tr>
  
      <th>No.</th> 
      <th>Kode</th>
	  <th>Lokasi</th>
	  <th>Aksi</th>
      </tr> 
      </thead>
      <tbody>";

      $p      = new Paging;
      $batas  = 15;
      $posisi = $p->cariPosisi($batas);
      
      $tampil = mysql_query("SELECT * FROM dis_lokasi ORDER BY id_lokasi DESC");
      
      $no = $posisi+1;
      while($r=mysql_fetch_array($tampil)){
      $lebar=strlen($no);
      switch($lebar){
      case 1:
      {
        $g="00".$no;
        break;     
      }
      case 2:
      {
        $g="0".$no;
        break;     
      }
      case 3:
      {
        $g=$no;
        break;     
      }      
    } 
	
    echo "<tr class=gradeX> 
   
    <td width=50><center>$g</center></td>
    <td>$r[kode_lokasi]</td>
	<td>$r[nama_lokasi]</td>
	<td valign=middle width=50>
	<a href=?module=lokasiarsip&act=editlokasi&id=$r[id_lokasi] rel=tooltip-top title='Edit' class='with-tip'>
    <center><img src='img/edit.png'></center></a> 
    </td> </tr> ";
  
    $no++; }
	
   echo "</tbody></table> ";

   break;  }
   }

   //--INPUT lokasi -------------  
   case "tambahlokasi":
   if ($_SESSION[leveluser]=='admin'
      OR $_SESSION[leveluser]=='pejabat'){
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>TAMBAH DATA LOKASI ARSIP</h1>
   </div>
   <div class='block-content'>
   
   <form onSubmit='return validasi(this)' id='formlokasi' 
   method=POST action='$aksi?module=lokasiarsip&act=input' enctype='multipart/form-data'>
	  
   <p class=inline-small-label> 
   <label for=field4>Unit</label>
   <select name='gustu'>
   <option value=0 selected>Pilih Unit</option>";
   $tampil=mysql_query("SELECT * FROM dis_unit ORDER BY id_unit");
   while($r=mysql_fetch_array($tampil)){
   echo "<option value=$r[id_unit]>$r[nm_jbtan] - [$r[id_unit]]</option></p>"; }
   
   echo "</select>";
   
   echo " 
   <p class=inline-small-label> 
   <label for=field4>Jenis Surat</label>
   <select name='jenis_lokasi'>
   <option value=0 selected>Pilih Jenis Surat</option>";
   $tampil=mysql_query("SELECT * FROM dis_surat_jenis ORDER BY id_jns");
   while($r=mysql_fetch_array($tampil)){
   echo "<option value=$r[kode_jns]>$r[ket_jns]</option></p>"; }
   
   echo "</select>";
   
   echo " 
   <p class=inline-small-label> 
   <label for=field4>Klasifikasi</label>
   <select name='klas'>
   <option value=0 selected>Pilih Klasifikasi</option>";
   $tampil=mysql_query("SELECT * FROM dis_jra ORDER BY jra_kode");
   while($r=mysql_fetch_array($tampil)){
   echo "<option value=$r[jra_kode]>$r[jra_kode]</option></p>"; }
   
   echo "</select>";
   
   echo " 	  
   <p class=inline-small-label> 
   <label for=field4>Nama Lokasi</label>
   <input type=text name='nama_lokasi'>
   </p> 

   <p class=inline-small-label> 
   <label for=field4>Keterangan</label>
   <textarea name='catat_lokasi' style='height: 150px;'></textarea>
   </p><br/>";
	  

   echo "<br/><br/><div class=block-actions> 
    <ul class=actions-right> 
    <li>
    <a class='button red' id=reset-validate-form href='?module=lokasiarsip'>Batal</a>
    </li> </ul>
    <ul class=actions-left> 
    <li>
   <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
   </form>"; }
   
    else{
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>

   <div class='block-header'>
   <h1>Anda tidak berhak mengakses halaman ini !</h1>
   </div>";  }
	 
   break;
   
   //--EDIT Lokasi -------------
   case "editlokasi":
   $edit=mysql_query("SELECT * FROM dis_lokasi WHERE id_lokasi='$_GET[id]'");
   $r=mysql_fetch_array($edit);

   //----- AWAL leveluser admin----------
   if($_SESSION[leveluser]=='admin'
      OR $_SESSION[leveluser]=='pejabat'){
	  
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>EDIT DATA LOKASI PENYIMPANAN ARSIP</h1>
   </div>
   <div class='block-content'>
     
   <form onSubmit='return validasi(this)' id='formlokasi' 
   method=POST action='$aksi?module=lokasiarsip&act=update' enctype='multipart/form-data'>
   <input type=hidden name=id value=$r[id_lokasi]>
	  
   <p class=inline-small-label> 
   <label for=field4>Kode</label>
   <input type=text name='kode_lokasi' value='$r[kode_lokasi]' disabled>
    <input type=hidden name=kode_lokasi value=$r[kode_lokasi]>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Unit</label>
   <select name='gustu'>";
   $tampil1=mysql_query("SELECT * FROM dis_unit ORDER BY id_unit");
   if ($r[unit_lokasi]==0){
   echo "<option value=0 selected>- Pilih Unit -</option>"; }   

   while($x=mysql_fetch_array($tampil1)){
   if ($r[unit_lokasi]==$x[id_unit]){
   echo "<option value=$x[id_unit] selected>$x[nm_jbtan] - [$x[id_unit]]</option>";}
   else{
   echo "<option value=$x[id_unit]>$x[nm_jbtan] - [$x[id_unit]]</option> </p> ";}}
   echo "</select>";

   echo "
   <p class=inline-small-label> 
   <label for=field4>Jenis Surat</label>
   <select name='jenis_lokasi'>";
   $tampil1=mysql_query("SELECT * FROM dis_surat_jenis ORDER BY id_jns");
   if ($r[jenis_lokasi]==0){
   echo "<option value=0 selected>- Pilih Jenis Surat -</option>"; }   

   while($x=mysql_fetch_array($tampil1)){
   if ($r[jenis_lokasi]==$x[kode_jns]){
   echo "<option value=$x[kode_jns] selected>$x[ket_jns]</option>";}
   else{
   echo "<option value=$x[kode_jns]>$x[ket_jns]</option> </p> ";}}
   echo "</select>";

   echo "
   <p class=inline-small-label> 
   <label for=field4>Klasifikasi</label>
   <select name='klas'>";
   $tampil1=mysql_query("SELECT * FROM dis_jra ORDER BY jra_kode");
   if ($r[klas_lokasi]==0){
   echo "<option value=0 selected>- Pilih Klasifikasi -</option>"; }   

   while($x=mysql_fetch_array($tampil1)){
   if ($r[klas_lokasi]==$x[jra_kode]){
   echo "<option value=$x[jra_kode] selected>$x[jra_kode]</option>";}
   else{
   echo "<option value=$x[jra_kode]>$x[jra_kode]</option> </p> ";}}
   echo "</select>";

   echo "
   <p class=inline-small-label> 
   <label for=field4>Nama Lokasi</label>
   <input type=text name='nama_lokasi' value='$r[nama_lokasi]'>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Keterangan</label>
   <textarea name='catat_lokasi' style='height: 150px;'>$r[catat_lokasi]</textarea>
   </p><br/>";
	
	echo "<br/><div class=block-actions> 
    <ul class=actions-right> 
    <li>
    <a class='button red' id=reset-validate-form href='?module=lokasiarsip'>Batal</a>
    </li> </ul>
    <ul class=actions-left> 
    <li>
    <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	</form>";
    }     
	
    break;  
   }
   //kurawal akhir hak akses module
   } else {
	echo akses_salah();
   }

   }
   ?>


   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>
