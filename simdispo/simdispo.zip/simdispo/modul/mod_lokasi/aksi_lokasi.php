<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";
}
  
else{
include "../../config/koneksi.php";
include "../../config/library.php";

$module=$_GET[module];
$act=$_GET[act];

     
// Hapus lokasi
if ($module=='lokasiarsip' AND $act=='hapus'){
    $hapus = mysql_query("SELECT kode_lokasi FROM dis_lokasi 
            WHERE id_lokasi='$_GET[id]'");
    $r=mysql_fetch_array($hapus);
    $folder = '../../files/';
    $kode = $r[kode_lokasi];
    //hapus folder
    rmdir($folder.$kode);
    //hapus data
    mysql_query("DELETE FROM dis_lokasi WHERE id_lokasi='$_GET[id]'");
    
  header('location:../../media.php?module='.$module);
}

// Input lokasi
 elseif ($module=='lokasiarsip' AND $act=='input'){
     // Pengaturan kode lokasi
    // Kode = SKR.M.AK.001
    $folder = '../../files/';
    $kode1= $_POST[gustu]; 
    $kode2= $_POST[jenis_lokasi];
    $kode3= $_POST[klas];  
    $kode = $kode1.$kode2.$kode3;
    $folderbaru = $folder.$kode;
    
     mysql_query("INSERT INTO dis_lokasi(kode_lokasi,
                                 nama_lokasi,
                                 unit_lokasi,
                                 jenis_lokasi,
                                 klas_lokasi,
                                 catat_lokasi,
                                 ptgs_lokasi,
                                 tgl_lokasi) 
	                       VALUES('$kode',
                                '$_POST[nama_lokasi]',
                                '$_POST[gustu]',
                                '$_POST[jenis_lokasi]',
                                '$_POST[klas]',
								                '$_POST[catat_lokasi]',
                                '$_SESSION[namaluser]',
                                '$tgl_sekarang')");
    //buat folder baru 
    mkdir('../../files/'.$kode,0755);
     
  header('location:../../media.php?module='.$module);
  }

// Update lokasi
elseif ($module=='lokasiarsip' AND $act=='update') {
	mysql_query("UPDATE dis_lokasi SET 
		                           nama_lokasi   = '$_POST[nama_lokasi]',
								               catat_lokasi  = '$_POST[catat_lokasi]' 
                            WHERE  id_lokasi = '$_POST[id]'");
	
   header('location:../../media.php?module='.$module);
}
}

?>
