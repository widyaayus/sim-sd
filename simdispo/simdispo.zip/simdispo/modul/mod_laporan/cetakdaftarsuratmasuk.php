<body onload="window.print()">
<?php
error_reporting(0);
session_start();
include "../config/koneksi.php"; 
include "../config/fungsi_indotgl.php"; 
?>
<table class="basic"  border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
  	<td width="65" rowspan="6"><img src="logo.jpg" width="100"></td>
    <td width="550" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><h2>RAMADANI TRAVEL AND TOUR</h2></td>
  </tr>
  <tr>
    <td align="center"><p>Jl. Goa Ria Ruko Griya Blok A No.3 Sudiang Makassar <br> Telp/Fax. 0411-550956 HP: 0811 420 2201, 0812 4325 8438  
	Email: ramadanitravel@yahoo.com, www.ramadanitravel.com</p></td>
  </tr>  
</table>
<hr><table class="basic" width="630" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>
<?php
$panjang=strlen($_GET[bln_mulai]);
if ($lebar = 1){
	$blnm = '0'.$_GET[bln_mulai];
}else{
	$blnm = $_GET[bln_mulai];
}	

$panjang=strlen($_GET[bln_selesai]);
if ($lebar = 1){
	$blns = '0'.$_GET[bln_selesai];
}else{
	$blns = $_GET[bln_selesai];
}
?>
    <h3>Laporan Penjualan Periodik : <?php echo "$_GET[tgl_mulai]-$blnm-$_GET[thn_mulai] s/d $_GET[tgl_selesai]-$blns-$_GET[thn_selesai]"; ?></h3></td>
  </tr>
</table><br>
<?php
$tglpertama = 	$_GET[thn_mulai].'-'.$blnm.'-'.$_GET[tgl_mulai];
$tglkedua   = 	$_GET[thn_selesai].'-'.$blns.'-'.$_GET[tgl_selesai];
	  echo "<table width=100% border=1>
							<tr bgcolor=#cecece>
								<th>No</th>
								<th>Kode</th>
								<th>Nama Agen</th>
								<th>Tanggal Transaksi</th>
								<th>Nama Maskapai</th>
								<th>Rute</th>
								<th>Harga NTA</th>
								<th>Nama Penumpang</th>
								<th>Waktu Input Transaksi</th>
							</tr>";
				$mapel = mysql_query("SELECT * FROM rb_transaksi a JOIN rb_agen b ON a.id_agen=b.id_agen where a.tanggal_transaksi BETWEEN '$tglpertama' AND '$tglkedua' ORDER BY a.id_transaksi DESC");
				$no = 1;
				while ($r = mysql_fetch_array($mapel)){
						echo "<tr>
								<td>$no</td>
								  <td>$r[kode_booking]</td>
								  <td>$r[nama_agen]</td>
								  <td>".tgl_indo($r[tanggal_transaksi])."</td>
								  <td><center>$r[nama_maskapai]</center></td>
								  <td><center>$r[rute]</center></td>
								  <td>Rp ".number_format($r[harga_nta])."</td>
								  <td><center>$r[nama_penumpang]</center></td>
								  <td><center>$r[waktu]</center></td>
								</tr>";
					$no++;
				}	
				$to = mysql_fetch_array(mysql_query("SELECT sum(harga_nta) as total_harga_nta FROM rb_transaksi a JOIN rb_agen b ON a.id_agen=b.id_agen where a.tanggal_transaksi BETWEEN '$tglpertama' AND '$tglkedua'"));
						echo "<tr bgcolor=lightblue>
								<td colspan=6>Total</td>
								  <td>Rp ".number_format($to[total_harga_nta])."</td>
								  <td><center></center></td>
								  <td><center></center></td>
								</tr>";	
echo "</table><br/><hr>";
?>
<table width=100%>
  <tr>
    <td colspan="2"></td>
    <td width="286"></td>
  </tr>
  <tr>
    <td width="230" align="center"></td>
    <td width="530"></td>
    <td align="center">Mengetahui <br> Ramadani Travel</td>
  </tr>
  <tr>
    <td align="center"></td>
    <td>&nbsp;</td>
    <td align="center" valign="top"><br /><br /><br />
      ( ...................................... )<br />
    </td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table> 
</body>
