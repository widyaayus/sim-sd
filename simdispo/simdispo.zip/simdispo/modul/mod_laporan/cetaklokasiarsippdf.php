<?php  
 
/**
 * @author Sutejo, S.Kom
 * @website http://www.isakomputer.com
 * @email bangtejos@yahoo.co.id
 */
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
 
  echo "
  <link href='css/zalstyle.css' rel='stylesheet' type='text/css'>";

  echo "
  </head>
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  
  <img src='img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul ini, Anda harus login dahulu!</p></span><br/>
  
  </section>
  
  <section id='error-text'>
  <p><a class='button' href='index.php'>&nbsp;&nbsp; <b>ULANGI LAGI</b> &nbsp;&nbsp;</a></p>
  </section>
  </div>";
  
  }
  else{
error_reporting(0);

 //Panggil library FPDF
require_once("../../fpdf17/fpdf.php");
include "../../config/fungsi_indotgl.php";

class FPDF_AutoWrapTable extends FPDF {
  	private $data = array();
  	private $options = array(
  		'filename' => '',
  		'destinationfile' => '',
  		'paper_size'=>'A4',
  		'orientation'=>'P'
  	);
 
  	function __construct($data = array(), $options = array()) {
    	parent::__construct();
    	$this->data = $data;
    	$this->options = $options;
	}
 
	public function rptDetailData () {
		//
		$border = 0;
		$this->AddPage();
		$this->SetAutoPageBreak(true,50);
		$this->AliasNbPages();
		$left = 30;
 
		//judul
        $idbab= $_POST[id] ;
		$this->Cell(0, 1, " ", "B");
		$this->Ln(20);
		$this->SetFont("", "B", 12);
		$this->SetX($left); $this->Cell(0, 10, 'DAFTAR LOKASI ARSIP', 0, 1,'C');
   	    $this->Ln(10);
 
		$h = 25;
		$left = 80;
		$top = 100;	
		#tableheader
		$this->SetFont("", "B", 8);
		$this->SetFillColor(200,200,200);	
		$left = $this->GetX();
		$this->Cell(30,$h,'NO',1,0,'C',true);
		$this->SetX($left += 30); $this->Cell(80, $h, 'KODE', 1, 0, 'L',true);
		$this->SetX($left += 80); $this->Cell(180, $h, 'LOKASI', 1, 0, 'C',true);
		$this->SetX($left += 180); $this->Cell(180, $h, 'KETERANGAN', 1, 0, 'C',true);
		$this->SetX($left += 180); $this->Cell(70, $h, 'JENIS', 1, 1, 'L',true);
		$this->Ln(2);
 
		$this->SetFont('Arial','',8);
		$this->SetWidths(array(30,80,180,180,70));
		$this->SetAligns(array('C','L','L','L','L'));
    $kosong = ' ';
		$no = 1; 
		$this->SetFillColor(255);

		foreach ($this->data as $baris) {
			$this->Row(
				array($no++, 
				$baris['lok_kode'], 
				$baris['lok_nama'],
				$baris['lok_catat'], 
        $baris['lok_jenis']
			));
		}
		
		#table tanda tangan
    include "../../config/tandatangan.php";
		
		
	}
 
	public function printPDF () {
 
		if ($this->options['paper_size'] == "A4") {
			$a = 8.3 * 72; //1 inch = 72 pt
			$b = 11.5 * 72;
			$this->FPDF($this->options['orientation'], "pt", array($a,$b));
		} else {
			$this->FPDF($this->options['orientation'], "pt", $this->options['paper_size']);
		}
 
	    $this->SetAutoPageBreak(false);
	    $this->AliasNbPages();
	    $this->SetFont("helvetica", "B", 10);
	    //$this->AddPage();
 
	    $this->rptDetailData();
 
	    $this->Output($this->options['filename'],$this->options['destinationfile']);
  	}
 
  	private $widths;
	private $aligns;
 
	function SetWidths($w)
	{
		//Set the array of column widths
		$this->widths=$w;
	}
 
	function SetAligns($a)
	{
		//Set the array of column alignments
		$this->aligns=$a;
	}
 
	function Row($data)
	{
		//Calculate the height of the row
		$nb=0;
		for($i=0;$i<count($data);$i++)
			$nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
		$h=15*$nb;
		//Issue a page break first if needed
		$this->CheckPageBreak($h);
		//Draw the cells of the row
		for($i=0;$i<count($data);$i++)
		{
			$w=$this->widths[$i];
			$a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
			//Save the current position
			$x=$this->GetX();
			$y=$this->GetY();
			//Draw the border
			$this->Rect($x,$y,$w,$h);
			//Print the text
			$this->MultiCell($w,10,$data[$i],0,$a);
			//Put the position to the right of the cell
			$this->SetXY($x+$w,$y);
		}
		//Go to the next line
		$this->Ln($h);
	}
 
	function CheckPageBreak($h)
	{
		//If the height h would cause an overflow, add a new page immediately
		if($this->GetY()+$h>$this->PageBreakTrigger)
			$this->AddPage($this->CurOrientation);
	}
 
	function NbLines($w,$txt)
	{
		//Computes the number of lines a MultiCell of width w will take
		$cw=&$this->CurrentFont['cw'];
		if($w==0)
			$w=$this->w-$this->rMargin-$this->x;
		$wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
		$s=str_replace("\r",'',$txt);
		$nb=strlen($s);
		if($nb>0 and $s[$nb-1]=="\n")
			$nb--;
		$sep=-1;
		$i=0;
		$j=0;
		$l=0;
		$nl=1;
		while($i<$nb)
		{
			$c=$s[$i];
			if($c=="\n")
			{
				$i++;
				$sep=-1;
				$j=$i;
				$l=0;
				$nl++;
				continue;
			}
			if($c==' ')
				$sep=$i;
			$l+=$cw[$c];
			if($l>$wmax)
			{
				if($sep==-1)
				{
					if($i==$j)
						$i++;
				}
				else
					$i=$sep+1;
				$sep=-1;
				$j=$i;
				$l=0;
				$nl++;
			}
			else
				$i++;
		}
		return $nl;
	}
	
	// Page header
function Header()
{
    include "../../config/kopsurat.php";
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-50);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,0,'Halaman '.$this->PageNo().' / {nb}',0,0,'R');
}
} //end of class
 
/* contoh penggunaan dengan data diambil dari database mysql
 * 
 * 1. buatlah database di mysql
 * 2. buatlah tabel 'pegawai' dengan field: nip, nama, alamat, email dan website
 * 3. isikan beberapa contoh data ke tabel pegawai tersebut.
 * 
 * */
 
// Koneksi ke database dan tampilkan datanya
include "../../config/koneksi.php";

#ambil data dari DB dan masukkan ke array
$data = array();
// Query 
$query  = "SELECT * FROM lok ORDER BY lok_kode";

$sql = mysql_query ($query);
$total = 0;
while ($row = mysql_fetch_assoc($sql)) {
	array_push($data, $row);
	
}


//pilihan
$options = array(
	'filename' => '', //nama file penyimpanan, kosongkan jika output ke browser
	'destinationfile' => '', //I=inline browser (default), F=local file, D=download
	'paper_size'=>'A4',	//paper size: F4, A3, A4, A5, Letter, Legal
	'orientation'=>'P' //orientation: P=portrait, L=landscape
);
 
$tabel = new FPDF_AutoWrapTable($data, $options);
$tabel->printPDF();
  }
?>
