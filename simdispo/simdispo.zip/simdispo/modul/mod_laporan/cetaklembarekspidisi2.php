<?php  
 
/**
 * @author Sutejo, S.Kom
 * @website http://www.isakomputer.com
 * @email bangtejos@yahoo.co.id
 */
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
 
  echo "
  <link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>";

  echo "
  </head>
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  
  <img src='img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul ini, Anda harus login dahulu!</p></span><br/>
  
  </section>
  
  <section id='error-text'>
  <p><a class='button' href='index.php'>&nbsp;&nbsp; <b>ULANGI LAGI</b> &nbsp;&nbsp;</a></p>
  </section>
  </div>";
  
  }
  else{
error_reporting(0);

 //Panggil library FPDF
require_once("../../fpdf17/fpdf.php");
include "../../config/library.php";
include "../../config/fungsi_indotgl.php";

class FPDF_AutoWrapTable extends FPDF {
  	private $data = array();
  	private $options = array(
  		'filename' => '',
  		'destinationfile' => '',
  		'paper_size'=>'A4',
  		'orientation'=>'P'
  	);
 
  	function __construct($data = array(), $options = array()) {
    	parent::__construct();
    	$this->data = $data;
    	$this->options = $options;
	}
 
	public function rptDetailData () {
		//
		$border = 0;
		$this->AddPage();
		$this->SetAutoPageBreak(true,50);
		$this->AliasNbPages();
		$left = 30;
 
		//judul
    
	$a=mysql_fetch_array(mysql_query("SELECT * FROM dis_identitas WHERE id_identitas = 1"));
  $b=mysql_fetch_array(mysql_query("SELECT a.*,b.nama,b.alamat,b.kota 
							  FROM dis_masuk_agd a
							  inner join dis_perus as b on a.noperus = b.nomor
							  WHERE nomasuk='$_POST[id]'"));
    
  $idnama   = $a[nama_rs];
  $idalamat = $a[alamat];
  $idkota   = $a[kota];
  $idtelpon = $a[no_telp];
  $idlogo   = $a[logo]; 
  $idbag    = $b[jabatan];
  $idtgl    = $b[tgmasuk];
  $nomor    = $b[nomasuk] ;
  $nama     = $b[nama] ;
  $almt     = $b[alamat];
  $kota     = $b[kota];

  $this->Ln(0);
	$h = 63;
	$h1 = 120;
	$h2 = 200;
	$left = 80;
	$top = 10;	
	
  #tableheader2
		$this->SetFont("Arial", "B", 10);
		$left = $this->GetX();
		//Cell(width,top,judul,1 (garis tabel),1(gantibaris),margin (Left,Center,right),background(true/false);
		$this->Ln(1);
		$this->Cell(300,10,'                '.$idnama,0,0,'L',false);
		$this->SetFont("Arial", "B", 12);
		$this->Cell(200,75,'BUKTI PENGIRIMAN SURAT INTERNAL',0,0,'L',false);
		$this->Ln(10);
		$this->SetFont("Arial", "", 8);
		$this->Cell(300,25,'                    '.$idalamat.' '.$idkota,0,0,'L',false);
		$this->Ln(1);
    $this->Cell(300,50,'                   '.' Telp.: '.$idtelpon,0,0,'L',false);
    $this->SetFont("Arial", "", 10);
    $this->Cell(260,50,'',0,0,'C',false);
    $this->SetFont("Arial", "", 14);
    $this->Cell(90,50,'',0,1,'C',false);
    //$this->Ln(2);
    $this->Cell(550,$h2,'',1,0,'L',false);
    
	  // Logo : left,top,persengambar
		$this->Image('../../logo/'.$idlogo,32,40,40);

		$h = 20;
		$this->Ln(2);
    #tableheader2
		$this->SetFont("", "", 10);
		$left = $this->GetX();
		$this->Cell(200,$h,'   Tanggal/Date : '.tgl_indo($idtgl),1,0,'L',false);
		$this->SetX($left += 200); 
    $this->Cell(350, $h, '  Kode/Code : '.$nomor, 1, 1, 'L',false);
    //$this->Cell(200,$h,'    Surat dari / from: ',0,0,'L',false);
    $this->SetX($left += 5);
    $this->Cell(350,$h,    ' Penerima/Receiver : '.'                                  Tanda Tangan / Signature', 0, 0, 'L',false);
    $this->SetX($left);
    $this->Cell(350,$h+75, ' Tanggal / Date        : '.' ', 0, 0, 'L',false);
    $this->SetX($left);
    $this->Cell(350,$h+150,' Jam / Time             : '.'                               ________________________', 0, 0, 'L',false);
    $this->Cell(350,$h+160,'                                                             nama dan tanda tangan  ', 0, 0, 'L',false);
    
    $this->Ln(0);
    $this->Cell(200,$h1,'',1,0,'L',false);
    
		
    //$this->SetX($left += 200);
    $this->Cell(350,$h1,'',1,0,'L',false);
    $left = $this->GetX();
		//$this->SetX($left += 200); 
    $this->Ln(2);		
    $this->Cell(200,$h,'   Surat dari / from : ',0,1,'L',false);
		$this->Cell(200,$h+50,'   '.$nama,0,1,'L',false);
		
	}
 
	public function printPDF () {
 
		if ($this->options['paper_size'] == "A4") {
			$a = 8.3 * 72; //1 inch = 72 pt
			$b = 11.5 * 72;
			$this->FPDF($this->options['orientation'], "pt", array($a,$b));
		} else {
			$this->FPDF($this->options['orientation'], "pt", $this->options['paper_size']);
		}
 
	    $this->SetAutoPageBreak(false);
	    $this->AliasNbPages();
	    $this->SetFont("helvetica", "B", 10);
	    //$this->AddPage();
 
	    $this->rptDetailData();
 
	    $this->Output($this->options['filename'],$this->options['destinationfile']);
  	}
 
  	private $widths;
	private $aligns;
 
	function SetWidths($w)
	{
		//Set the array of column widths
		$this->widths=$w;
	}
 
	function SetAligns($a)
	{
		//Set the array of column alignments
		$this->aligns=$a;
	}
 
	function Row($data)
	{
		//Calculate the height of the row
		$nb=0;
		for($i=0;$i<count($data);$i++)
			$nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
		$h=15*$nb;
		//Issue a page break first if needed
		$this->CheckPageBreak($h);
		//Draw the cells of the row
		for($i=0;$i<count($data);$i++)
		{
			$w=$this->widths[$i];
			$a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
			//Save the current position
			$x=$this->GetX();
			$y=$this->GetY();
			//Draw the border
			$this->Rect($x,$y,$w,$h);
			//Print the text
			$this->MultiCell($w,10,$data[$i],0,$a);
			//Put the position to the right of the cell
			$this->SetXY($x+$w,$y);
		}
		//Go to the next line
		$this->Ln($h);
	}
 
	function CheckPageBreak($h)
	{
		//If the height h would cause an overflow, add a new page immediately
		if($this->GetY()+$h>$this->PageBreakTrigger)
			$this->AddPage($this->CurOrientation);
	}
 
	function NbLines($w,$txt)
	{
		//Computes the number of lines a MultiCell of width w will take
		$cw=&$this->CurrentFont['cw'];
		if($w==0)
			$w=$this->w-$this->rMargin-$this->x;
		$wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
		$s=str_replace("\r",'',$txt);
		$nb=strlen($s);
		if($nb>0 and $s[$nb-1]=="\n")
			$nb--;
		$sep=-1;
		$i=0;
		$j=0;
		$l=0;
		$nl=1;
		while($i<$nb)
		{
			$c=$s[$i];
			if($c=="\n")
			{
				$i++;
				$sep=-1;
				$j=$i;
				$l=0;
				$nl++;
				continue;
			}
			if($c==' ')
				$sep=$i;
			$l+=$cw[$c];
			if($l>$wmax)
			{
				if($sep==-1)
				{
					if($i==$j)
						$i++;
				}
				else
					$i=$sep+1;
				$sep=-1;
				$j=$i;
				$l=0;
				$nl++;
			}
			else
				$i++;
		}
		return $nl;
	}
	
	// Page header
} //end of class
 
/* contoh penggunaan dengan data diambil dari database mysql
 * 
 * 1. buatlah database di mysql
 * 2. buatlah tabel 'pegawai' dengan field: nip, nama, alamat, email dan website
 * 3. isikan beberapa contoh data ke tabel pegawai tersebut.
 * 
 * */
 
// Koneksi ke database dan tampilkan datanya
include "../../config/koneksi.php";

#ambil data dari DB dan masukkan ke array
$data = array();
// Query 
$query  = "SELECT a.*,b.nama,b.alamat,b.kota 
							  FROM dis_masuk_agd a
							  inner join dis_perus as b on a.noperus = b.nomor
							  WHERE nomasuk='$_GET[id]'";

$sql = mysql_query ($query);
$total = 0;
while ($row = mysql_fetch_assoc($sql)) {
	array_push($data, $row);
}


//pilihan
$options = array(
	'filename' => '', //nama file penyimpanan, kosongkan jika output ke browser
	'destinationfile' => '', //I=inline browser (default), F=local file, D=download
	'paper_size'=>'A4',	//paper size: F4, A3, A4, A5, Letter, Legal
	'orientation'=>'P' //orientation: P=portrait, L=landscape
);
 
$tabel = new FPDF_AutoWrapTable($data, $options);
$tabel->printPDF();
  }
?>
