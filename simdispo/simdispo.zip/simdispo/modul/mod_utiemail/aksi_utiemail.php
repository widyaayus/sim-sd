<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../config/koneksi.php";
include "../../config/library.php";
include "../../config/fungsi_thumb.php";

$module=$_GET[module];
$act=$_GET[act];
$namakomp = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$ipkomp = GetHostByName($REMOTE_ADDR);

// Hapus Email
if ($module=='pesanintranet' AND $act=='hapus'){
  $data=mysql_fetch_array(mysql_query("SELECT attachment FROM dis_email_in WHERE id_pesan='$_GET[id]'"));
  if ($data['attachment']!=''){
  mysql_query("DELETE FROM dis_email_in WHERE id_pesan='$_GET[id]'");
     unlink("../../../attachment/$_GET[namafile]");   
  }
  else{
  mysql_query("DELETE FROM dis_email_in WHERE id_pesan='$_GET[id]'");
  }
  header('location:../../media.php?module='.$module);
}

// Input Email Internal
elseif ($module=='pesanintranet' AND $act=='input'){
  mysql_query("INSERT INTO dis_email_in(kode_penerima,
                                   subjek,
                                   pesan,
                                   tglkirim,
                                   kode_pengirim,
                                   ipkomp) 
                            VALUE('$_POST[nama]',
                                  '$_POST[subjek]',
                                  '$_POST[pesan]',
                                  '$tgl_sekarang',
                                  '$_SESSION[namauser]',
                                  '$ipkomp')");

  header('location:../../media.php?module='.$module);
}

}
?>
