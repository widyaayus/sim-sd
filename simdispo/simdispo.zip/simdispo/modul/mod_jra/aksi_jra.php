<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];
$mulai      = $_POST[thn_mulai].'-'.$_POST[bln_mulai].'-'.$_POST[tgl_mulai];
$akhir      = $_POST[thn_akhir].'-'.$_POST[bln_akhir].'-'.$_POST[tgl_akhir];
  
// Hapus Jadwal Retensi Arsip
if ($module=='jadwalretensi' AND $act=='hapus'){
    mysql_query("DELETE FROM dis_jra WHERE id_jra='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input Jadwal Retensi Arsip
 elseif ($module=='jadwalretensi' AND $act=='input'){
     
     mysql_query("INSERT INTO dis_jra(jra_kode,
                                 jra_msl,
                                 jra_ra,
                                 jra_rin,
                                 jra_nasib,
                                 jra_urai,
                                 jra_ket,
                                 jra_tgl,
                                 jra_sls) 
	                       VALUES('$_POST[jra_kode]',
                                '$_POST[jra_msl]',
                                '$_POST[jra_ra]',
                                '$_POST[jra_rin]',
                                '$_POST[jra_nasib]',
                                '$_POST[jra_urai]',
                                '$_POST[jra_ket]',
                                '$mulai',
                                '$akhir')");
 
  header('location:../../media.php?module='.$module);
  }

// Update Jadwal Retensi Arsip
elseif ($module=='jadwalretensi' AND $act=='update') {
	   mysql_query("UPDATE dis_jra SET 
		                     jra_kode   = '$_POST[jra_kode]',
				                 jra_msl    = '$_POST[jra_msl]',
								         jra_ra     = '$_POST[jra_ra]',
                         jra_rin    = '$_POST[jra_rin]',  
                         jra_nasib  = '$_POST[jra_nasib]',
                         jra_urai   = '$_POST[jra_urai]',
                         jra_ket    = '$_POST[jra_ket]',
                         jra_tgl    = '$mulai',
                         jra_sls    = '$akhir'
                  WHERE  id_jra     = '$_POST[id]'");
 
 header('location:../../media.php?module='.$module);
	}
   
}

?>
