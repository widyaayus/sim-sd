<script>
function confirmdelete(delUrl) {
   if (confirm("Apakah Anda Yakin Ingin Menghapus Data Jadwal Retensi Ini?")) {
      document.location = delUrl;
   }
}
</script>
<script>
function validasi(form){
		  if (form.jra_kode.value == ""){
			alert("Anda belum mengisi Kode.");
			form.jra_kode.focus();
			return (false);
		  }
		  if (form.jra_msl.value == ""){
			alert("Anda belum mengisi Bagian Masalah.");
			form.jra_msl.focus();
			return (false);
		  }
		  if (form.jra_ra.value == ""){
			alert("Anda belum mengisi Bagian Retensi Aktif.");
			form.jra_ra.focus();
			return (false);
		  }
		  if (form.jra_rin.value == ""){
			alert("Anda belum mengisi Bagian Retensi In Aktif.");
			form.jra_rin.focus();
			return (false);
		  }
		  if (form.jra_nasib.value == ""){
			alert("Anda belum mengisi Bagian Nasib Akhir.");
			form.jra_nasib.focus();
			return (false);
		  }
		  return (true);
}
</script>

<?php    
session_start();
//Deteksi hanya bisa diinclude, tidak bisa langsung dibuka (direct open)
if(count(get_included_files())==1)
{
	echo "<meta http-equiv='refresh' content='0; url=http://$_SERVER[HTTP_HOST]'>";
	exit("Direct access not permitted.");
}
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

//cek hak akses user
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 
   OR $_SESSION[leveluser]=='admin'  
    OR $_SESSION[leveluser]=='direksi' 
    OR $_SESSION[leveluser]=='pejabat'
	  OR $_SESSION[leveluser]=='arsiparis'
    OR $_SESSION[leveluser]=='user'){
	   
   $aksi="modul/mod_jra/aksi_jra.php";
   switch($_GET[act]){
   
   // Tampil Jadwal Retensi Arsip
   default:
   echo "";
   
   if (empty($_GET['kata'])){
      //-----------HAK AKESE ADMIN------------------
      if ($_SESSION[leveluser]=='admin'){
	    echo "
      <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DAFTAR JADWAL RETENSI ARSIP (JRA)</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=jadwalretensi&act=tambahjra' class='button'>
        <span>Tambahkan Jadwal Retensi</span></a>
        <a href='modul/mod_laporan/cetakjadwalretensipdf.php' target = _blank class='button'>
        <span>Cetak Jadwal Retensi</span></a>
        </div>
	      <table id='table-example' class='table'>
      <thead><tr>
      <th>No.</th> 
      <th>Kode</th>
	    <th>Masalah</th> 
	    <th>R.Aktif</th> 
	    <th>R.Inaktif</th>
	    <th>Nasib Akhir</th>
      <th>Aksi</th>
      </tr> 
      </thead>
      <tbody>";

      $p      = new Paging;
      $batas  = 15;
      $posisi = $p->cariPosisi($batas);
      
      $tampil = mysql_query("SELECT * FROM dis_jra ORDER BY id_jra DESC");
      
      $no = $posisi+1;
      while($r=mysql_fetch_array($tampil)){
      $lebar=strlen($no);
      switch($lebar){
      case 1:
      {
        $g="00".$no;
        break;     
      }
      case 2:
      {
        $g="0".$no;
        break;     
      }
      case 3:
      {
        $g=$no;
        break;     
      }      
    } 
	  
	  $warna1  = 'background:#9F6; color:#000';
	  $warna2  = 'background:#9E0; color:#000';
    echo "<tr class=gradeX> 
   
    <td width=50><center>$g</center></td>
    <td width=50>$r[jra_kode]</td>
	  <td>$r[jra_msl]</td>
	  <td style='$warna1;'>$r[jra_ra] tahun</td>
	  <td style='$warna2;'>$r[jra_rin] tahun</td>
	  <td>$r[jra_nasib]</td>
	<td valign=middle width=80>
	<a href=?module=jadwalretensi&act=editjra&id=$r[id_jra] rel=tooltip-top title='Edit' class='with-tip'>
    <center><img src='img/edit.png'></a> 
	<a href=javascript:confirmdelete('$aksi?module=jadwalretensi&act=hapus&id=$r[id_jra]') title='Hapus' class='with-tip'>
       &nbsp;&nbsp;<img src='img/hapus.png'></center></a>
   
    </td> </tr> ";
  
    $no++; }
	
   echo "</tbody></table> ";

   break;  }
   
   /*/-----------Hak Akses Direksi, Arsiparis------------------
   elseif ($_SESSION[leveluser]=='direksi'
           OR $_SESSION[leveluser]=='arsiparis'){
      echo "
      <div id='main-content'>
      <div class='container_12'>
      <div class=grid_12> 
      <br/>
      <a href='?module=jadwalretensi&act=tambahjra' class='button'>
      <span>Tambahkan Jadwal Retensi</span>
      </a>
      <a href='modul/mod_laporan/cetakjadwalretensipdf.php' target = _blank class='button'>
      <span>Cetak Jadwal Retensi ke PDF</span>
      </a>
	    </div>
		 
      <div class='grid_12'>
      <div class='block-border'>
      <div class='block-header'>
      <h1>DAFTAR JADWAL RETENSI ARSIP (JRA)</h1>
      <span></span> 
      </div>
      <div class='block-content'>
      <table id='table-example' class='table'> 
      <thead><tr>
      <th>No.</th> 
      <th>Kode</th>
	    <th>Masalah</th> 
	    <th>R.Aktif</th> 
	    <th>R.Inaktif</th>
	    <th>Nasib Akhir</th>
      <th>Aksi</th>
      </tr> 
      </thead>
      <tbody>";

      $p      = new Paging;
      $batas  = 15;
      $posisi = $p->cariPosisi($batas);
      
      $tampil = mysql_query("SELECT * FROM dis_jra ORDER BY id_jra DESC");
      
      $no = $posisi+1;
      while($r=mysql_fetch_array($tampil)){
      $lebar=strlen($no);
      switch($lebar){
      case 1:
      {
        $g="00".$no;
        break;     
      }
      case 2:
      {
        $g="0".$no;
        break;     
      }
      case 3:
      {
        $g=$no;
        break;     
      }      
    } 
	  
	  $warna1  = 'background:#9F6; color:#000';
	  $warna2  = 'background:#9E0; color:#000';
    echo "<tr class=gradeX> 
   
    <td width=50><center>$g</center></td>
    <td width=50>$r[jra_kode]</td>
	  <td>$r[jra_msl]</td>
	  <td style='$warna1;'>$r[jra_ra] tahun</td>
	  <td style='$warna2;'>$r[jra_rin] tahun</td>
	  <td>$r[jra_nasib]</td>
	<td valign=middle width=80>
	<a href=?module=jadwalretensi&act=editjra&id=$r[id_jra] rel=tooltip-top title='Edit' class='with-tip'>
    <center><img src='img/edit.png'></a>
    </td> </tr> ";
  
    $no++; }
	
   echo "</tbody></table> ";

   break;  }
   
   //-----------Hak Akses Pejabat dan User------------------
   elseif ($_SESSION[leveluser]=='admin'){
   echo "
      <div id='main-content'>
      <div class='container_12'>
      <div class=grid_12> 
      <br/>
      <a href='?module=jadwalretensi&act=tambahjra' class='button'>
      <span>Tambahkan Jadwal Retensi</span>
      </a>
      <a href='modul/mod_laporan/cetakjadwalretensipdf.php' target = _blank class='button'>
      <span>Cetak Jadwal Retensi ke PDF</span>
      </a>
	    </div>
		 
      <div class='grid_12'>
      <div class='block-border'>
      <div class='block-header'>
      <h1>DAFTAR JADWAL RETENSI ARSIP (JRA)</h1>
      <span></span> 
      </div>
      <div class='block-content'>
      <table id='table-example' class='table'> 
      <thead><tr>
      <th>No.</th> 
      <th>Kode</th>
	    <th>Masalah</th> 
	    <th>R.Aktif</th> 
	    <th>R.Inaktif</th>
	    <th>Nasib Akhir</th>
      </tr> 
      </thead>
      <tbody>";

      $p      = new Paging;
      $batas  = 15;
      $posisi = $p->cariPosisi($batas);
      
      $tampil = mysql_query("SELECT * FROM dis_jra ORDER BY id_jra DESC");
      
      $no = $posisi+1;
      while($r=mysql_fetch_array($tampil)){
      $lebar=strlen($no);
      switch($lebar){
      case 1:
      {
        $g="00".$no;
        break;     
      }
      case 2:
      {
        $g="0".$no;
        break;     
      }
      case 3:
      {
        $g=$no;
        break;     
      }      
    } 
	  
	  $warna1  = 'background:#9F6; color:#000';
	  $warna2  = 'background:#9E0; color:#000';
    echo "<tr class=gradeX> 
   
    <td width=50><center>$g</center></td>
    <td width=50>$r[jra_kode]</td>
	  <td>$r[jra_msl]</td>
	  <td style='$warna1;'>$r[jra_ra] tahun</td>
	  <td style='$warna2;'>$r[jra_rin] tahun</td>
	  <td>$r[jra_nasib]</td>
    </td> </tr> ";
  
    $no++; }
	
   echo "</tbody></table> ";

   break;  
   } */
   
   //-----------Hak User------------------
   else{
   echo "
      <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DAFTAR JADWAL RETENSI ARSIP (JRA)</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        </div>
	      <table id='table-example' class='table'>
	      <thead><tr>
      <th>No.</th> 
      <th>Kode</th>
	    <th>Masalah</th> 
	    <th>R.Aktif</th> 
	    <th>R.Inaktif</th>
	    <th>Nasib Akhir</th>
      </tr> 
      </thead>
      <tbody>";

      $p      = new Paging;
      $batas  = 15;
      $posisi = $p->cariPosisi($batas);
      
      $tampil = mysql_query("SELECT * FROM dis_jra ORDER BY id_jra DESC");
      
      $no = $posisi+1;
      while($r=mysql_fetch_array($tampil)){
      $lebar=strlen($no);
      switch($lebar){
      case 1:
      {
        $g="00".$no;
        break;     
      }
      case 2:
      {
        $g="0".$no;
        break;     
      }
      case 3:
      {
        $g=$no;
        break;     
      }      
    } 
	  
	  $warna1  = 'background:#9F6; color:#000';
	  $warna2  = 'background:#9E0; color:#000';
    echo "<tr class=gradeX> 
   
    <td width=50><center>$g</center></td>
    <td width=50>$r[jra_kode]</td>
	  <td>$r[jra_msl]</td>
	  <td style='$warna1;'>$r[jra_ra] tahun</td>
	  <td style='$warna2;'>$r[jra_rin] tahun</td>
	  <td>$r[jra_nasib]</td>
    </td> </tr> ";
  
    $no++; }
	
   echo "</tbody></table> ";

   break;
   } 
  }

   //--INPUT Jadwal Retensi -------------  
   case "tambahjra":
   if ($_SESSION['leveluser']=='admin'
          OR $_SESSION['leveluser']=='arsiparis'){
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>TAMBAH JADWAL RETENSI ARSIP</h1>
   </div>
   <div class='block-content'>
   
   <form onSubmit='return validasi(this)' id='formjra' 
   method=POST action='$aksi?module=jadwalretensi&act=input' enctype='multipart/form-data'>
	  
   <p class=inline-small-label> 
   <label for=field4>Kode</label>
   <input style='width:20%' type=text name='jra_kode' size=50>
   </p> 
	 	  
   <p class=inline-small-label> 
   <label for=field4>Masalah</label>
   <input type=text name='jra_msl' >
   </p> 
   <p class=inline-small-label> 
   <label for=field4>Retensi Aktif</label>
   <input style='width:5%' type=text name='jra_ra'> Tahun
   </p>
   <p class=inline-small-label> 
   <label for=field4>Retensi In Aktif</label>
   <input style='width:5%' type=text name='jra_rin'> Tahun
   </p>
   
   <p class=inline-small-label> 
   <label for=field4>Nasib Akhir</label>
   <select name='jra_nasib'>
   <option value='#' selected>Pilih Nasih Akhir</option>";
   $tampil=mysql_query("SELECT * FROM dis_jra_nasib ORDER BY id_nasib");
   while($r=mysql_fetch_array($tampil)){
   echo "<option value=$r[kode_nasib]>$r[kode_nasib]</option></p>"; }
   
   echo "</select>";
   
   echo "
   <p class=inline-small-label> 
   <label for=field4>Uraian</label>
   <textarea name='jra_urai' style='height: 50px;'></textarea>
   </p>
   
   <p class=inline-small-label> 
   <label for=field4>Keterangan</label>
   <textarea name='jra_ket' style='height: 50px;'></textarea>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Tanggal Berlaku</label> ";        
   combotgl(1,31,'tgl_mulai',$tgl_skrg);
   combonamabln(1,12,'bln_mulai',$bln_sekarang);
   combothn($thn_sekarang-5,$thn_sekarang,'thn_mulai',$thn_sekarang);
   echo "
   <p class=inline-small-label> 
   <label for=field4>Tanggal Berakhir</label> ";        
   combotgl(1,31,'tgl_akhir',$tgl_skrg);
   combonamabln(1,12,'bln_akhir',$bln_sekarang);
   combothn($thn_sekarang,$thn_sekarang+10,'thn_akhir',$thn_sekarang);
   echo "</p>";

   echo "<br/><br/><div class=block-actions> 
    <ul class=actions-right> 
    <li>
    <a class='button red' id=reset-validate-form href='?module=jadwalretensi'>Batal</a>
    </li> </ul>
    <ul class=actions-left> 
    <li>
   <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
   </form>"; }
   
    else{
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>

   <div class='block-header'>
   <h1>Anda tidak berhak mengakses halaman ini !</h1>
   </div>";  }
	 
   break;
   
   //--EDIT Jadwal Retensi -------------
   case "editjra":
   $edit=mysql_query("SELECT * FROM dis_jra WHERE id_jra='$_GET[id]'");
   $r=mysql_fetch_array($edit);

   //----- AWAL leveluser admin----------
   if($_SESSION['leveluser']=='admin'
          OR $_SESSION['leveluser']=='arsiparis'){
	  
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>EDIT DATA JADWAL RETENSI ARSIP</h1>
   </div>
   <div class='block-content'>
     
   <form method=POST action='$aksi?module=jadwalretensi&act=update' enctype='multipart/form-data'>
   <input type=hidden name=id value=$r[id_jra]>
	  
   <p class=inline-small-label> 
   <label for=field4>Kode</label>
   <input style='width:20%' type=text name='jra_kode' value='$r[jra_kode]'>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Masalah</label>
   <input type=text name='jra_msl' value='$r[jra_msl]'>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Retensi Aktif</label>
   <input style='width:5%' type=text name='jra_ra' value='$r[jra_ra]'> Tahun
   </p>
   <p class=inline-small-label> 
   <label for=field4>Retensi In Aktif</label>
   <input style='width:5%' type=text name='jra_rin' value='$r[jra_rin]'> Tahun
   </p>
   <p class=inline-small-label> 
   <label for=field4>Nasib Akhir</label>
   <select name='jra_nasib'>";
   $tampil1=mysql_query("SELECT * FROM dis_jra_nasib ORDER BY id_nasib");
   if ($r[kode_nasib]=='#'){
   echo "<option value='#' selected>- Pilih Nasib Akhir -</option>"; }   

   while($x=mysql_fetch_array($tampil1)){
   if ($r[jra_nasib]==$x[kode_nasib]){
   echo "<option value=$x[kode_nasib] selected>$x[kode_nasib]</option>";}
   else{
   echo "<option value=$x[kode_nasib]>$x[kode_nasib]</option> </p> ";}}
   echo "</select>";

   echo "
   <p class=inline-small-label> 
   <label for=field4>Uraian</label>
   <textarea name='jra_urai' style='height: 50px;' >$r[jra_urai]</textarea>
   </p>
   
   <p class=inline-small-label> 
   <label for=field4>Keterangan</label>
   <textarea name='jra_ket' style='height: 50px;'>$r[jra_ket]</textarea>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Tanggal Berlaku</label> ";  
          $get_tgl=substr("$r[jra_tgl]",8,2);
          combotgl(1,31,'tgl_mulai',$get_tgl);
          $get_bln=substr("$r[jra_tgl]",5,2);
          combonamabln(1,12,'bln_mulai',$get_bln);
          $get_thn=substr("$r[jra_tgl]",0,4);
          $thn_skrg=date("Y");
          combothn($thn_sekarang-5,$thn_sekarang,'thn_mulai',$get_thn);
    echo "</p>";
	  echo "<p class=inline-small-label> 
         <label for=field4>Tanggal Berakhir</label> ";  
          $get_tgl=substr("$r[jra_sls]",8,2);
          combotgl(1,31,'tgl_akhir',$get_tgl);
          $get_bln=substr("$r[jra_sls]",5,2);
          combonamabln(1,12,'bln_akhir',$get_bln);
          $get_thn=substr("$r[jra_sls]",0,4);
          $thn_skrg=date("Y");
          combothn($thn_sekarang,$thn_sekarang+10,'thn_akhir',$get_thn);
    echo "</p><br/>";
	  echo "<br/><div class=block-actions> 
    <ul class=actions-right> 
    <li>
    <a class='button red' id=reset-validate-form href='?module=jadwalretensi'>Batal</a>
    </li> </ul>
    <ul class=actions-left> 
    <li>
    <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	</form>";
    }
	//----- AKHIR leveluser admin ----------
	
   else {
	   
   //----- AWAL bukan admin ----------
  		  
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>EDIT DATA JADWAL RETENSI ARSIP</h1>
   </div>
   <div class='block-content'>
     
   <form method=POST action='$aksi?module=jadwalretensi&act=update' enctype='multipart/form-data'>
   <input type=hidden name=id value=$r[id_unit]>
     
   <p class=inline-small-label> 
   <label for=field4>Kode</label>
   <input type=text name='id_unit' value='$r[id_unit]' disabled>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Nama Unit</label>
   <input type=text name='nm_jbtan' value='$r[nm_jbtan]'>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Nama Pejabat</label>
   <input type=text name='nm_pjabat' value='$r[nm_pjabat]'>
   </p><br/>";
	
	echo "<br/><div class=block-actions> 
    <ul class=actions-right> 
    <li>
    <a class='button red' id=reset-validate-form href='?module=jadwalretensi'>Batal</a>
    </li> </ul>
    <ul class=actions-left> 
    <li>
    <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	</form>";
    }     
	
    break;  
   }
   //kurawal akhir hak akses module
   } else {
	echo akses_salah();
   }

   }
   ?>


   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>
