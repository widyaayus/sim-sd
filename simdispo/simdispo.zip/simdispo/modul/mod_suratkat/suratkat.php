<script>
function confirmdelete(delUrl) {
   if (confirm("Apakah Anda Yakin Ingin Menghapus Data Kategori Surat Ini?")) {
      document.location = delUrl;
   }
}
</script>
<script>
function validasi(form){
		  if (form.id_group.value == ""){
			alert("Anda belum mengisi Kode Kategori.");
			form.id_group.focus();
			return (false);
		  }
		  if (form.nm_group.value == 0){
			alert("Anda belum mengisi Nama Kategori.");
			form.nm_group.focus();
			return (false);
		  }
		  
		  return (true);
}
</script>

<?php    
session_start();
//Deteksi hanya bisa diinclude, tidak bisa langsung dibuka (direct open)
if(count(get_included_files())==1)
{
	echo "<meta http-equiv='refresh' content='0; url=http://$_SERVER[HTTP_HOST]'>";
	exit("Direct access not permitted.");
}
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='../../css/biru/style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

//cek hak akses user
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 
   OR $_SESSION['leveluser']=='admin'){
	   
   $aksi="modul/mod_suratkat/aksi_suratkat.php";
   switch($_GET[act]){
   
   // Tampil Kategori Surat
   default:
   echo "";
   
   if (empty($_GET['kata'])){
      echo "
      <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DAFTAR KATEGORI SURAT</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=kategorisurat&act=tambah' class='button'>
        <span>Tambahkan Kategori Surat</span></a>
        </div>
	      <table id='table-example' class='table'>
       <thead><tr>
      <th>No.</th> 
      <th>Kode</th>
	    <th>Nama</th> 
	    <th>Keterangan</th> 
	    <th>Aksi</th>
      </tr> 
      </thead>
      <tbody>";

      $p      = new Paging;
      $batas  = 15;
      $posisi = $p->cariPosisi($batas);
      
      $tampil = mysql_query("SELECT * FROM dis_groupsurat ORDER BY id_group");
      
      $no = $posisi+1;
      while($r=mysql_fetch_array($tampil)){
      $lebar=strlen($no);
      switch($lebar){
      
      case 1:
      {
        $g="0".$no;
        break;     
      }
      case 2:
      {
        $g=$no;
        break;     
      }      
    } 
	  
	  echo "<tr class=gradeX> 
   
    <td width=50><center>$g</center></td>
    <td>$r[id_group]</td>
	  <td>$r[nm_group]</td>
	  <td>$r[ket_group]</td>
	  <td valign=middle width=80>
	  <a href=?module=kategorisurat&act=edit&id=$r[id_group] rel=tooltip-top title='Edit' class='with-tip'>
    <center><img src='img/edit.png'></a> 
	<a href=javascript:confirmdelete('$aksi?module=kategorisurat&act=hapus&id=$r[id_group]') title='Hapus' class='with-tip'>
       &nbsp;&nbsp;<img src='img/hapus.png'></center></a>
   
    </td> </tr> ";
  
    $no++; }
	
   echo "</tbody></table> ";

   break;  
   
  }

   //--INPUT Kategori Surat -------------  
   case "tambah":
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>TAMBAH KATEGORI SURAT</h1>
   </div>
   <div class='block-content'>
   
   <form onSubmit='return validasi(this)' id='formkategori' 
   method=POST action='$aksi?module=kategorisurat&act=input' enctype='multipart/form-data'>
	 
   <p class=inline-small-label> 
   <label for=field4>Kode</label>
   <input style='width:10%' type=text name='id_group'>
   </p> 
	 	  
   <p class=inline-small-label> 
   <label for=field4>Nama</label>
   <input type=text name='nm_group'>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Keterangan</label>
   <textarea name='ket_group' style='height: 50px;'></textarea>
   </p>";

   echo "<br/><br/><div class=block-actions> 
    <ul class=actions-right> 
    <li>
    <a class='button red' id=reset-validate-form href='?module=kategorisurat'>Batal</a>
    </li> </ul>
    <ul class=actions-left> 
    <li>
   <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
   </form>"; 
	 
   break;
   
   //--EDIT Kategori Surat -------------
   case "edit":
   $edit=mysql_query("SELECT * FROM dis_groupsurat WHERE id_group='$_GET[id]'");
   $r=mysql_fetch_array($edit);

   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>EDIT KATEGORI SURAT</h1>
   </div>
   <div class='block-content'>
     
   <form onSubmit='return validasi(this)' id='formkategori' 
   method=POST action='$aksi?module=kategorisurat&act=update' enctype='multipart/form-data'>
   <input type=hidden name=id value=$r[id_group]>
	 
   <p class=inline-small-label> 
   <label for=field4>Kode</label>
   <input style='width:10%' type=text name='lok_kode' value='$r[id_group]' disabled>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Nama Lokasi</label>
   <input type=text name='nm_group' value='$r[nm_group]'>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Keterangan</label>
   <textarea name='ket_group' style='height: 50px;' >$r[ket_group]</textarea>
   </p><br/>";
	  echo "<br/><div class=block-actions> 
    <ul class=actions-right> 
    <li>
    <a class='button red' id=reset-validate-form href='?module=kategorisurat'>Batal</a>
    </li> </ul>
    <ul class=actions-left> 
    <li>
    <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	</form>";
    
    break;  
   }
   //kurawal akhir hak akses module
   } else {
	echo akses_salah();
   }

   }
   ?>


   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>
