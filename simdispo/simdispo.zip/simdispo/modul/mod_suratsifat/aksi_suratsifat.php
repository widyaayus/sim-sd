<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];
  
// Hapus Sifat Surat
if ($module=='sifatsurat' AND $act=='hapus'){
    mysql_query("DELETE FROM dis_surat_sifat WHERE id_sifat='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input Sifat Surat
 elseif ($module=='sifatsurat' AND $act=='input'){
     
     mysql_query("INSERT INTO dis_surat_sifat (kode_sifat,
                                   ket_sifat) 
	                       VALUES('$_POST[kode_sifat]',
                                '$_POST[ket_sifat]')");
 
  header('location:../../media.php?module='.$module);
  }

// Update Sifat Surat
elseif ($module=='sifatsurat' AND $act=='update') {
	   mysql_query("UPDATE dis_surat_sifat SET 
		                     ket_sifat  = '$_POST[ket_sifat]'
                  WHERE  id_sifat     = '$_POST[id]'");
 
 header('location:../../media.php?module='.$module);
	}
   
}

?>
