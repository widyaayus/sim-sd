<script>
function confirmdelete(delUrl) {
   if (confirm("Apakah Anda Yakin Ingin Menghapus Data Surat Keluar Ini?")) {
      document.location = delUrl;
   }
}
</script>
<script>
function validasi(form){
		  if (form.sifat.value == ""){
			alert("Anda belum mengisi Bagian Sifat.");
			form.sifat.focus();
			return (false);
		  }
		  if (form.kodejra.value == 0){
			alert("Anda belum mengisi Bagian Klasifikasi.");
			form.kodejra.focus();
			return (false);
		  }
		  if (form.hal.value == ""){
			alert("Anda belum mengisi Bagian Perihal.");
			form.hal.focus();
			return (false);
		  }
		  if (form.kepada.value == ""){
			alert("Anda belum mengisi Bagian Kepada.");
			form.kepada.focus();
			return (false);
		  }
		  if (form.isi_surat.value == ""){
			alert("Anda belum mengisi Bagian isi Surat.");
			form.isi_surat.focus();
			return (false);
		  }
		  return (true);
}
</script>


<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
 
  echo "
  <link href='../../css/biru/zalstyle.css' rel='stylesheet' type='text/css'>";

  echo "
  </head>
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  
  <img src='img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul ini, Anda harus login dahulu!</p></span><br/>
  
  </section>
  
  <section id='error-text'>
  <p><a class='button' href='index.php'>&nbsp;&nbsp; <b>ULANGI LAGI</b> &nbsp;&nbsp;</a></p>
  </section>
  </div>";
  
  }
  else{

//cek hak akses user dan pastikan semua user boleh mengakses  modul ini
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 
  OR $_SESSION['leveluser']=='direksi'
  OR $_SESSION['leveluser']=='pejabat'
  OR $_SESSION['leveluser']=='arsiparis'){

$aksi="modul/mod_suratkeluar/aksi_suratkeluar.php";
switch($_GET[act]){

  // Tampil Data Surat Keluar
  default:
  echo "";
  
  //----------Jika kata KOSONG ------------------
 if (empty($_GET['kata'])){
	 echo "
	 
	 <div id='main-content'>
        <div class='container_12'>
      
        <div class='grid_12'>
        <div class='block-border'>
        <div class='block-header'>
        <h1>DAFTAR SURAT KELUAR</h1>
        <div id='form-close'>
             <p><a class='button red' href='?module=home'>X</a> </p>
        </div>
        </div>
        <div class='block-content'>
        <div class=grid_12> 
        <a href='?module=suratkeluar&act=tambah' class='button'>
        <span>Tambahkan Data</span>
        </a>
		    <a href='modul/mod_laporan/cetakdaftarsuratkeluarpdf.php' target = _blank class='button'>
        <span>Cetak Daftar Surat Keluar</span>
        </a></div>
	      <table id='table-example' class='table'>
	      <thead><tr>  
        <th>No</th>
        <th>No.Surat</th>
        <th>Kepada</th>
        <th>Perihal</th>
        <th>Aksi</th>
        </thead>
        <tbody>";
   
        $p      = new Paging;
        $batas  = 40;
        $posisi = $p->cariPosisi($batas);
        $tampil = mysql_query("SELECT * FROM dis_keluar 
                 WHERE YEAR(tgkel) = YEAR(now())
                ORDER BY nokel DESC");
	      $no = $posisi+1;
    
        while($r=mysql_fetch_array($tampil)){
        $keluar=tgl_indo($r[tgkel]);
        $lebar=strlen($no);
        switch($lebar){
        case 1:
        {
        $g="000".$no;
        break;     
         }
       case 2:
        {
        $g="00".$no;
        break;     
         }
	    case 3:
         {
        $g="0".$no;
        break;     
        }
        case 4:
        {
        $g=$no;
        break;     
       }      
       } 
       
	           
     if($r[cekproses]==1){
	   $warna  = 'background:#FFFF00; color:#000';  //kuning - proses
	   }
	   else{ 
	   $warna  = 'background:#FF0000; color:#fff';   //warna merah
	   }
	   
     if($r[cekfinal]==1){
	   $warna  = 'background:#f9d3f9; color:#000';  //ungu - final belum disimpan
	   }
	   if($r[cekkirim]==1){
	   $warna  = 'background:#00FF00; color:#000';  //hijau - final,sudah dikirim belum disimpan
	   } 
	   if($r[ceksimpan]==1){
	   $warna  = 'background:#F8F8F8F8; color:#000';  //ABU-ABU - disimpan
	   }
     
	
	     
	   //----------Jika hak akses Direksi ------------------
	  if ($_SESSION['leveluser']=='direksi'){
	   echo "<tr class=gradeX> 
      <td style='$warna;'><center>$g</center></td>
      <td style='$warna;'>$r[nokel]</td>
      <td style='$warna;'>$r[kepada]</td>
	    <td style='$warna;'>$r[hal]</td>
	    <td width=70 style='$warna;'>
      <a href=?module=suratkeluar&act=lihatfile&id=$r[noid] title='Lihat Surat' class='with-tip'>&nbsp;&nbsp;<img src='img/pdf.gif'>
      <a href=?module=suratkeluar&act=edit&id=$r[noid] title='Edit Data' class='with-tip'>&nbsp;<img src='img/edit.png'></a>
      <a href=javascript:confirmdelete('$aksi?module=suratkeluar&act=hapus&id=$r[noid]') title='Hapus Data' class='with-tip'>
      &nbsp;<img src='img/hapus.png'></center></a>   
      </td></tr>";
	   }
		 
		 //----------Jika hak akses Pejabat ------------------
	    elseif($_SESSION['leveluser']=='pejabat'){
	   echo "<tr class=gradeX> 
       <td style='$warna;'><center>$g</center></td>
     <td style='$warna;'>$r[nokel]</td>
      <td style='$warna;'>$r[kepada]</td>
	    <td style='$warna;'>$r[hal]</td>
	    <td width=70 style='$warna;'>
	    <a href=?module=suratkeluar&act=lihatfile&id=$r[noid] title='Lihat Surat' class='with-tip'>&nbsp;&nbsp;<img src='img/pdf.gif'>
      <a href=?module=suratkeluar&act=edit&id=$r[noid] title='Edit Data' class='with-tip'>&nbsp;&nbsp;<img src='img/edit.png'></a>
      </td></tr>";
		}
		//----------Jika hak akses Arsiparis ------------------
	    elseif($_SESSION['leveluser']=='arsiparis'){
		echo "<tr class=gradeX> 
      <td style='$warna;'><center>$g</center></td>
      <td style='$warna;'>$r[nokel]</td>
     <td style='$warna;'>$r[kepada]</td>
	    <td style='$warna;'>$r[hal]</td>
	    <td width=70 style='$warna;'>
	    <a href=?module=suratkeluar&act=lihatfile&id=$r[noid] title='Lihat Surat' class='with-tip'>&nbsp;&nbsp;<img src='img/pdf.gif'></a>   
      <a href=?module=suratkeluar&act=edit&id=$r[noid] title='Edit Data' class='with-tip'>&nbsp;&nbsp;<img src='img/edit.png'></a>
       </td> </tr>";
		}
	   $no++;
       }
   
       echo "</table>";
       $jmldata = mysql_num_rows(mysql_query("SELECT * FROM dis_keluar WHERE YEAR(tgkel) = YEAR(now())"));  
       $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
       $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);
       break;    
      
 }
  
  case "tambah":
  
  echo "
  <div id='main-content'>
  <div class='container_12'>

  <div class='grid_12'>
  <div class='block-border'>
  <div class='block-header'>
   
  <h1>TAMBAH SURAT KELUAR</h1>
  </div>
  <div class='block-content'>

  <form onSubmit='return validasi(this)' id='formsuratkeluar' 
  method=POST action='$aksi?module=suratkeluar&act=input' enctype='multipart/form-data'>
   
   <p class=inline-small-label> 
   <label for=field4>Tanggal Surat</label>";         
   combotgl(1,31,'tgl_kel',$tgl_skrg);
   combonamabln(1,12,'bln_kel',$bln_sekarang);
   combothn($thn_sekarang,$thn_sekarang,'thn_kel',$thn_sekarang);
   echo "</p> 
  
   <p class=inline-small-label> 
   <label for=field4>Sifat Surat</label>
   <select name='sifat'>
   <option value=0 selected>Pilih Sifat Surat</option>";
   $tampil1=mysql_query("SELECT * FROM dis_surat_sifat ORDER BY id_sifat");
   while($r=mysql_fetch_array($tampil1)){
   echo "<option value=$r[kode_sifat]>$r[kode_sifat]</option>"; }
   echo "</select>";
   
   echo"
   Klasifikasi
   <select name='kodejra'>
   <option value=0 selected>Pilih Klasifikasi</option>";
   $tampil2=mysql_query("SELECT * FROM dis_jra ORDER BY jra_kode");
   while($r=mysql_fetch_array($tampil2)){
   echo "<option value=$r[jra_kode]>$r[jra_kode] - $r[jra_msl]</option></p>"; }
   echo "</select>";
   
   echo"
   <p class=inline-small-label> 
   <label for=field4>Lampiran</label>
   <input type=text name='lamp'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Perihal</label>
   <input type=text name='hal'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Kepada</label>
   <textarea name='kepada'  style='height: 50px;'></textarea>
   </p> 	  
     					 
   <p class=inline-small-label> 
   <label for=field4>Isi Surat</label>
   <textarea id='loko' name='isisurat'  style='height: 400px;'></textarea>
   </p> 
   <p class=inline-small-label> 
   <label for=field4>Tembusan</label>
   <textarea name='tembusan'  style='height: 50px;'></textarea>
   </p><br /><br />";

   echo " 
   <div class=block-actions> 
   <ul class=actions-right> 
   <li>
   <a class='button red' id=reset-validate-form href='?module=suratkeluar'>Batal</a>
   </li> </ul>
   <ul class=actions-left> 
   <li>
      <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
   </li> 
   </ul>
	  </form>";
   
   
   break;
    
    
   //-----------------------------EDIT DATA ---------------------------------
  case "edit":
  $edit = mysql_query("SELECT * FROM dis_keluar
							  WHERE noid='$_GET[id]'");
  $r    = mysql_fetch_array($edit);
  
   echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>EDIT SURAT KELUAR</h1>
   </div>
   <div class='block-content'>
   <form onSubmit='return validasi(this)' id='formsuratkeluar' 
   method=POST enctype='multipart/form-data' action=$aksi?module=suratkeluar&act=update>
   <input type=hidden name=id value=$r[noid]>
   
   <p class=inline-small-label> 
   <label for=field4>No.Surat</label>
   <input type=text name='nokel' value='$r[nokel]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Tanggal Surat</label> ";  
          $get_tgl=substr("$r[tgkel]",8,2);
          combotgl(1,31,'tgl_keluar',$get_tgl);
          $get_bln=substr("$r[tgkel]",5,2);
          combonamabln(1,12,'bln_keluar',$get_bln);
          $get_thn=substr("$r[tgkel]",0,4);
          $thn_skrg=date("Y");
          combothn($thn_sekarang,$thn_sekarang+5,'thn_keluar',$get_thn);
    
   echo "
   <p class=inline-small-label> 
   <label for=field4>Sifat Surat</label>
   <select name='sifat'>";
   $tampilx=mysql_query("SELECT * FROM dis_surat_sifat ORDER BY kode_sifat");
   if ($r[jnskel]==0){
   echo "<option value=0 selected>- Pilih Sifat Surat -</option>"; }   
   while($w=mysql_fetch_array($tampilx)){
   if ($r[jnskel]==$w[kode_sifat]){
   echo "<option value=$w[kode_sifat] selected>$w[kode_sifat]</option>";}
   else{
   echo "<option value=$w[kode_sifat]>$w[kode_sifat]</option> </p> ";}}
   echo "</select>";
   
   echo "
   <p class=inline-small-label> 
   <label for=field4>Klasifikasi</label>
   <select name='kodejra'>";
   $tampilx=mysql_query("SELECT * FROM dis_jra ORDER BY jra_kode");
   if ($r[kodejra]==0){
   echo "<option value=0 selected>- Pilih Klasifikasi -</option>"; }   
   while($w=mysql_fetch_array($tampilx)){
   if ($r[kodejra]==$w[jra_kode]){
   echo "<option value=$w[jra_kode] selected>$w[jra_kode] - $w[jra_msl]</option>";}
   else{
   echo "<option value=$w[jra_kode]>$w[jra_kode] - $w[jra_msl]</option> </p> ";}}
   echo "</select>";
   
   echo "
   <p class=inline-small-label> 
   <label for=field4>Lampiran</label>
   <input type=text name='lamp' value='$r[lamp]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Perihal</label>
   <input type=text name='hal' value='$r[hal]'>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Kepada</label>
   <textarea name='kepada'  style='height: 50px;'>$r[kepada]</textarea>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Isi Ringkas</label>
   <textarea id='loko' name='isisurat' style='height: 400px;'>$r[isisurat]</textarea>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Tembusan</label>
   <textarea name='tembusan'  style='height: 50px;'>$r[tembusan]</textarea>
   </p>
   <p class=inline-small-label> 
   <label for=field4>Nama File</label>
   <input type=text name='file' value='$r[file]' disabled>
   </p> 	
   <p class=inline-small-label> 
   <label for=field4>Ganti File</label>
   <input type=file name='fupload' ></br>
   <small><b>Perhatian:</b> Apabila file tidak diubah, dikosongkan saja</small>
   </p>";
  
   if ($r[ceksimpan]==1){
      echo "
      <p class=inline-small-label> 
      <label for=field4>Disimpan</label>
      <input type=radio name='ceksimpan' value=1 checked> Ya
      <input type=radio name='ceksimpan' value=0 > Tidak</p>";
      }
   else{
      echo "
      <p class=inline-small-label>
      <label for=field4>Disimpan</label>
      <input type=radio name='ceksimpan' value=1 > Ya
      <input type=radio name='ceksimpan' value=0 checked> Tidak</p>";
      }
	 if ($r[cekkirim]==1){
      echo "
      <p class=inline-small-label> 
      <label for=field4>Dikirim</label>
      <input type=radio name='cekkirim' value=1 checked> Ya
      <input type=radio name='cekkirim' value=0 > Tidak</p>";
      }
   else{
      echo "
      <p class=inline-small-label>
      <label for=field4>Dikirim</label>
      <input type=radio name='cekkirim' value=1 > Ya
      <input type=radio name='cekkirim' value=0 checked> Tidak</p>";
      }  
   if ($r[cekfinal]==1){
      echo "
      <p class=inline-small-label> 
      <label for=field4>Final</label>
      <input type=radio name='cekfinal' value=1 checked> Ya
      <input type=radio name='cekfinal' value=0 > Tidak</p>";
      }
   else{
      echo "
      <p class=inline-small-label>
      <label for=field4>Final</label>
      <input type=radio name='cekfinal' value=1 > Ya
      <input type=radio name='cekfinal' value=0 checked> Tidak</p>";
      }
   if ($r[cekproses]==1){
      echo "
      <p class=inline-small-label> 
      <label for=field4>Proses</label>
      <input type=radio name='cekproses' value=1 checked> Ya
      <input type=radio name='cekproses' value=0 > Tidak</p>";
      }
   else{
      echo "
      <p class=inline-small-label>
      <label for=field4>Proses</label>
      <input type=radio name='cekproses' value=1 > Ya
      <input type=radio name='cekproses' value=0 checked> Tidak</p>";
      }
            
 echo "<br /><br />
    <div class=block-actions> 
   <ul class=actions-right> 
   <li>
   <a class='button red' id=reset-validate-form href='?module=suratkeluar'>Batal</a>
   </li> </ul>
   <ul class=actions-left> 
   <li>
      <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
   </li> 
   </ul>
   </form>";
   
    break;
    
    case "lihatfile": 
  $gambar = mysql_query("SELECT nokel,file FROM dis_keluar WHERE noid='$_GET[id]'");
  $r    = mysql_fetch_array($gambar);
  $file = $r[file];
  
  echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>VIEW KELUAR SURAT NO.: $r[nokel]</h1>
   </div>
   <div class='block-content'>
   
   <center>
   <embed src='fileupload/skel/$file#toolbar=0&navpanes=0&scrollbar=0' 
          quality='high'
          name='suratkeluar'
          AllowScriptAccess='always'
          AllowFullScreen='true'
          type='application/pdf' 
          width='100%' 
          height='440'/>
   </embed>
   </center>
   <br/>
   
   <div class=block-actions>
   <ul class=actions-right> 
   <li>
   <a class='button red' id=reset-validate-form href='?module=suratkeluar'>Tutup</a>
   </li> </ul>";
   
    break; 
    
}
    //kurawal akhir hak akses module
}else {
	echo akses_salah();
    }
    }
    ?>

   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>
