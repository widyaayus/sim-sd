<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/biru/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../config/koneksi.php";
include "../../config/library.php";
include "../../config/fungsi_thumb.php";

$module=$_GET[module];
$act=$_GET[act];
$keluar=$_POST[thn_keluar].'-'.$_POST[bln_keluar].'-'.$_POST[tgl_keluar];
$kirim=$_POST[thn_kirim].'-'.$_POST[bln_kirim].'-'.$_POST[tgl_kirim];

// Hapus Data Surat Keluar
if ($module=='suratkeluar' AND $act=='hapus'){
   $data = mysql_query("SELECT file FROM dis_keluar WHERE noid='$_GET[id]'");
   $z    = mysql_fetch_array($data);
   if ($z[file]!=''){
	   mysql_query("DELETE FROM dis_keluar WHERE noid='$_GET[id]'");
     @unlink('../fileupload/skel/'.$z['file']);   
   }
   else{
     mysql_query("DELETE FROM dis_keluar WHERE noid='$_GET[id]'");
   }
  header('location:../../media.php?module='.$module);
}

// Input Surat Keluar
elseif ($module=='suratkeluar' AND $act=='input'){
  //Nomor Surat Keluar : NoUrut/KodeInstitusi/Klasifikasi/TahunSekarang
  //Contoh : 3752/RS.PWC/SW/VII/2016
  $a=mysql_fetch_array(mysql_query("SELECT kode_rs FROM dis_identitas WHERE id_identitas = 1"));
  $koders = $a[kode_rs];
  
  $klas   = $_POST[kodejra];
  $thn   = date("Y"); //tahun 4 digit
	$qr1	 = mysql_query("SELECT MAX(CONCAT(LPAD((SUBSTR((nokel),1,4)+1),4,'0'))) 
                         FROM dis_keluar 
                         WHERE YEAR(tgkel) = YEAR(now())");
  $qr2  = mysql_query("SELECT MIN(CONCAT(LPAD((SUBSTR((nokel),1,4)),4,'0'))) 
                        FROM dis_keluar 
                        WHERE YEAR(tgkel) = YEAR(now())");
  $kde1   = mysql_fetch_array($qr1);
  $kde2= mysql_fetch_array($qr2);
  	
  if ($kde2[0] != '0001'){
       $nourut = '0001'.'/'.$koders.'/'.$klas.'/'.$thn;
    }
    else{
       $nourut = $kde1[0].'/'.$koders.'/'.$klas.'/'.$thn;
    }
  
  mysql_query("INSERT INTO dis_keluar(nokel,
                      tgkel, 
                      jnskel,
                      kodejra,
			                lamp,
			                hal ,
			                kepada,
			                isisurat,
			                tembusan) 
              VALUES ('$nourut',
                      '$tgl_sekarang', 
                      '$_POST[sifat]',
                      '$_POST[kodejra]',
			                '$_POST[lamp]',
			                '$_POST[hal]',
			                '$_POST[kepada]',
			                '$_POST[isisurat]',
			                '$_POST[tembusan]')");
   
  header('location:../../media.php?module='.$module);
}

// Update Surat Keluar
elseif ($module=='suratkeluar' AND $act=='update'){
  //$allowed_ext = array('doc', 'docx', 'xls', 'xlsx', 'pdf');
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $file        = $_FILES['fupload']['name'];
  $file_ext	   = explode('.', $file);
  $tipe_file   = $_FILES['fupload']['type'];
  $file_size   = $_FILES['fupload']['size'];
  
  // Apabila File tidak diganti
  if (empty($lokasi_file)){
     mysql_query("UPDATE dis_keluar SET
                      nokel     = '$_POST[nokel]',
                      tgkel     = '$keluar', 
                      jnskel    = '$_POST[sifat]',
                      kodejra   = '$_POST[kodejra]',
			                lamp      = '$_POST[lamp]',
			                hal       = '$_POST[hal]',
			                kepada    = '$_POST[kepada]',
			                isisurat  = '$_POST[isisurat]',
			                tembusan  = '$_POST[tembusan]',
			                ceksimpan = '$_POST[ceksimpan]',
			                cekkirim  = '$_POST[cekkirim]',
			                cekfinal  = '$_POST[cekfinal]',
			                cekproses = '$_POST[cekproses]'
                WHERE noid      = '$_POST[id]'");
  }
  else{
     $data_file = mysql_query("SELECT file FROM dis_keluar WHERE noid='$_POST[id]'");
	   $z    	= mysql_fetch_array($data_file);
	   @unlink('../fileupload/skel/'.$z['file']);
		
	   UploadFileKeluar($file);
     mysql_query("UPDATE dis_keluar SET
                      nokel     = '$_POST[nokel]',
                      tgkel     = '$keluar', 
                      jnskel    = '$_POST[sifat]',
                      kodejra   = '$_POST[kodejra]',
			                lamp      = '$_POST[lamp]',
			                hal       = '$_POST[hal]',
			                kepada    = '$_POST[kepada]',
			                isisurat  = '$_POST[isisurat]',
			                tembusan  = '$_POST[tembusan]',
			                file      = '$file'
                WHERE noid      = '$_POST[id]'");
  }
  header('location:../../media.php?module='.$module);
}
}
?>
