<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../config/koneksi.php";
include "../../config/fungsi_thumb.php";

$module=$_GET[module];
$act=$_GET[act];
$terbit=$_POST[thn_terbit].'-'.$_POST[bln_terbit].'-'.$_POST[tgl_terbit];
$berlaku=$_POST[thn_berlaku].'-'.$_POST[bln_berlaku].'-'.$_POST[tgl_berlaku];
$selesai=$_POST[thn_selesai].'-'.$_POST[bln_selesai].'-'.$_POST[tgl_selesai];

// Hapus Data Surat Perjanjian
if ($module=='perjanjian' AND $act=='hapus'){
   $data = mysql_query("SELECT file FROM dis_keluar_pks WHERE noid='$_GET[id]'");
   $z    = mysql_fetch_array($data);
   if ($z[file]!=''){
	 mysql_query("DELETE FROM dis_keluar_pks WHERE noid='$_GET[id]'");
     @unlink('../../files/suratpks/'.$z['file']);   
   }
   else{
     mysql_query("DELETE FROM dis_keluar_pks WHERE noid='$_GET[id]'");
  }
  header('location:../../media.php?module='.$module);
}

// Input Surat Perjanjian
elseif ($module=='perjanjian' AND $act=='input'){
  //$allowed_ext = array('doc', 'docx', 'xls', 'xlsx', 'pdf');
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $file        = $_FILES['fupload']['name'];
  $file_ext	   = explode('.', $file);
  $tipe_file   = $_FILES['fupload']['type'];
  $file_size   = $_FILES['fupload']['size'];

  // Apabila ada file yang diupload
  if (!empty($lokasi_file)){  
    UploadFilePKS($file);
     mysql_query("INSERT INTO dis_keluar_pks(nopks,
                           tgpks,
                           pks_dengan,
                           hal,
                           lamp,
                           tgawal,
                           tgakhir,
                           kodejra,
                           ket,
                           file,
                           kd_ptgs) 
                    VALUES('$_POST[nopks]',
                           '$terbit',
                           '$_POST[pks_dengan]',
                           '$_POST[hal]',
                           '$_POST[lamp]',
                           '$berlaku',
                           '$selesai',
                           '$_POST[kodejra]',
                           '$_POST[ket]',
                           '$file',
                           '$_SESSION[namauser]')");
  }
  else{ 
     mysql_query("INSERT INTO dis_keluar_pks(nopks,
                           tgpks,
                           pks_dengan,
                           hal,
                           lamp,
                           tgawal,
                           tgakhir,
                           kodejra,
                           ket,
                           kd_ptgs) 
                    VALUES('$_POST[nopks]',
                           '$terbit',
                           '$_POST[pks_dengan]',
                           '$_POST[hal]',
                           '$_POST[lamp]',
                           '$berlaku',
                           '$selesai',
                           '$_POST[kodejra]',
                           '$_POST[ket]',
                           '$_SESSION[namauser]')");
  } 
  header('location:../../media.php?module='.$module);
}

// Update Surat Perjanjian
elseif ($module=='perjanjian' AND $act=='update'){
  //$allowed_ext = array('doc', 'docx', 'xls', 'xlsx', 'pdf');
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $file        = $_FILES['fupload']['name'];
  $file_ext	   = explode('.', $file);
  $tipe_file   = $_FILES['fupload']['type'];
  $file_size   = $_FILES['fupload']['size'];
  
  // Apabila File tidak diganti
  if (empty($lokasi_file)){
      mysql_query("UPDATE dis_keluar_pks SET 
			                nopks      = '$_POST[nopks]',
			                tgpks      = '$terbit',
			                pks_dengan = '$_POST[pks_dengan]',
			                hal        = '$_POST[hal]',
			                lamp       = '$_POST[lamp]',
			                tgawal     = '$berlaku',
			                tgakhir    = '$selesai',
			                kodejra    = '$_POST[kodejra]',
			                ket        = '$_POST[ket]',
			                cekfinal   = '$_POST[cekfinal]',
			                ceksimpan  = '$_POST[ceksimpan]'
                WHERE noid       = '$_POST[id]'");
     }
  else{
      $data_file = mysql_query("SELECT file FROM dis_keluar_pks WHERE noid='$_POST[id]'");
	    $z    	= mysql_fetch_array($data_file);
	    @unlink('../../files/suratpks/'.$z['file']);
		
	    UploadFilePKS($file);
      mysql_query("UPDATE dis_keluar_pks SET 
			                nopks      = '$_POST[nopks]',
			                tgpks      = '$terbit',
			                pks_dengan = '$_POST[pks_dengan]',
			                hal        = '$_POST[hal]',
			                lamp       = '$_POST[lamp]',
			                tgawal     = '$berlaku',
			                tgakhir    = '$selesai',
			                kodejra    = '$_POST[kodejra]',
			                ket        = '$_POST[ket]',
			                file       = '$file',
			                cekfinal   = '$_POST[cekfinal]',
			                ceksimpan  = '$_POST[ceksimpan]'
                WHERE noid       = '$_POST[id]'");
  }
  header('location:../../media.php?module='.$module);
}
}
?>
