<?php
include "config/koneksi.php";
$a=mysql_fetch_array(mysql_query("SELECT * FROM dis_pemakai WHERE kode_ptgs='$_SESSION[namauser]'"));
echo "<div class='nama_user'>$a[nama_ptgs]</div>"; 

?>
