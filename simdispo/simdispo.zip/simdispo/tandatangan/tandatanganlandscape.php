<?
include "config/koneksi.php";
$tt=mysql_fetch_array(mysql_query("SELECT * FROM dis_identitas WHERE id_identitas = 1"));
$idkota = $tt[kota];
$idnamadir = $tt[namadir];
$idjabatan = $tt[jabatan];
$idnip = $tt[nip];
$left = 28;
$h = 10;
	  
$now = date('Y-m-d');
$date_now = tgl_indo($now);
$this->SetFillColor(255);
$this->SetFont('Arial','',10);
$this->Ln(30);
$this->Cell(575,$h,' ',0,0,'C',true);
$this->Cell(485,$h,$idkota.', '.$date_now,0,0,'L',true);
$this->Ln();
$this->Cell(575,$h,' ',0,0,'C',true);
$this->Cell(485,$h,$idjabatan.',',0,0,'L',true);
$this->Ln(50);
$this->Cell(575,$h,' ',0,0,'C',true);
$this->Cell(485, $h, $idnamadir, 0, 0, 'L',true);
$this->Ln();
$this->Cell(575,$h,' ',0,0,'C',true);
$this->Cell(485, $h, 'NIP. : '.$idnip, 0, 0, 'L',true);

?>
