<?
include "config/koneksi.php";
$tt=mysql_fetch_array(mysql_query("SELECT * FROM dis_identitas WHERE id_identitas = 1"));
$idkota = $tt[kota];
$idnamadir = $tt[namadir];
$idjabatan = $tt[jabatan];
$idnip = $tt[nip];
$left = 28;
$h = 10;
	  
$now = date('Y-m-d');
$date_now = tgl_indo($now);
$this->SetFillColor(255);
$this->SetFont('Arial','',10);
$this->Ln(30);
$this->Cell(375,$h,' ',0,0,'C',true);
$this->Cell(285,$h,$idkota.', '.$date_now,0,0,'L',true);
$this->Ln(20);
$this->Cell(375,$h,' ',0,0,'C',true);
$this->Cell(285,$h,' Auditor,',0,0,'L',true);
$this->Ln(60);
$this->Cell(375,$h,' ',0,0,'C',true);
$this->Cell(285, $h, $_SESSION[namalengkap], 0, 0, 'L',true);
$this->Ln();
$this->Cell(375,$h,' ',0,0,'C',true);
$this->Cell(285, $h, 'NIP. : '.$_SESSION[nip], 0, 0, 'L',true);

/*
$this->SetFillColor(255);
$this->SetFont('Arial','',10);
$this->Ln(30);
$this->Cell(383,$h,' ',0,0,'C',true);
$this->Cell(383,$h,$idkota.','.$date_now,0,0,'C',true);
$this->Ln();
$this->Cell(383,$h,'Mengetahui,',0,0,'C',true);
$this->Cell(383, $h, '....................,', 0, 0, 'C',true);
$this->Ln(40);
$this->Cell(383,$h,'(............................)',0,0,'C',true);
$this->Cell(383, $h, '..........................', 0, 0, 'C',true);
$this->Ln();
$this->Cell(383,$h,'Wakil Direktur .................',0,0,'C',true);
$this->Cell(383, $h, 'Ka Bag/Ka Inst/Koord. ........', 0, 0, 'C',true);
$this->Ln();
$this->Cell(765,$h,'Menyetujui '.$idjabatan.',',0,0,'C',true);
$this->Ln(50);
$this->Cell(765, $h, $idnamadir, 0, 1, 'C',true);
$this->Cell(765, $h, 'NIP. : '.$idnip, 0, 0, 'C',true);
*/
?>
